-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';

DROP DATABASE IF EXISTS `trofeo_asm`;
CREATE DATABASE `trofeo_asm` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `trofeo_asm`;

DROP TABLE IF EXISTS `access_token_details`;
CREATE TABLE `access_token_details` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `access_token` varchar(32) NOT NULL,
  `vechicle_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `assigned_date` date NOT NULL,
  `shift` enum('Morning','Evening') NOT NULL,
  `start_km` int(11) NOT NULL DEFAULT '0',
  `end_km` int(11) NOT NULL DEFAULT '0',
  `total_km` int(11) NOT NULL DEFAULT '0',
  `ctime` int(11) NOT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY (`token_id`),
  KEY `vechicle_id` (`vechicle_id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `access_token_details_ibfk_1` FOREIGN KEY (`vechicle_id`) REFERENCES `vechicle` (`vechicle_id`),
  CONSTRAINT `access_token_details_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `counter_sales`;
CREATE TABLE `counter_sales` (
  `counter_sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `area_id` int(11) NOT NULL,
  `sale_no` char(16) NOT NULL,
  `sales_date` datetime NOT NULL,
  `quantity` decimal(9,3) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `token_id` int(11) NOT NULL,
  `item_type` enum('milk','curd') NOT NULL DEFAULT 'milk',
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`counter_sales_id`),
  UNIQUE KEY `sale_no` (`sale_no`),
  KEY `area_id` (`area_id`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `counter_sales_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `counter_sales_area` (`area_id`),
  CONSTRAINT `counter_sales_ibfk_3` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `counter_sales_area`;
CREATE TABLE `counter_sales_area` (
  `area_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `area_name` varchar(150) NOT NULL,
  `index_order_no` tinyint(4) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`area_id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `counter_sales_area_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `rate_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` char(16) NOT NULL,
  `mobile` char(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(150) NOT NULL,
  `pincode` char(10) NOT NULL,
  `outstanding_amt` decimal(10,2) NOT NULL DEFAULT '0.00',
  `mtime` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `route_id` (`route_id`),
  KEY `rate_type_id` (`rate_type_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`),
  CONSTRAINT `customers_ibfk_2` FOREIGN KEY (`rate_type_id`) REFERENCES `rate_type` (`rate_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` char(16) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_type` enum('milk','curd','butter_milk','loose_milk','counter_milk') NOT NULL,
  `uom` enum('pkt','ltr') NOT NULL,
  `retail_price` decimal(10,2) NOT NULL,
  `counter_sale_price` decimal(10,2) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `login_map`;
CREATE TABLE `login_map` (
  `map_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_role` char(15) NOT NULL,
  `token_id` int(11) NOT NULL,
  PRIMARY KEY (`map_id`),
  KEY `user_id` (`user_id`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `login_map_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_login` (`user_id`),
  CONSTRAINT `login_map_ibfk_2` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `order_booking`;
CREATE TABLE `order_booking` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `mobile1` int(11) NOT NULL,
  `mobile2` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` decimal(10,3) NOT NULL,
  `amt` decimal(10,2) NOT NULL,
  `advance_amt` decimal(10,2) NOT NULL,
  `balance_amt` decimal(10,2) NOT NULL,
  `payment_type` enum('Cash','Cheque') NOT NULL,
  `cheque_no` varchar(50) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `expected_delivery_date` date NOT NULL,
  `expected_delivery_time` time NOT NULL,
  `order_receiver` varchar(200) NOT NULL,
  `delivary_address` varchar(350) NOT NULL,
  `token_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `customer_id` (`customer_name`),
  KEY `item_id` (`item_id`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `order_booking_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `order_booking_ibfk_3` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `order_delivery`;
CREATE TABLE `order_delivery` (
  `delivery_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `delivery_date` datetime NOT NULL,
  `mobile` int(11) NOT NULL,
  `payment_type` enum('Cash','Cheque') NOT NULL,
  `cheque_no` varchar(50) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `received_amt` decimal(10,2) NOT NULL,
  `receiver_name` varchar(100) NOT NULL,
  `provider_name` varchar(100) NOT NULL,
  `number_of_can` int(11) NOT NULL,
  `number_of_tray` int(11) NOT NULL,
  `token_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_id`),
  KEY `order_id` (`order_id`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `order_delivery_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order_booking` (`order_id`),
  CONSTRAINT `order_delivery_ibfk_2` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `rate_type`;
CREATE TABLE `rate_type` (
  `rate_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_type_name` char(20) NOT NULL,
  PRIMARY KEY (`rate_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `raw_dump_archive_2017`;
CREATE TABLE `raw_dump_archive_2017` (
  `archive_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `api_key` char(40) DEFAULT NULL,
  `access_token` char(32) DEFAULT NULL,
  `json_dump` varchar(1000) DEFAULT NULL,
  `request_type` char(16) DEFAULT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY (`archive_id`)
) ENGINE=ARCHIVE DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `receipts`;
CREATE TABLE `receipts` (
  `receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_no` int(11) NOT NULL,
  `receipt_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `balance_amt` decimal(10,2) NOT NULL,
  `payment_type` enum('Cash','Bank') NOT NULL,
  `received_amt` decimal(10,2) NOT NULL,
  `cheque_no` varchar(50) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `returned_can` smallint(6) NOT NULL,
  `returned_tray` smallint(6) NOT NULL,
  `token_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`receipt_id`,`receipt_no`),
  KEY `customer_id` (`customer_id`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `receipts_ibfk_1` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `route`;
CREATE TABLE `route` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_code` char(5) NOT NULL,
  `route_name` varchar(255) NOT NULL,
  PRIMARY KEY (`route_id`),
  UNIQUE KEY `route_code` (`route_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `stock_details`;
CREATE TABLE `stock_details` (
  `stock_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `token_id` int(11) NOT NULL,
  `load_qty` decimal(9,3) NOT NULL,
  `available_qty` decimal(9,3) NOT NULL,
  `total_qty` decimal(9,3) NOT NULL,
  `number_of_cans` int(11) NOT NULL DEFAULT '0',
  `number_of_traies` int(11) NOT NULL DEFAULT '0',
  `updated_at` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`stock_details_id`),
  KEY `item_id` (`item_id`),
  KEY `user_id` (`user_id`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `stock_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `stock_details_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_login` (`user_id`),
  CONSTRAINT `stock_details_ibfk_3` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `stock_transfer`;
CREATE TABLE `stock_transfer` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_date` datetime NOT NULL,
  `transfered_route_code` varchar(200) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `quantity` varchar(150) NOT NULL,
  `from_vechile_id` int(11) NOT NULL,
  `to_vechile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`transfer_id`),
  KEY `item_id` (`item_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `stock_transfer_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `stock_transfer_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_login` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `user_login`;
CREATE TABLE `user_login` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(155) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `last_access_time` datetime DEFAULT NULL,
  `user_role` enum('admin','user') NOT NULL DEFAULT 'user',
  `mobile` char(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `config_key` char(40) NOT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `password` (`password`),
  KEY `mobile` (`mobile`),
  KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `vechicle`;
CREATE TABLE `vechicle` (
  `vechicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `vechicle_no` char(16) NOT NULL,
  `model` varchar(155) NOT NULL,
  `reg_no` char(16) NOT NULL,
  `make` year(4) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY (`vechicle_id`),
  UNIQUE KEY `vechicle_code` (`vechicle_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `whole_sale`;
CREATE TABLE `whole_sale` (
  `ws_id` int(11) NOT NULL AUTO_INCREMENT,
  `dc_no` char(16) NOT NULL,
  `dc_date` datetime NOT NULL,
  `token_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL DEFAULT '0',
  `total_qty` decimal(9,3) NOT NULL DEFAULT '0.000',
  `payment_type` enum('Cash','Cheque') NOT NULL,
  `cheque_no` varchar(200) DEFAULT NULL,
  `bank_name` varchar(200) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `can` int(11) NOT NULL DEFAULT '0',
  `tray` int(11) NOT NULL DEFAULT '0',
  `ctime` int(11) DEFAULT NULL,
  PRIMARY KEY (`ws_id`),
  KEY `dc_no` (`dc_no`),
  KEY `token_id` (`token_id`),
  CONSTRAINT `whole_sale_ibfk_1` FOREIGN KEY (`token_id`) REFERENCES `access_token_details` (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `whole_sale_item`;
CREATE TABLE `whole_sale_item` (
  `ws_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `ws_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` decimal(9,3) NOT NULL,
  `amt` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ws_item_id`),
  KEY `item_id` (`item_id`),
  KEY `ws_id` (`ws_id`),
  CONSTRAINT `whole_sale_item_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `whole_sale_item_ibfk_2` FOREIGN KEY (`ws_id`) REFERENCES `whole_sale` (`ws_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2017-10-23 16:16:59
