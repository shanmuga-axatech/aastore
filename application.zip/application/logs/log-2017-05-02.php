<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-02 13:13:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'trofeavv_amna'@'localhost' (using password: YES) /var/www/html/amna/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2017-05-02 13:13:08 --> Unable to connect to the database
ERROR - 2017-05-02 13:13:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'trofeavv_amna'@'localhost' (using password: YES) /var/www/html/amna/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2017-05-02 13:13:39 --> Unable to connect to the database
