<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-08 20:15:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-07-08 20:15:34 --> Query error: Unknown column 'hsncode' in 'field list' - Invalid query: SELECT category_id,
		category_name,hsncode,igstper FROM category WHERE 1=1  ORDER BY category_id ASC LIMIT 0,10
ERROR - 2017-07-08 21:02:24 --> Unable to load the requested class: Invprint
