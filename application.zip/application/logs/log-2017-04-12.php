<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-12 19:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-04-12 20:00:17 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_new_customers() /var/www/html/amna/application/models/Dashboard_model.php 88
ERROR - 2017-04-12 20:04:50 --> Query error: Table 'trofeo_amna_foods.customers' doesn't exist - Invalid query: SELECT COUNT(*) AS cnt FROM customers
         WHERE mtime <= 1492021799 AND mtime >= 1491935400
