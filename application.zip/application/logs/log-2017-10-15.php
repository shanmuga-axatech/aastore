<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-15 09:59:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/amna/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2017-10-15 09:59:14 --> Unable to connect to the database
ERROR - 2017-10-15 10:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-10-15 10:25:25 --> Query error: Unknown column 'hsncode' in 'field list' - Invalid query: SELECT category_id,
		category_name,hsncode,igstper FROM category WHERE 1=1  ORDER BY category_id ASC LIMIT 0,10
