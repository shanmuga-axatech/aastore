<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-01 15:34:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'trofeavv_amna'@'localhost' (using password: YES) /var/www/html/amna/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2017-05-01 15:34:21 --> Unable to connect to the database
ERROR - 2017-05-01 15:35:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-05-01 15:36:19 --> Unable to load the requested class: Invprint
ERROR - 2017-05-01 21:24:34 --> Array
(
    [0] => 5101
)

ERROR - 2017-05-01 21:24:34 --> DELETE FROM sales_item WHERE sales_id IN(5101)
ERROR - 2017-05-01 21:28:03 --> Array
(
    [0] => 5102
)

ERROR - 2017-05-01 21:28:04 --> DELETE FROM sales_item WHERE sales_id IN(5102)
ERROR - 2017-05-01 21:29:48 --> Array
(
    [0] => 5103
)

ERROR - 2017-05-01 21:29:48 --> DELETE FROM sales_item WHERE sales_id IN(5103)
ERROR - 2017-05-01 21:31:40 --> SELECT *
FROM `sales`
WHERE `sales_no` = 281
AND `form_type` = 'FORM-8'
AND `vechicle_code` = 'vc3'
AND `financial_year` = '0-01/05/2017'
ERROR - 2017-05-01 21:31:40 --> Array
(
    [0] => 5104
)

ERROR - 2017-05-01 21:31:40 --> DELETE FROM sales_item WHERE sales_id IN(5104)
ERROR - 2017-05-01 21:34:42 --> 01/05/2017
ERROR - 2017-05-01 21:34:42 --> 0-01/05/2017
ERROR - 2017-05-01 21:34:42 --> SELECT *
FROM `sales`
WHERE `sales_no` = 281
AND `form_type` = 'FORM-8'
AND `vechicle_code` = 'vc3'
AND `financial_year` = '0-01/05/2017'
ERROR - 2017-05-01 21:34:42 --> 2017-05-01
ERROR - 2017-05-01 21:34:42 --> 2017-2018
ERROR - 2017-05-01 21:34:42 --> Array
(
    [0] => 5105
)

ERROR - 2017-05-01 21:34:42 --> DELETE FROM sales_item WHERE sales_id IN(5105)
ERROR - 2017-05-01 21:36:48 --> 01/05/2017
ERROR - 2017-05-01 21:36:48 --> 0-01/05/2017
ERROR - 2017-05-01 21:36:48 --> SELECT *
FROM `sales`
WHERE `sales_no` = 281
AND `form_type` = 'FORM-8'
AND `vechicle_code` = 'vc3'
AND `financial_year` = '0-01/05/2017'
ERROR - 2017-05-01 21:36:48 --> Array
(
    [0] => 5106
)

ERROR - 2017-05-01 21:36:48 --> DELETE FROM sales_item WHERE sales_id IN(5106)
ERROR - 2017-05-01 21:44:09 --> 01/05/2017
ERROR - 2017-05-01 21:44:09 --> 2017-2018
ERROR - 2017-05-01 21:44:09 --> SELECT *
FROM `sales`
WHERE `sales_no` = 281
AND `form_type` = 'FORM-8'
AND `vechicle_code` = 'vc3'
AND `financial_year` = '2017-2018'
ERROR - 2017-05-01 21:44:09 --> Array
(
    [0] => 5102
)

ERROR - 2017-05-01 21:44:09 --> DELETE FROM sales_item WHERE sales_id IN(5102)
ERROR - 2017-05-01 21:45:31 --> 01/05/2017
ERROR - 2017-05-01 21:45:31 --> 2017-2018
ERROR - 2017-05-01 21:45:31 --> SELECT *
FROM `sales`
WHERE `sales_no` = 282
AND `form_type` = 'FORM-8'
AND `vechicle_code` = 'vc3'
AND `financial_year` = '2017-2018'
ERROR - 2017-05-01 21:45:31 --> Array
(
    [0] => 5107
)

ERROR - 2017-05-01 21:45:31 --> DELETE FROM sales_item WHERE sales_id IN(5107)
ERROR - 2017-05-01 21:46:09 --> 01/05/2017
ERROR - 2017-05-01 21:46:09 --> 2017-2018
ERROR - 2017-05-01 21:46:09 --> SELECT *
FROM `sales`
WHERE `sales_no` = 282
AND `form_type` = 'FORM-8'
AND `vechicle_code` = 'vc3'
AND `financial_year` = '2017-2018'
ERROR - 2017-05-01 21:46:09 --> Array
(
    [0] => 5107
)

ERROR - 2017-05-01 21:46:09 --> DELETE FROM sales_item WHERE sales_id IN(5107)
