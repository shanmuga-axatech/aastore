<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-21 12:21:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-10-21 12:21:54 --> Query error: Unknown column 'hsncode' in 'field list' - Invalid query: SELECT category_id,
		category_name,hsncode,igstper FROM category WHERE 1=1  ORDER BY category_id ASC LIMIT 0,10
ERROR - 2017-10-21 12:22:00 --> Query error: Unknown column 'hsncode' in 'field list' - Invalid query: SELECT category_id,
		category_name,hsncode,igstper FROM category WHERE 1=1  ORDER BY category_id ASC LIMIT 0,10
