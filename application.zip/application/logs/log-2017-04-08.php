<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-08 15:27:04 --> Query error: Unknown column 'iscancel' in 'field list' - Invalid query: SELECT sales_id,
        sales_no,sales_no AS billno, sales_date,sales.vechicle_code,mode_of_pay,form_type,cus.name,net_amt,iscancel FROM sales 
        INNER JOIN customer cus ON cus.customer_id=sales.customer_id  WHERE 1=1  ORDER BY sales.vechicle_code ASC LIMIT 0,25
ERROR - 2017-04-08 15:28:01 --> 404 Page Not Found: entry/Sales/get_print
ERROR - 2017-04-08 15:29:43 --> 404 Page Not Found: entry/Sales/get_print
ERROR - 2017-04-08 15:31:42 --> 404 Page Not Found: Dashboard/index
ERROR - 2017-04-08 15:32:26 --> 404 Page Not Found: Dashboard/index
ERROR - 2017-04-08 15:33:15 --> 404 Page Not Found: Dashboard/index
ERROR - 2017-04-08 15:33:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Dashboard_Model /var/www/html/amna/system/core/Loader.php 344
ERROR - 2017-04-08 15:33:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Dashboard_Model /var/www/html/amna/system/core/Loader.php 344
ERROR - 2017-04-08 15:34:32 --> Severity: Notice --> Undefined variable: title /var/www/html/amna/application/views/temp/header.php 51
ERROR - 2017-04-08 15:34:32 --> Severity: Notice --> Undefined variable: sURLAdd /var/www/html/amna/application/views/temp/header.php 59
ERROR - 2017-04-08 15:34:32 --> Severity: Notice --> Undefined variable: sURLView /var/www/html/amna/application/views/temp/header.php 60
ERROR - 2017-04-08 15:34:32 --> Severity: Notice --> Undefined variable: data /var/www/html/amna/application/controllers/Dashboard.php 20
ERROR - 2017-04-08 15:34:53 --> Severity: Notice --> Undefined variable: title /var/www/html/amna/application/views/temp/header.php 51
ERROR - 2017-04-08 15:34:53 --> Severity: Notice --> Undefined variable: sURLAdd /var/www/html/amna/application/views/temp/header.php 59
ERROR - 2017-04-08 15:34:53 --> Severity: Notice --> Undefined variable: sURLView /var/www/html/amna/application/views/temp/header.php 60
ERROR - 2017-04-08 15:44:57 --> Severity: Notice --> Undefined variable: title /var/www/html/amna/application/views/temp/head.php 50
ERROR - 2017-04-08 15:45:47 --> Severity: Notice --> Undefined variable: title /var/www/html/amna/application/views/temp/head.php 50
ERROR - 2017-04-08 15:57:34 --> Severity: Notice --> Undefined index:  /var/www/html/amna/application/helpers/ui_helper.php 81
ERROR - 2017-04-08 15:57:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/amna/application/helpers/ui_helper.php 81
ERROR - 2017-04-08 15:57:34 --> Carabiner: The asset group definition named 'minifyjs' does not contain a well formed array.
ERROR - 2017-04-08 16:25:29 --> Severity: error --> Exception: syntax error, unexpected '' FROM sales '' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/amna/application/models/Dashboard_model.php 18
ERROR - 2017-04-08 16:25:48 --> Severity: Warning --> date() expects parameter 2 to be integer, object given /var/www/html/amna/application/models/Dashboard_model.php 15
ERROR - 2017-04-08 16:41:04 --> Severity: error --> Exception: syntax error, unexpected '=' /var/www/html/amna/application/models/Dashboard_model.php 29
ERROR - 2017-04-08 16:41:29 --> Severity: error --> Exception: Call to a member function result_array() on array /var/www/html/amna/application/models/Dashboard_model.php 24
ERROR - 2017-04-08 22:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-04-08 22:54:55 --> Severity: Notice --> Undefined variable: end_date_obj /var/www/html/amna/application/models/Dashboard_model.php 51
ERROR - 2017-04-08 22:54:55 --> Severity: Warning --> date_modify() expects parameter 1 to be DateTime, null given /var/www/html/amna/application/models/Dashboard_model.php 51
ERROR - 2017-04-08 22:54:55 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, boolean given /var/www/html/amna/application/models/Dashboard_model.php 52
ERROR - 2017-04-08 22:54:55 --> Query error: Unknown column 'item.item_name' in 'field list' - Invalid query: SELECT item.item_name, SUM(si.qty) AS sales_qty,
       SUM(si.total) AS sales_total FROM sales_item AS si
       JOIN sales AS sale ON sale.sales_id = si.sales_id
       JOIN item AS itm ON si.item_id=itm.item_id
       WHERE sale.sales_date BETWEEN "" AND ""
       GROUP BY itm.item_id
ERROR - 2017-04-08 22:55:22 --> Query error: Unknown column 'item.item_name' in 'field list' - Invalid query: SELECT item.item_name, SUM(si.qty) AS sales_qty,
       SUM(si.total) AS sales_total FROM sales_item AS si
       JOIN sales AS sale ON sale.sales_id = si.sales_id
       JOIN item AS itm ON si.item_id=itm.item_id
       WHERE sale.sales_date BETWEEN "2017-04-07" AND "2017-04-07"
       GROUP BY itm.item_id
