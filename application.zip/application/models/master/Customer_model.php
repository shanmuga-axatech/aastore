<?php

class Customer_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function save($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Customer details failed to save.';
        
		$insert['name'] = $params['name'];
		$insert['tinno'] = $params['tinno'];
		$insert['customer_code'] = $params['customer_code'];
		$insert['sales_type'] = $params['sales_type'];
		$insert['mobile'] = $params['mobile'];
		$insert['email'] = $params['email'];
		$insert['address1'] = $params['address1'];
		$insert['address2'] = $params['address2'];
		$insert['pincode'] = $params['pincode'];
		$insert['phone'] = $params['phone'];			
		$insert['city'] = $params['city'];
		$insert['user_id'] = $params['user_id'];
		$insert['mtime'] = time();
		$bStatus = $this->isUniqueCode($params['customer_code']);
		
		if($bStatus && $this->db->insert('customer', $insert)) {
			$data['status'] = true;
			$data['customer_id'] = $this->db->insert_id();
			$data['msg'] = 'Customer details saved successfully.';
		}
	
		if(!$bStatus)
			$data['msg'] = 'Customer Code Already Exists.';

		return $data;
	}


	public function get_records($params)
	{
		$result = array ();
		$where = $orderby = '';		
		$result ['aaData'] = array ();		
		$sql = "SELECT customer_id,customer_code,vechicle_code,
		name, mobile, address1 FROM customer WHERE 1=1 ";
		
		$cql = "SELECT COUNT(customer_id) AS cnt
      				FROM customer WHERE 1=1 ";
		
		if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
			$sStr = $this->db->escape_like_str($params ['sSearch']);
			$where = " AND (name LIKE '%{$sStr}%' OR customer_code LIKE '%{$sStr}%'
			OR mobile = '{$sStr}' OR city LIKE '%{$sStr}%' OR vechicle_code LIKE '%{$sStr}%')";
		}
		
		$result ['sEcho'] = intval($params['sEcho']);
		switch ($params ['iSortCol_0']) {
			case 0 :
				$orderby = " ORDER BY customer_code " . strtoupper ( $params ['sSortDir_0'] );
				break;

			case 1 :
				$orderby = " ORDER BY vechicle_code " . strtoupper ( $params ['sSortDir_0'] );
				break;

			case 2 :
				$orderby = " ORDER BY name " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 3 :
				$orderby = " ORDER BY mobile " . strtoupper ( $params ['sSortDir_0'] );
				break;

			default :
				$orderby = " ORDER BY mtime DESC";
				break;
		}
		
		$cql .= $where;
		$sql .= $where . $orderby;
		if (isset ( $params ['iDisplayStart'] ) && 
			is_numeric ( $params ['iDisplayStart'] ) 
			&& isset ( $params ['iDisplayLength'] ) 
			&& is_numeric ( $params ['iDisplayLength'] ) 
			&& $params ['iDisplayLength'] > 0) {
			$sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
		} else {
			$sql .= " LIMIT 0, 25";
		}
		
		$rs = $this->db->query ($sql);
		$cnt = $this->db->query ($cql)->row_array ();
		$result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt ['cnt'];		
		if ($rs->num_rows () > 0) {						
			foreach ( $rs->result () as $row ) {
				$links = '';
				$links .= '<a  href="' . site_url ( 'master/customer/edit/'.$row->customer_id).'" class="btn btn-xs btn-default">';
				$links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';

				$links .= '&nbsp;<a  href="' . site_url ( 'master/customer/view/'.$row->customer_id).'" class="btn btn-xs btn-default pop-up-dialog">';
				$links .= '<i class="glyphicon glyphicon-play-circle"> </i>&nbsp;View</a>';
						
				$result ['aaData'] [] = array (
						$row->customer_code,			
						$row->vechicle_code,			
						$row->name,
						$row->mobile,
						$row->address1,
						$links
				);
			}
		}		
		return $result;		
	}

	public function edit($iCustomerId)
	{
		$oResult = $this->db->get_where('customer', array(
			'customer_id'=>$iCustomerId
		));
		return $oResult->row_array();
	}

	public function update($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Customer details failed to update.';     

		$insert['name'] = $params['name'];
		$insert['tinno'] = $params['tinno'];
		$insert['customer_code'] = $params['customer_code'];
		$insert['sales_type'] = $params['sales_type'];
		$insert['mobile'] = $params['mobile'];
		$insert['email'] = $params['email'];
		$insert['address1'] = $params['address1'];
		$insert['address2'] = $params['address2'];
		$insert['pincode'] = $params['pincode'];
		$insert['phone'] = $params['phone'];			
		$insert['city'] = $params['city'];
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();	
		$bStatus = $this->isUniqueCode(
			$params['customer_code'],$params['customer_id']
		);	
		if($bStatus && $this->db->update('customer', $insert, array(
			'customer_id'=>$params['customer_id']
		))) {
			$data['status'] = true;
			$data['customer_id'] = $params['customer_id'];
			$data['msg'] = 'Customer details updated successfully.';
		}
		if(!$bStatus)
			$data['msg'] = 'Customer Code Already Exists.';
		
		return $data;
	}

	private function isUniqueCode($sCode, $iCustomerId=0)
	{
		$sql = 'SELECT customer_id FROM customer ';
		$sql .= ' WHERE customer_code="'.$sCode.'"';
            
		if(!empty($iCustomerId))
			$sql .= ' AND customer_id != '.$iCustomerId;

		$sql .= ' LIMIT 1';

		$oResult = $this->db->query($sql);

		if($oResult->num_rows() > 0)
			return false;
				
		return true;
	}
}