<?php

class Category_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function save($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Category details failed to save.';
        
		$insert['category_name'] = $params['category_name'];
		$insert['hsncode'] = $params['hsncode'];
		$insert['igstper'] = $params['igstper'];		
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();
	    $bStatus = $this->isUniqueCode($params['category_name']);	

		if($bStatus && $this->db->insert('category', $insert)) {
			$data['status'] = true;
			$data['msg'] = 'Category details saved successfully.';
		}

		if(!$bStatus)
			$data['msg'] = 'Category Name Already Exists.';
					
		return $data;				
	}

	public function get_records($params)
	{
		$result = array ();
		$where = $orderby = '';		
		$result ['aaData'] = array ();		
		$sql = "SELECT category_id,
		category_name,hsncode,igstper FROM category WHERE 1=1 ";
		
		$cql = "SELECT COUNT(category_id) AS cnt
      				FROM category WHERE 1=1 ";
		
		if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
			$sStr = $this->db->escape_like_str($params ['sSearch']);
			$where = " AND (category_name LIKE '%{$sStr}%' 
			OR category_id = '{$sStr}')";
		}
		
		$result ['sEcho'] = intval($params['sEcho']);
		switch ($params ['iSortCol_0']) {
			case 0 :
				$orderby = " ORDER BY category_id " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 1 :
				$orderby = " ORDER BY category_name " . strtoupper ( $params ['sSortDir_0'] );
				break;

			case 2 :
				$orderby = " ORDER BY hsncode " . strtoupper ( $params ['sSortDir_0'] );
				break;

			case 3 :
				$orderby = " ORDER BY igstper " . strtoupper ( $params ['sSortDir_0'] );
				break;

			default :
				$orderby = " ORDER BY category_id DESC";
				break;
		}
		
		$cql .= $where;
		$sql .= $where . $orderby;
		if (isset ( $params ['iDisplayStart'] ) && 
			is_numeric ( $params ['iDisplayStart'] ) 
			&& isset ( $params ['iDisplayLength'] ) 
			&& is_numeric ( $params ['iDisplayLength'] ) 
			&& $params ['iDisplayLength'] > 0) {
			$sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
		} else {
			$sql .= " LIMIT 0, 10";
		}
		
		$rs = $this->db->query ($sql);
		$cnt = $this->db->query ($cql)->row_array ();
		$result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt ['cnt'];		
		if ($rs->num_rows () > 0) {						
			foreach ( $rs->result () as $row ) {
				$links = '';
				$links .= '<a  href="' . site_url ( 'master/category/edit/'.$row->category_id).'" class="btn btn-xs btn-default">';
				$links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';

				$result ['aaData'] [] = array (
						$row->category_id,
						$row->category_name,
						$row->hsncode,
						$row->igstper,					
						$links
				);
			}
		}		
		return $result;		
	}

	public function edit($iId)
	{
		$oResult = $this->db->get_where('category', array(
			'category_id'=>$iId
		));
		return $oResult->row_array();
	}

	public function update($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Category details failed to update.';        
		$insert['category_name'] = $params['category_name'];
        $insert['hsncode'] = $params['hsncode'];
        $insert['igstper'] = $params['igstper'];
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();
		$bStatus = $this->isUniqueCode(
			$params['category_name'],$params['category_id']
		);	
		if($bStatus && $this->db->update('category', $insert, array(
			'category_id'=>$params['category_id']
		))) {
			$data['status'] = true;
			$data['msg'] = 'Category Name updated successfully.';
		}
		
		if(!$bStatus)
			$data['msg'] = 'Category Name Already Exists.';

		return $data;
	}

	private function isUniqueCode($sName, $iCategoryId=0)
	{
		$sql = 'SELECT category_id FROM category ';
		$sql .= ' WHERE category_name="'.$sName.'"';
            
		if(!empty($iCategoryId))
			$sql .= ' AND category_id != '.$iCategoryId;

		$sql .= ' LIMIT 1';

		$oResult = $this->db->query($sql);

		if($oResult->num_rows() > 0)
			return false;
				
		return true;
	}		
}