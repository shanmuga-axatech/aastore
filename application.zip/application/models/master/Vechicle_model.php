<?php

class Vechicle_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function save($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Vechicle details failed to save.';        
		$insert['vechicle_code'] = $params['vechicle_code'];
		$insert['model'] = $params['model'];
		$insert['reg_no'] = $params['reg_no'];
		$insert['insurance_no'] = $params['insurance_no'];	
        $sExpiry = !empty($params['expiry_date'])?$params['expiry_date']:null;
        $insert['expiry_date'] = $sExpiry;
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();	
		$bStatus = $this->isUniqueCode($params['vechicle_code']);	

		if($bStatus &&$this->db->insert('vechicle', $insert)) {
			$data['status'] = true;
			$data['vechicle_id'] = $this->db->insert_id();
			$data['msg'] = 'Vechicle details saved successfully.';
		}		
		if(!$bStatus)
			$data['msg'] = 'Vechile Code Already Exists.';
					
		return $data;
	}


	public function get_records($params)
	{
		$result = array ();
        $cnt = 0;
		$where = $orderby = '';		
		$result ['aaData'] = array ();		
		$sql = "SELECT * FROM vechicle WHERE 1=1 ";

		if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
			$sStr = $this->db->escape_like_str($params ['sSearch']);
			$where = " AND (vechicle_code LIKE '%{$sStr}%' OR insurance_no LIKE '%{$sStr}%'
			OR model LIKE '%{$sStr}%' OR reg_no LIKE '%{$sStr}%')";
		}
		
		$result ['sEcho'] = intval($params['sEcho']);
		switch ($params ['iSortCol_0']) {
			case 0 :
				$orderby = " ORDER BY vechicle_code " . strtoupper ( $params ['sSortDir_0'] );
				break;					
			case 1 :
				$orderby = " ORDER BY model " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 2 :
				$orderby = " ORDER BY reg_no " . strtoupper ( $params ['sSortDir_0'] );
				break;
            case 3 :
				$orderby = " ORDER BY insurance_no " . strtoupper ( $params ['sSortDir_0'] );
				break;
            case 4 :
				$orderby = " ORDER BY expiry_date " . strtoupper ( $params ['sSortDir_0'] );
				break;
			default :
				$orderby = " ORDER BY mtime DESC";
				break;
		}

		$sql .= $where . $orderby;
		if (isset ( $params ['iDisplayStart'] ) && 
			is_numeric ( $params ['iDisplayStart'] ) 
			&& isset ( $params ['iDisplayLength'] ) 
			&& is_numeric ( $params ['iDisplayLength'] ) 
			&& $params ['iDisplayLength'] > 0) {
			$sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
		} else {
			$sql .= " LIMIT 0, 10";
		}		
		$rs = $this->db->query ($sql);	
		if ($rs->num_rows () > 0) {					
            $cnt = $rs->num_rows()+1; 	
			foreach ($rs->result() as $row) {
				$links = '';
				$links .= '<a  href="' . site_url ( 'master/vechicle/edit/'.$row->vechicle_id).'" class="btn btn-xs btn-default">';
				$links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';
				$result ['aaData'] [] = array (
						$row->vechicle_code,
						$row->model,
						$row->reg_no,
                        $row->insurance_no,
                        $row->expiry_date,
						$links
				);
			}
		}	
        $result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt;			
		return $result;		
	}

	public function edit($vechicle_id)
	{
		$oResult = $this->db->get_where('vechicle', array(
			'vechicle_id'=>$vechicle_id
		));
		return $oResult->row_array();
	}

	public function update($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Vechicle details failed to update.';        
		$insert['vechicle_code'] = $params['vechicle_code'];
		$insert['model'] = $params['model'];
		$insert['reg_no'] = $params['reg_no'];
		$insert['insurance_no'] = $params['insurance_no'];	
        $sExpiry = !empty($params['expiry_date'])?$params['expiry_date']:null;
        $insert['expiry_date'] = $sExpiry;
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();	
		$bStatus = $this->isUniqueCode(
			$params['vechicle_code'],$params['vechicle_id']
		);	
		if($bStatus && $this->db->update('vechicle', $insert, array('vechicle_id'=>$params['vechicle_id']))) {
			$data['status'] = true;
			$data['msg'] = 'Vechicle details updated successfully.';
		}		

		if(!$bStatus)
			$data['msg'] = 'Vechile Code Already Exists.';

		return $data;
	}

	private function isUniqueCode($sCode, $ivechicleId=0)
	{
		$sql = 'SELECT vechicle_id FROM vechicle ';
		$sql .= ' WHERE vechicle_code="'.$sCode.'"';
            
		if(!empty($ivechicleId))
			$sql .= ' AND vechicle_id != '.$ivechicleId;

		$sql .= ' LIMIT 1';

		$oResult = $this->db->query($sql);

		if($oResult->num_rows() > 0)
			return false;
				
		return true;
	}	
}