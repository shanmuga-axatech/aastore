<?php

class Item_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

    public function get_category()
    {
        $oResult = $this->db->get('category');
        return $oResult->result();
    }

	public function save($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Item details failed to save.';        
		$insert['item_name'] = $params['item_name'];
		$insert['item_code'] = $params['item_code'];
		$insert['category_id'] = $params['category_id'];
	//	$insert['tax_per'] = $params['tax_per'];
		$insert['mrp'] = $params['mrp'];
		$insert['retail_price'] = $params['retail_price'];
		$insert['whole_sale_price'] = $params['whole_sale_price'];	
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();	
		$bStatus = $this->isUniqueCode($params['item_code']);	
		
		if($bStatus && $this->db->insert('item', $insert)) {
			$data['status'] = true;
			$data['item_id'] = $this->db->insert_id();
			$data['msg'] = 'Item details saved successfully.';
		}	
	   if(!$bStatus)
		$data['msg'] = 'Item Code Already Exists.';

		return $data;
	}


	public function get_records($params)
	{
		$result = array ();
        $cnt = 0;
		$where = $orderby = '';		
		$result ['aaData'] = array ();		
		$sql = "SELECT item.item_id,
		item.item_code, item.item_name, category.category_name,
		retail_price,whole_sale_price 
        FROM item
        JOIN category ON item.category_id=category.category_id WHERE 1=1 ";
        
        $cql = "SELECT COUNT(item_id) AS cnt
      				FROM item 
      				JOIN category ON item.category_id=category.category_id ";

		if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
			$sStr = $this->db->escape_like_str($params ['sSearch']);
			$where = " AND (item_code LIKE '%{$sStr}%' 
			OR item_name LIKE '%{$sStr}%' OR category_name LIKE '%{$sStr}%')";
		}
		
		$result ['sEcho'] = intval($params['sEcho']);
		switch ($params ['iSortCol_0']) {
			case 0 :
				$orderby = " ORDER BY item_code " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 1 :
				$orderby = " ORDER BY item_name " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 2 :
				$orderby = " ORDER BY category_name " . strtoupper ( $params ['sSortDir_0'] );
				break;

			default :
				$orderby = " ORDER BY mtime DESC";
				break;
		}
        
        $cql .= $where; 
		$sql .= $where . $orderby;
		if (isset ( $params ['iDisplayStart'] ) && 
			is_numeric ( $params ['iDisplayStart'] ) 
			&& isset ( $params ['iDisplayLength'] ) 
			&& is_numeric ( $params ['iDisplayLength'] ) 
			&& $params ['iDisplayLength'] > 0) {
			$sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
		} else {
			$sql .= " LIMIT 0, 10";
		}		
		$rs = $this->db->query ($sql);	
		$cnt = $this->db->query ($cql)->row_array ();
		$result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt ['cnt'];		

		if ($rs->num_rows () > 0) {					        
			foreach ($rs->result() as $row) {
				$links = '';
				$links .= '<a  href="' . site_url ( 'master/item/edit/'.$row->item_id).'" class="btn btn-xs btn-default">';
				$links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';

				$links .= '&nbsp;<a  href="' . site_url ( 'master/item/view/'.$row->item_id).'" class="btn btn-xs btn-default pop-up-dialog">';
				$links .= '<i class="glyphicon glyphicon-play-circle"> </i>&nbsp;View</a>';
						
				$result ['aaData'] [] = array (
						$row->item_code,
						$row->item_name,
						$row->category_name,
						$row->retail_price,
						$row->whole_sale_price,
						$links
				);
			}
		}	
		return $result;		
	}

	public function edit($item_id)
	{
		$oResult = $this->db->get_where('item', array(
			'item_id'=>$item_id
		));
		return $oResult->row_array();
	}

	public function update($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Item details failed to update.';        
		$insert['item_name'] = $params['item_name'];
		$insert['item_code'] = $params['item_code'];
		$insert['category_id'] = $params['category_id'];
	//	$insert['tax_per'] = $params['tax_per'];
		$insert['mrp'] = $params['mrp'];
		$insert['retail_price'] = $params['retail_price'];
		$insert['whole_sale_price'] = $params['whole_sale_price'];	
		$insert['user_id'] = $this->session->userdata('user_id');
		$insert['mtime'] = time();	
		$bStatus = $this->isUniqueCode(
			$params['item_code'],$params['item_id']
		);	
		if($bStatus && $this->db->update('item', $insert, array('item_id'=>$params['item_id']))) {
			$data['status'] = true;
			$data['msg'] = 'Item details updated successfully.';
		}		
	   if(!$bStatus)
		$data['msg'] = 'Item Code Already Exists.';

		return $data;
	}

	private function isUniqueCode($sCode, $iItemId=0)
	{
		$sql = 'SELECT item_id FROM item ';
		$sql .= ' WHERE item_code="'.$sCode.'"';
            
		if(!empty($iItemId))
			$sql .= ' AND item_id != '.$iItemId;

		$sql .= ' LIMIT 1';

		$oResult = $this->db->query($sql);

		if($oResult->num_rows() > 0)
			return false;
				
		return true;
	}
}