<?php

class Dashboard_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}


	public function counts()
	{
      
      $result=array();

      $total_sql="SELECT SUM(net_amt) AS total_amt FROM sales WHERE 1=1 ";
      
      $van_sales_sql ="SELECT SUM(net_amt) AS total_amt,trim(vechicle_code) AS van FROM
                        sales GROUP BY trim(vechicle_code)" ;

      $result['sales'] = $this->db->query($total_sql)->row_array();
      $result['vansales'] = $this->db->query($van_sales_sql)->result_array();

      return $result;
	}
}