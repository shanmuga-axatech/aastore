<?php

class User_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function save($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'User details failed to save.'; 

		$sSql = 'SELECT user_id FROM user_login
					WHERE email= "'.$params['email'].'" LIMIT 1';
		$oResult = $this->db->query($sSql);

		if($oResult->num_rows() > 0)
			return $data;

		$insert['user_name'] = $params['user_name'];
		$insert['mobile'] = $params['mobile'];
		$insert['email'] = $params['email'];
		$insert['password'] = $params['password'];
		$insert['user_role'] = $params['user_role'];
		$insert['status'] = 1;
		$insert['config_key'] = $this->getAPIKey();	
		$insert['mtime'] = time();		
		if($this->db->insert('user_login', $insert)) {
			$data['status'] = true;
			$data['msg'] = 'User details saved successfully.';
		}		
		return $data;
	}


	private function getAPIKey()
	{
		$sKey = '';
		$aKeys = array(
			md5(time()+3),
			md5(time()+5),
			md5(time()+8),
			md5(time()+11),
			md5(time()+7),
		);

		$this->db->select('user_id, config_key');
		$this->db->from('user_login');
		$this->db->where_in('config_key', $aKeys);
		$oResult = $this->db->get();

		if(is_object($oResult) && 
				$oResult->num_rows() > 0 && 
					$oResult->num_rows() < 5) {
			foreach ($oResult->result() as $oRow) {
				if(($key = array_search($oRow->config_key, $aKeys)) !== false) {
				    unset($aKeys[$key]);
				}
			}
		}

		$iKey = array_rand($aKeys,1);
		return $aKeys[$iKey];
	}


	public function get_records($params)
	{
		$result = array ();
		$where = $orderby = '';		
		$result ['aaData'] = array ();		
		$sql = "SELECT user_id,user_name, email,user_role, 
					password,mobile,status FROM user_login WHERE 1=1 ";
		
		$cql = "SELECT COUNT(user_id) AS cnt
      				FROM user_login WHERE 1=1 ";
		
		if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
			$sStr = $this->db->escape_like_str($params ['sSearch']);
			$where = " AND (user_name LIKE '%{$sStr}%' 
			OR email = '{$sStr}' OR user_role = '{$sStr}' OR mobile = '{$sStr}')";
		}
		
		$result ['sEcho'] = intval($params['sEcho']);
		switch ($params ['iSortCol_0']) {
			case 0 :
				$orderby = " ORDER BY user_name " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 1 :
				$orderby = " ORDER BY email " . strtoupper ( $params ['sSortDir_0'] );
				break;
					
			case 2 :
				$orderby = " ORDER BY password " . strtoupper ( $params ['sSortDir_0'] );
				break;

			case 3 :
				$orderby = " ORDER BY mobile " . strtoupper ( $params ['sSortDir_0'] );
				break;

			case 4 :
				$orderby = " ORDER BY user_role " . strtoupper ( $params ['sSortDir_0'] );
				break;

			default :
				$orderby = " ORDER BY mtime DESC";
				break;
		}
		
		$cql .= $where;
		$sql .= $where . $orderby;
		if (isset ( $params ['iDisplayStart'] ) && 
			is_numeric ( $params ['iDisplayStart'] ) 
			&& isset ( $params ['iDisplayLength'] ) 
			&& is_numeric ( $params ['iDisplayLength'] ) 
			&& $params ['iDisplayLength'] > 0) {
			$sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
		} else {
			$sql .= " LIMIT 0, 10";
		}
		
		$rs = $this->db->query ($sql);
		$cnt = $this->db->query ($cql)->row_array ();
		$result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt ['cnt'];		
		if ($rs->num_rows () > 0) {						
			foreach ( $rs->result () as $row ) {
				$links = '';
				$links .= '<a  href="' . site_url ( 'admin/user/edit/'.$row->user_id).'" class="btn btn-xs btn-default">';
				$links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';

				$status = ($row->status==1)?'InActive':'Active';
				$icon = ($row->status==1)?'glyphicon glyphicon-ban-circle':'glyphicon glyphicon-ok-circle';
				$text = ($row->status==1)?'Disable':'Enable';
				$class = ($row->status==1)?'btn-danger':'btn-success';
				$links .= '&nbsp;<a data-status="'.$status.'"  href="' . site_url ( 'admin/user/update-status/'.$row->user_id.'/'.$status).'" class="btn btn-xs '.$class.'">';
				$links .= '<i class="'.$icon.'"> </i>&nbsp;'.$text.'</a>';
						
				$result ['aaData'] [] = array (
						$row->user_name,
						$row->email,
						$row->password,						
						$row->mobile,
						ucwords($row->user_role),
						$links
				);
			}
		}		
		return $result;		
	}

	public function edit($iCustomerId)
	{
		$oResult = $this->db->get_where('user_login', array(
			'user_id'=>$iCustomerId
		));
		return $oResult->row_array();
	}

	public function update($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'User details failed to update.';        
		$insert['user_name'] = $params['user_name'];
		$insert['mobile'] = $params['mobile'];
		$insert['email'] = $params['email'];
		$insert['password'] = $params['password'];
		$insert['user_role'] = $params['user_role'];
		$insert['mtime'] = time();		
		if($this->db->update('user_login', $insert, array(
			'user_id'=>$params['user_id']
		))) {
			$data['status'] = true;
			$data['msg'] = 'User details updated successfully.';
		}
		
		return $data;
	}

	public function update_status($user_id, $status)
	{
		$data = array();
		$data['status'] = false;
		$data['msg'] = 'Failed to change the user status.';
		$status = strtolower($status);
		$aStatus = array('active', 'inactive');
		if(in_array($status, $aStatus)) {
			$update = array();
			$update['config_key'] = '';
			$update['status'] = 0;
			$where = array('user_id'=>$user_id);
			if($status=='active') {
				$update['config_key'] = $this->getAPIKey();
				$update['status'] = 1;
			}
			if($this->db->update('user_login', $update, $where)) {
				$data['status'] = true;
				$data['msg'] = 'User status updated successfully.';
			}
		}
		return $data;
	}
}