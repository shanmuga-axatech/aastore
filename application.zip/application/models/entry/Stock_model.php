<?php

class Stock_Model extends CI_Model
{
    public function save($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Stock details failed to save.';
        
        $insert['input_date'] = $params['input_date'];
		$insert['item_code'] = strtoupper($params['item_code']);
		$insert['batch_no'] = $params['batch_no'];
        $insert['item_id'] = $this->get_item_id($params['item_code']);
		$insert['vechicle_code'] = strtoupper($params['vechicle_code']);
        $insert['vechicle_id'] = $this->get_vech_id($params['vechicle_code']);
		$insert['opening_qty'] = $params['opening_qty'];
		$insert['input_qty'] = $params['input_qty'];
		$insert['closing_qty'] = $params['closing_qty'];
		$insert['user_id'] = $params['user_id'];
		$insert['mtime'] = time();
		
		if($this->db->insert('vechicle_stock_input', $insert)) {
			$data['status'] = true;
			$data['stock_input_id'] = $this->db->insert_id();
			$data['msg'] = 'Stock details saved successfully.';
		}
		
		return $data;
	}


	public function get_records($params)
	{
		$result = array ();
		$where = $orderby = '';		
		$result ['data'] = array ();		
		$sql = "SELECT stock_input_id,input_date,vsi.item_code,item.item_name,batch_no,vechicle_code,opening_qty, input_qty, closing_qty FROM vechicle_stock_input as vsi
            Join item ON item.item_id=vsi.item_id WHERE 1=1 AND input_date = '".date('Y-m-d')."'";
		
		$cql = "SELECT COUNT(stock_input_id) AS cnt
      				FROM vechicle_stock_input AS vsi 
      				Join item ON item.item_id=vsi.item_id WHERE 1=1 AND input_date = '".date('Y-m-d')."'";
		
		if (isset ($params['search']['value']) && !empty($params ['search']['value'])) {
			$sStr = $this->db->escape_like_str($params['search']['value']);
			$where = " AND (item.item_name LIKE '%{$sStr}%' OR vsi.item_code LIKE '%{$sStr}%' OR batch_no LIKE '%{$sStr}%' OR vechicle_code LIKE '%{$sStr}%')";
		}

		if(!empty($params['vechicle_code']) || !empty($params['item_code']) ) {

			$where .= " AND (";
			$a = array();

			if(!empty($params['vechicle_code']))
				$a[] = "vechicle_code LIKE '%{$params['vechicle_code']}%'";

			if(!empty($params['item_code'])) 
				$a[] = "vsi.item_code LIKE '%{$params['item_code']}%'";

			$where .= implode(' AND ', $a).')';
		}

		
		$orderbycol = $params['order'][0]['column'];
		$orderbydir = $params['order'][0]['dir'];

		switch ($orderbycol) {
			case 0 :
				$orderby = " ORDER BY input_date " . strtoupper ( $orderbydir );
				break;
					
			case 1 :
				$orderby = " ORDER BY item_code " . strtoupper ( $orderbydir );
				break;

			case 2 :
				$orderby = " ORDER BY item_name " . strtoupper ( $orderbydir );
				break;
					
			case 3 :
				$orderby = " ORDER BY vechicle_code " . strtoupper ( $orderbydir );
				break;

			case 5 :
				$orderby = " ORDER BY input_qty " . strtoupper ( $orderbydir );
				break;

			default :
				$orderby = " ORDER BY input_date DESC,item_name ";
				break;
		}
		
		$cql .= $where;
		$sql .= $where . $orderby;
		if (isset ( $params ['start'] ) && 
			is_numeric ( $params ['start'] ) 
			&& isset ( $params ['length'] ) 
			&& is_numeric ( $params ['length'] ) 
			&& $params ['length'] > 0) {
			$sql .= " LIMIT ".$params ['start'].",".$params ['length'];
		} else {
			$sql .= " LIMIT 0, 25";
		}

		//echo $sql;exit();
				
		$rs = $this->db->query ($sql);
		$cnt = $this->db->query ($cql)->row_array ();
		$result ['recordsTotal'] = $result ['recordsFiltered'] = $cnt ['cnt'];	
			
		if ($rs->num_rows () > 0) {						
			foreach ( $rs->result () as $row ) {
				$links = '';
				$links .= '<a  href="' . site_url ( 'entry/stock/edit/'.$row->stock_input_id).'" class="btn btn-xs btn-default">';
				$links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';
						
				$result ['data'] [] = array (
						'input_date'=>$row->input_date,
						'item_code'=>$row->item_code,
						'item'=>$row->item_name,
						'vech_code'=>$row->vechicle_code,
                        'op_qty'=>$row->opening_qty,
						'in_qty'=>$row->input_qty,
						'cl_qty'=>$row->closing_qty,
						'action'=>$links
				);
			}
		}		
		return $result;		
	}

	public function edit($stock_id)
	{
		$oResult = $this->db->get_where('vechicle_stock_input', array(
			'stock_input_id'=>$stock_id
		));
		return $oResult->row_array();
	}

	public function update($params)
	{
		$insert = array();		
		$data = array();		
		$data['status'] = false;
		$data['msg'] = 'Stock details failed to update.';

		$insert['input_date'] = $params['input_date'];
		$insert['item_code'] = strtoupper($params['item_code']);
		$insert['batch_no'] = $params['batch_no'];
        $insert['item_id'] = $this->get_item_id($params['item_code']);
		$insert['vechicle_code'] = strtoupper($params['vechicle_code']);
        $insert['vechicle_id'] = $this->get_vech_id($params['vechicle_code']);
		$insert['opening_qty'] = $params['opening_qty'];
		$insert['input_qty'] = $params['input_qty'];
		$insert['closing_qty'] = $params['closing_qty'];
		$insert['user_id'] = $params['user_id'];
		$insert['entry_type'] = 'manual';
		$insert['mtime'] = time();		

		if($this->db->update('vechicle_stock_input', $insert, array(
			'stock_input_id'=>$params['stock_input_id']
		))) {
			$data['status'] = true;
			$data['msg'] = 'Stock details updated successfully.';
		}
		
		return $data;
	}

    public function get_items($params)
    {
        $data = array();
        $sql = 'SELECT item.item_id, item.item_code, item.item_name';
        $sql .= ' FROM item ';       
        $sql .= ' WHERE item.item_code LIKE "%'.$params['term'].'%" OR ';
        $sql .= ' item.item_name LIKE "%'.$params['term'].'%"';
        $oResult = $this->db->query($sql);        
        if($oResult->num_rows() > 0) {
            foreach($oResult->result() as $oRow) {
                $aItem = array();
                $aItem['item_id'] = $oRow->item_id;
                $aItem['item_code'] = strtoupper($oRow->item_code);
                $aItem['item_name'] = strtoupper($oRow->item_name);
                $aItem['value'] = strtoupper($oRow->item_code);
                $data[] = $aItem;
            }
        }

        return $data;
    }

    private function get_item_id($item_code)
    {
        $iId = 0;
        $sql = 'SELECT item.item_id';
        $sql .= ' FROM item ';       
        $sql .= ' WHERE item.item_code = "'.$item_code.'"';
        $oResult = $this->db->query($sql);
        if($oResult->num_rows() > 0) {
            $aRow = $oResult->row_array();
            $iId = $aRow['item_id'];
        }

        return $iId;

    }

    public function vechicle_details($params)
    {
        $data = array();
        $sql = 'SELECT vechicle_code, model';
        $sql .= ' FROM vechicle ';       
        $sql .= ' WHERE vechicle_code LIKE "%'.$params['term'].'%" OR ';
        $sql .= ' model LIKE "%'.$params['term'].'%"';
        $oResult = $this->db->query($sql);
        log_message('error', $sql);
        if($oResult->num_rows() > 0) {
            foreach($oResult->result() as $oRow) {
                $aItem = array();               
                $aItem['vechicle_code'] = strtoupper($oRow->vechicle_code);
                $aItem['model'] = strtoupper($oRow->model);
                $aItem['value'] = strtoupper($oRow->vechicle_code);
                $data[] = $aItem;
            }
        }

        return $data;
    }

    private function get_vech_id($vCode)
    {
        $iId = 0;
        $sql = 'SELECT vechicle_id, model';
        $sql .= ' FROM vechicle ';       
        $sql .= ' WHERE vechicle_code = "'.$vCode.'"';
        $oResult = $this->db->query($sql);

        if($oResult->num_rows() > 0) {
            $aRow = $oResult->row_array();
            $iId = $aRow['vechicle_id'];
        }

        return $iId;

    }

   public function get_vechicle()
   {
		$sql= "Select vechicle_id,vechicle_code from vechicle";
   		return $this->db->query($sql)->result();
   }

   public function get_item_list()
   {
   		$sql = 'SELECT stock.item_code, item.item_name'.
   		' FROM vechicle_stock_input AS stock'.
   		' JOIN item ON item.item_code = stock.item_code'.
   		' GROUP BY item.item_code';
   		return $this->db->query($sql)->result();   		
   }

   public function verify_unique($params)
   {
   		$data = array();
   		$data['status'] = false;
   		$sql = 'SELECT stock_input_id FROM vechicle_stock_input '.
   		' WHERE input_date="'.$params['input_date'].'"'.
   		' AND item_code="'.$params['item_code'].'"'.
   		' AND vechicle_code="'.$params['vechicle_code'].'"';
   		$result = $this->db->query($sql);
   		if($result->num_rows() > 0) {
   			$row = $result->row_array();
   			$data['status'] = true;
   			$data['stock_input_id'] = $row['stock_input_id'];
   		}
   		return $data;
   }
       
}