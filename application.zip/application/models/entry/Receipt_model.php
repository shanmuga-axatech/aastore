<?php

class Receipt_Model extends CI_Model
{
    public function saveTemp($params,$unique_id, $cate)
    {
        $insert = array();
        $insert['unique_id'] = $unique_id;
        $insert['json_data'] = json_encode($params);
        $insert['cate'] = $cate;
        $insert['mtime'] = time();
        $insert['user_id'] = $this->session->userdata('user_id');
        return $this->db->insert('temp', $insert);
    }

    public function get_outstanding_amount_details($unique_id)
    {              
        $oResult = $this->get_temp_records($unique_id, 'receipt');
        $oRcpt = json_decode($oResult->json_data);
        return $this->get_outstanding_details($oRcpt->customer_code);        
    }

    public function get_outstanding_details($customer_code)
    {
        $data = array();
        $sql = 'SELECT sales.sales_id,sales.sales_no,sales.sales_date,'.
        'IFNULL(SUM(sales_item.total),0) AS outstanding_amt '.
        'FROM sales '.
        'JOIN sales_item ON sales.sales_id=sales_item.sales_id '.
        'WHERE sales.customer_code="'.$customer_code.'"';
        $oRst = $this->db->query($sql);        
        if($oRst->num_rows() > 0) {
            $data['sales'] = array();
            $aItem = array();
            foreach ($oRst->result_array() as $oRow) {
               $aItem[$oRow['sales_id']] = $oRow;
               $aItem[$oRow['sales_id']]['display']  = $oRow['sales_no'].' | ';
               $aItem[$oRow['sales_id']]['display'] .= date('d-m-Y', strtotime($oRow['sales_date']));
            }
            $data = $aItem;
        }
        return $data;
    }

    public function get_items_list($params)
    {
        $data = array();
        $data['aaData'] = array();

        if(!isset($params['receipt_id']) || empty($params['receipt_id'])) {
            $data['aaData'] = $this->get_temp_datatable($params);
        }   
        else if(isset($params['receipt_id']) && !empty($params['receipt_id'])) {
             $data['aaData'] = $this->get_item_datatable($params['receipt_id']);
        }     
        
        return $data;
    }

    private function get_item_details($item_id)
    {
        return $this->db->get_where('item', array('item_id'=>$item_id))->row();
    }

    private function get_temp_records($unique_id, $cate)
    {
        $where = array(
            'unique_id' => $unique_id,
            'cate' => $cate
        );
        $oResult = $this->db->get_where('temp', $where);
        if($cate=='receipt') {
            return $oResult->row();
        }
        return $oResult->result();
    }

    private function get_temp_datatable($params)
    {
        $data = array();
        $oData = $this->get_temp_records($params['unique_id'], 'receipt_item');
        foreach ($oData as $oRow) {
           $aItem = [];
           $oJson = json_decode($oRow->json_data);
           $oItem = $this->get_sales_details($oJson->sales_id);
           $sDate = date('d-m-Y',strtotime($oItem->sales_date));
           $sHtml = '<h5>'.$oItem->sales_no.' | '.$sDate.'</h5>';
           $sLink = '<button class="btn btn-default btn-xs delete-temp" data-id="'.$oRow->temp_id.'">';
           $sLink .= '<i class="glyphicon glyphicon-remove-circle"></i>&nbsp;Delete</button>';
           $sQty = '<input type="text" class="form-control input-sm outstanding_amt text-right" value="'.$oJson->outstanding_amt.'">';
           $sTotal = '<input type="text" class="form-control input-sm received_amt text-right" value="'.$oJson->received_amt.'">';
           
           $aItem[] = $sHtml;          
           $aItem[] = $sQty;
           $aItem[] = $sTotal;        
           $aItem[] = $sLink;
           $data[] = $aItem;
        }
        return $data;
    }

    private function get_item_datatable($receipt_id)
    {   
         $data = array();

         $oResult = $this->db->get_where('sales_receipt_item', array('receipt_id'=>$receipt_id));

         if(is_object($oResult) && $oResult->num_rows() > 0) {
            foreach ($oResult->result() as $oRow) {
               $aItem = [];              
               $oItem = $this->get_sales_details($oRow->sales_id);
              
               $sLink = '<button class="btn btn-default btn-xs delete-item" data-id="'.$oRow->receipt_item_id.'">';
               $sLink .= '<i class="glyphicon glyphicon-remove-circle"></i>&nbsp;Delete</button>';
              
               $sTotal = '<input type="text" class="form-control input-sm received_amt text-right" value="'.$oRow->received_amt.'">';
              
               $aItem[] = $oItem->sales_no;
               $aItem[] = $oRow->outstanding_amt;
               $aItem[] = $sTotal;  
               $aItem[] = $sLink;
               $data[] = $aItem;
            }
         }

         return $data;

    }

    private function get_sales_details($sales_id)
    {
        return $this->db->get_where('sales', array(
            'sales_id'=>$sales_id
        ))->row();
    }

    public function delete_temp_record($temp_id)
    {
        return $this->db->delete('temp', array('temp_id'=>$temp_id));
    }

    public function delete_item_record($receipt_item_id)
    {
        return $this->db->delete('sales_receipt_item', array('receipt_item_id'=>$receipt_item_id));
    }

    public function save($params)
    {
        $data = array();
        $bStatus = true;
        $iSalesId = 0;

        if(isset($params['receipt_id']) && !empty($params['receipt_id'])) {
            return $this->update_receipt_amounts($params);
        }

        $this->db->trans_begin();
        $oReceipt = $this->get_temp_records($params['unique_id'], 'receipt');

        if(empty($oReceipt))
            $bStatus = false;

        if($bStatus) {
            $aReceipt = json_decode($oReceipt->json_data, true);
            $params['user_id'] = $this->session->userdata('user_id');
            $params['mtime'] = time();
            $iReceiptId = $this->insert_receipt($aReceipt, $params);            
        }

        if(!empty($iReceiptId) && $bStatus) {
            $oItems = $this->get_temp_records($params['unique_id'], 'receipt_item');
            if(!empty($oItems)) {
                foreach ($oItems as $oItem) {
                    $aItem = json_decode($oItem->json_data, true);
                    $aItem['user_id'] = $this->session->userdata('user_id');
                    $aItem['mtime'] = time();
                    $bStatus = $this->insert_receipt_item($aItem, $iReceiptId);
                    if(!$bStatus) {  
                        break;
                    }
                }             
            }
        }

        if (!$bStatus || $this->db->trans_status() === FALSE) {
            $data['status'] = false;
            $data['msg'] = 'Failed to save the sales entry.';
            $this->db->trans_rollback();
        } 
        else {

            //remove temp entries
            $this->remove_temp_entries($params['unique_id']);

            $data['status'] = true;
            $data['msg'] = 'Receipt entry created successfully.';
            $this->db->trans_commit();
        }
        return $data;
    }

    public function remove_temp_entries($unique_id)
    {
        $this->db->delete('temp', array('unique_id'=>$unique_id));
    }

    public function insert_receipt($aReceipt, $params)
    {
        $receipt_id = 0;
        $bStatus = $this->checkUniqueBillNo(
            $aReceipt['receipt_no'],$aReceipt['receipt_date']
        );
        if($bStatus) {
            $insert = array();
            $insert['receipt_no'] = $aReceipt['receipt_no'];
            $insert['receipt_date'] = $aReceipt['receipt_date'];
            $insert['customer_code'] = $aReceipt['customer_code'];           
            $insert['financial_year'] = financial_year($aReceipt['receipt_date']);
            $insert['net_amt'] = isset($aReceipt['net_amt'])?$aReceipt['net_amt']:$params['net_amt'];
            $insert['user_id'] = $params['user_id'];
            $insert['mtime'] = $params['mtime'];
            $insert['customer_id'] = $this->get_customer_id($aReceipt['customer_code']);
            if($this->db->insert('sales_receipt', $insert)) {               
                $receipt_id = $this->db->insert_id();
            }
            else {
                log_message('error', $this->db->_error_message());
            }
        }
        return $receipt_id;
    }

    public function insert_receipt_item($params, $receipt_id)
    {
        $receipt_item_id=0;
        $insert = array();
        $insert['sales_id'] = $params['sales_id'];
        $insert['receipt_id'] =$receipt_id;        
        $insert['outstanding_amt'] = $params['outstanding_amt'];
        $insert['received_amt'] = $params['received_amt'];       
        $insert['user_id'] = $params['user_id'];
        $insert['mtime'] = $params['mtime'];
        if($this->db->insert('sales_receipt_item', $insert)) {           
            $receipt_item_id = $this->db->insert_id();
        }
        else {
            log_message('error', $this->db->last_query());
        }        
        return $receipt_item_id;
    }

    public function checkUniqueBillNo($receipt_no,$receipt_date,$receipt_id=null)
    {
        $this->db->where('receipt_no', $receipt_no);
        $this->db->where('financial_year', financial_year($receipt_date));

        if(!empty($receipt_id))
            $this->db->where('receipt_id != ', $receipt_id);

        $chk = $this->db->get('sales_receipt');
        if($chk->num_rows() > 0) {
            log_message('error', 'Duplicate receipt number');
            return false;
        }
        return true;
    }

    public function get_customer_id($sCode)
    {
        $oCustomer = $this->db->get_where('customer', array(
            'customer_code' => $sCode
        ))->row();
        return $oCustomer->customer_id;
    }

    public function get_records($params)
    {
        $result = array ();
        $where = $orderby = '';     
        $result ['aaData'] = array ();      
        $sql = "SELECT receipt_id,
        receipt_no, receipt_date, customer_code, net_amt FROM sales_receipt WHERE 1=1 ";
        
        $cql = "SELECT COUNT(receipt_id) AS cnt
                    FROM sales_receipt WHERE 1=1 ";
        
        if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
            $sStr = $this->db->escape_like_str($params ['sSearch']);
            $where = " AND (receipt_no = '$sStr' 
            OR receipt_date = '{$sStr}' OR customer_code LIKE '%{$sStr}%')";
        }
        
        $result ['sEcho'] = intval($params['sEcho']);
        switch ($params ['iSortCol_0']) {
            case 0 :
                $orderby = " ORDER BY receipt_no " . strtoupper ( $params ['sSortDir_0'] );
                break;
                    
            case 1 :
                $orderby = " ORDER BY receipt_date " . strtoupper ( $params ['sSortDir_0'] );
                break;
                    
            case 2 :
                $orderby = " ORDER BY customer_code " . strtoupper ( $params ['sSortDir_0'] );
                break;

            default :
                $orderby = " ORDER BY mtime DESC";
                break;
        }
        
        $cql .= $where;
        $sql .= $where . $orderby;
        if (isset ( $params ['iDisplayStart'] ) && 
            is_numeric ( $params ['iDisplayStart'] ) 
            && isset ( $params ['iDisplayLength'] ) 
            && is_numeric ( $params ['iDisplayLength'] ) 
            && $params ['iDisplayLength'] > 0) {
            $sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
        } else {
            $sql .= " LIMIT 0, 10";
        }
        
        $rs = $this->db->query ($sql);
        $cnt = $this->db->query ($cql)->row_array ();
        $result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt ['cnt'];        
        if ($rs->num_rows () > 0) {                     
            foreach ( $rs->result () as $row ) {
                $links = '';
                $links .= '<a  href="' . site_url ( 'entry/receipt/edit/'.$row->receipt_id).'" class="btn btn-xs btn-default">';
                $links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';

                $links .= '&nbsp;<a  href="' . site_url ( 'entry/receipt/view/'.$row->receipt_id).'" class="btn btn-xs btn-default pop-up-dialog">';
                $links .= '<i class="glyphicon glyphicon-play-circle"> </i>&nbsp;View</a>';
                        
                $result ['aaData'] [] = array (
                        $row->receipt_no,
                        $row->receipt_date,
                        $row->customer_code,
                        $row->net_amt,
                        $links
                );
            }
        }       
        return $result;

    }

    public function edit($receipt_id)
    {
        $data = array();
        $data['receipt'] = $this->db->get_where(
            'sales_receipt', array('receipt_id'=>$receipt_id)
        )->row_array();
        $sql = 'SELECT sales.sales_no, sales.sales_date,'.
        'receipt.outstanding_amt, receipt.received_amt '.
        ' FROM sales '.
        ' JOIN sales_receipt_item As receipt ON receipt.sales_id = sales.sales_id '.
        ' WHERE receipt_id='.$receipt_id;
        $oResult = $this->db->query($sql);
        $data['receipt_item'] = $oResult->result_array();
        return $data;
    }

    public function update($params)
    {
        $data = array();
        $data['status'] = false;
        $data['msg']= 'Failed to update the receipt details.';
        $bStatus = $this->checkUniqueBillNo(
            $params['receipt_no'],$params['receipt_date'],$params['receipt_id']
        );
        if($bStatus) {
            $where = array('receipt_id'=>$params['receipt_id']);
            $insert = array();
            $insert['receipt_no'] = $params['receipt_no'];
            $insert['receipt_date'] = $params['receipt_date'];
            $insert['customer_code'] = $params['customer_code'];
            $insert['financial_year'] = financial_year($params['receipt_date']);
            $insert['user_id'] = $params['user_id'];
            $insert['mtime'] = $params['mtime'];
            $insert['customer_id'] = $this->get_customer_id($params['customer_code']);
            if($this->db->update('sales_receipt', $insert, $where)) {               
               $data['status'] = true;
               $data['receipt_id'] = $params['receipt_id'];
               $data['msg']= 'Receipt details are updated successfully.';
            }
            else {
                log_message('error', $this->db->_error_message());
            }            
        }
        return $data;
    }

    public function update_receipt_amounts($params)
    {
        $data = array();
        $update = array();
        $data['status'] = true;
        $data['msg'] = 'Receipt entry updated successfully.';
        $where = array('receipt_id'=>$params['receipt_id']);       
        $update['net_amt'] = $params['net_amt'];
        $update['user_id'] = $this->session->userdata('user_id');
        $update['mtime'] = time();        
        if(!$this->db->update('sales_receipt', $update, $where)) {
            $data['status'] = false;
            $data['msg'] = 'Failed to update net amount details.';
        }
        return $data;
    }

}