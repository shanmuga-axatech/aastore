<?php

class Sales_Model extends CI_Model
{
    public function saveTemp($params,$unique_id, $cate)
    {
        $insert = array();
        $insert['unique_id'] = $unique_id;
        $insert['json_data'] = json_encode($params);
        $insert['cate'] = $cate;
        $insert['mtime'] = time();
        $insert['user_id'] = $this->session->userdata('user_id');
        return $this->db->insert('temp', $insert);
    }

    public function get_items_list($params)
    {
        $data = array();
        $data['aaData'] = array();

        if(!isset($params['sales_id']) || empty($params['sales_id'])) {
            $data['aaData'] = $this->get_temp_datatable($params);
        }   
        else if(isset($params['sales_id']) && !empty($params['sales_id'])) {
             $data['aaData'] = $this->get_item_datatable($params['sales_id']);
        }     
        
        return $data;
    }

    private function get_item_details($item_id)
    {
        return $this->db->get_where('item', array('item_id'=>$item_id))->row();
    }

    private function get_temp_records($unique_id, $cate)
    {
        $where = array(
            'unique_id' => $unique_id,
            'cate' => $cate
        );
        $oResult = $this->db->get_where('temp', $where);
        if($cate=='sales') {
            return $oResult->row();
        }
        return $oResult->result();
    }

    private function get_temp_datatable($params)
    {
        $data = array();
        $oData = $this->get_temp_records($params['unique_id'], 'sales_item');
        foreach ($oData as $oRow) {
           $aItem = [];
           $oJson = json_decode($oRow->json_data);
           $oItem = $this->get_item_details($oJson->item_id);
           $sHtml = '<h5>'.$oItem->item_name.' <small>'.strtoupper($oItem->item_code).'</small></h5>';
           $sLink = '<button class="btn btn-default btn-xs delete-temp" data-id="'.$oRow->temp_id.'">';
           $sLink .= '<i class="glyphicon glyphicon-remove-circle"></i>&nbsp;Delete</button>';
           $sQty = '<input type="text" class="form-control input-sm item_qty text-right" value="'.$oJson->qty.'">';
           $sTotal = '<input type="text" class="form-control input-sm item_total text-right" value="'.$oJson->total.'">';
           $aItem[] = $sHtml;
           $aItem[] = $oJson->batch_no;
           $aItem[] = $sQty;
           $aItem[] = $oJson->rate;
           $aItem[] = $sTotal;  
           $aItem[] = $sLink;
           $data[] = $aItem;
        }
        return $data;
    }

    private function get_item_datatable($sales_id)
    {   
         $data = array();

         $oResult = $this->db->get_where('sales_item', array('sales_id'=>$sales_id));

         if(is_object($oResult) && $oResult->num_rows() > 0) {
            foreach ($oResult->result() as $oRow) {
               $aItem = [];              
               $oItem = $this->get_item_details($oRow->item_id);
               $sHtml = '<h5>'.$oItem->item_name.' <small>'.strtoupper($oItem->item_code).'</small></h5>';
               $sLink = '<button class="btn btn-default btn-xs delete-item" data-id="'.$oRow->sales_item_id.'">';
               $sLink .= '<i class="glyphicon glyphicon-remove-circle"></i>&nbsp;Delete</button>';
               $sQty = '<input type="text" class="form-control input-sm item_qty text-right" value="'.$oRow->qty.'">';
               $sTotal = '<input type="text" class="form-control input-sm item_total text-right" value="'.$oRow->total.'">';
               $aItem[] = $sHtml;
               $aItem[] = $oRow->batch_no;
               $aItem[] = $sQty;
               $aItem[] = $oRow->rate;
               $aItem[] = $sTotal;  
               $aItem[] = $sLink;
               $data[] = $aItem;
            }
         }

         return $data;

    }

    public function delete_temp_record($temp_id)
    {
        return $this->db->delete('temp', array('temp_id'=>$temp_id));
    }

    public function delete_item_record($sales_item_id)
    {
        return $this->db->delete('sales_item', array('sales_item_id'=>$sales_item_id));
    }

    public function save($params)
    {
        $data = array();
        $bStatus = true;
        $iSalesId = 0;

        if(isset($params['sales_id']) && !empty($params['sales_id'])) {
            return $this->update_sales_amounts($params);
        }

        $this->db->trans_begin();
        $oSales = $this->get_temp_records($params['unique_id'], 'sales');

        if(empty($oSales))
            $bStatus = false;

        if($bStatus) {
            $aSales = json_decode($oSales->json_data, true);
            $params['user_id'] = $this->session->userdata('user_id');
            $params['mtime'] = time();
            $iSalesId = $this->insert_sales($aSales, $params);            
        }

        if(!empty($iSalesId) && $bStatus) {
            $oItems = $this->get_temp_records($params['unique_id'], 'sales_item');
            if(!empty($oItems)) {
                foreach ($oItems as $oItem) {
                    $aItem = json_decode($oItem->json_data, true);
                    $aItem['user_id'] = $this->session->userdata('user_id');
                    $aItem['mtime'] = time();
                    $bStatus = $this->insert_sales_item($aItem, $iSalesId, $aSales['sales_no']);
                    if(!$bStatus) {  
                        break;
                    }
                }             
            }
        }

        if (!$bStatus || $this->db->trans_status() === FALSE) {
            $data['status'] = false;
            $data['msg'] = 'Failed to save the sales entry.';
            $this->db->trans_rollback();
        } 
        else {

            //remove temp entries
            $this->remove_temp_entries($params['unique_id']);

            $data['status'] = true;
            $data['msg'] = 'Sales entry created successfully.';
            $this->db->trans_commit();
        }
        return $data;
    }

    public function remove_temp_entries($unique_id)
    {
        $this->db->delete('temp', array('unique_id'=>$unique_id));
    }


    public function insert_sales($aSales, $params)
    {
        $sales_id = 0;
        $bStatus = $this->checkUniqueBillNo(
            $aSales['sales_no'],$aSales['sales_date']
        );
        if($bStatus) {
            $insert = array();
            $insert['sales_no'] = $aSales['sales_no'];
            $insert['sales_date'] = $aSales['sales_date'];
            $insert['customer_code'] = $aSales['customer_code'];
            $insert['outstanding_amt'] = $aSales['outstanding_amt'];
            $insert['financial_year'] = financial_year($aSales['sales_date']);
            $insert['user_id'] = $params['user_id'];
            $insert['mtime'] = $params['mtime'];            
            $insert['total_qty'] = $params['total_qty'];
            $insert['total_amt'] = $params['total_amt'];
            $insert['customer_id'] = $this->get_customer_id($aSales['customer_code']);
            if($this->db->insert('sales', $insert)) {               
                $sales_id = $this->db->insert_id();
            }
            else {
                log_message('error', $this->db->_error_message());
            }
        }
        return $sales_id;
    }

    public function insert_sales_item($params, $sales_id, $sales_no)
    {
        $sales_item_id=0;
        $insert = array();
        $insert['sales_id'] = $sales_id;
        $insert['sales_no'] = $sales_no;
        $insert['item_id'] = $params['item_id'];
        $insert['item_code'] = $params['item_code'];
        $insert['batch_no'] = $params['batch_no'];
        $insert['qty'] = $params['qty'];
        $insert['rate'] = $params['rate'];
        $insert['total'] = $params['total'];
        $insert['user_id'] = $params['user_id'];
        $insert['mtime'] = $params['mtime'];
        if($this->db->insert('sales_item', $insert)) {           
            $sales_item_id = $this->db->insert_id();
        }
        else {
            log_message('error', $this->db->last_query());
        }        
        return $sales_item_id;
    }

    public function checkUniqueBillNo($sales_no,$sales_date,$sales_id=null)
    {
        $this->db->where('sales_no', $sales_no);
        $this->db->where('financial_year', financial_year($sales_date));

        if(!empty($sales_id))
            $this->db->where('sales_id != ', $sales_id);

        $chk = $this->db->get('sales');
        if($chk->num_rows() > 0) {
            log_message('error', 'Duplicate sales number');
            return false;
        }
        return true;
    }

    public function get_customer_id($sCode)
    {
        $oCustomer = $this->db->get_where('customer', array(
            'customer_code' => $sCode
        ))->row();
        return $oCustomer->customer_id;
    }

    public function get_records($params)
    {
        $result = array ();
        $where = $orderby = '';     
        $result ['aaData'] = array ();    
        //CONCAT(sales.vechicle_code,'/',sales_no) AS billno  
        $sql = "SELECT sales_id,
        sales_no,sales_no AS billno, sales_date,sales.vechicle_code,mode_of_pay,form_type,cus.name,net_amt,iscancel FROM sales 
        INNER JOIN customer cus ON cus.customer_id=sales.customer_id  WHERE 1=1 ";
        
        $cql = "SELECT COUNT(sales_id) AS cnt
                    FROM sales  
                    INNER JOIN customer cus ON cus.customer_id=sales.customer_id 
                    WHERE 1=1 AND financial_year='2017-2018' ";     

        if (isset ( $params ['sSearch'] ) && ! empty ( $params ['sSearch'] )) {
            $sStr = $this->db->escape_like_str($params ['sSearch']);
            $where = " AND (sales_no LIKE '%{$sStr}%' 
            OR sales_date = '{$sStr}' OR sales.vechicle_code = '{$sStr}' OR form_type = '{$sStr}' 
            OR mode_of_pay = '{$sStr}' OR name LIKE '%{$sStr}%')";
        }
        
        $result ['sEcho'] = intval($params['sEcho']);
        switch ($params ['iSortCol_0']) {
            case 0 :
                $orderby = " ORDER BY sales.vechicle_code " . strtoupper ( $params ['sSortDir_0'] );
                break;

            case 1 :
                $orderby = " ORDER BY billno " . strtoupper ( $params ['sSortDir_0'] );
                break;
                    
            case 2 :
                $orderby = " ORDER BY sales_date " . strtoupper ( $params ['sSortDir_0'] );
                break;

            case 3 :
                $orderby = " ORDER BY customer_code " . strtoupper ( $params ['sSortDir_0'] );
                break;  

            case 4 :
                $orderby = " ORDER BY form_type " . strtoupper ( $params ['sSortDir_0'] );
                break;

            case 5 :
                $orderby = " ORDER BY mode_of_pay " . strtoupper ( $params ['sSortDir_0'] );
                break;                                                                

            case 6 :
                $orderby = " ORDER BY total_amt " . strtoupper ( $params ['sSortDir_0'] );
                break;

            default :
                $orderby = " ORDER BY sales_date DESC,sales_no DESC,vechicle_code";
                break;
        }
        
        $cql .= $where;
        $sql .= $where . $orderby;
        if (isset ( $params ['iDisplayStart'] ) && 
            is_numeric ( $params ['iDisplayStart'] ) 
            && isset ( $params ['iDisplayLength'] ) 
            && is_numeric ( $params ['iDisplayLength'] ) 
            && $params ['iDisplayLength'] > 0) {
            $sql .= " LIMIT ".$params ['iDisplayStart'].",".$params ['iDisplayLength'];
        } else {
            $sql .= " LIMIT 0, 10";
        }
        
        $rs = $this->db->query ($sql);
        $cnt = $this->db->query ($cql)->row_array ();
        $result ['iTotalRecords'] = $result ['iTotalDisplayRecords'] = $cnt ['cnt'];        
        if ($rs->num_rows () > 0) {                     
            foreach ( $rs->result () as $row ) {
                $links = '';
               // $links .= '<a  href="' . site_url ( 'entry/sales/edit/'.$row->sales_id).'" class="btn btn-xs btn-default">';
               // $links .= '<i class="glyphicon glyphicon-edit"> </i>&nbsp;Edit</a>';

                $links .= '&nbsp;<a  href="' . site_url ( 'entry/sales/view/'.$row->sales_id).'" class="btn btn-xs btn-default pop-up-dialog">';
                $links .= '<i class="glyphicon glyphicon-search"> </i></a>';

                $links .= '&nbsp;|&nbsp<a  href="' . site_url ( 'entry/sales/billcancel/'.$row->sales_id).'" class="btn btn-xs btn-danger pop-up-dialog">';
                $links .= '<i class="glyphicon glyphicon-remove"> </i></a>';

            if($row->iscancel!=1) {
               $links .= '&nbsp;|&nbsp;<a href="'.site_url('/entry/sales/get_print/'.$row->sales_id.'/'.url_title($row->sales_no)).'" target="_blank" data-toggle="tooltip" title="Print" data-placement="top" class="print">';
             $links .= '<i class="glyphicon glyphicon-print"></i></a>';      
            }    
                    
                $result ['aaData'] [] = array (
                        $row->vechicle_code,                    
                        $row->billno,
                        $row->sales_date,
                        $row->name,
                        $row->form_type,                        
                        $row->mode_of_pay,
                        $row->net_amt,
                        $links
                );
            }
        }       
        return $result;

    }

    public function cancel_get($sales_id)
    {
      $data = array();
      $this->db->select('sales_id,iscancel,reason');
      $oResult = $this->db->get_where('sales', array('sales_id'=>$sales_id));      
      $data['cancel_reason'] = $oResult->row_array();
      return $data;       
    }

    public function cancel_entry($params)
    {
        $data = array();
        $data['status'] = false;
        $data['msg']= 'Failed to Cancel the sales Entry.';

            $where = array('sales_id'=>$params['sales_id']);
            $insert = array();
            $insert['iscancel'] = '1';
            $insert['reason'] = $params['reason'];
            $insert['total_amt'] = '0.00';
            $insert['total_qty'] = '0.000';
            $insert['sub_total'] = '0.00';
            $insert['kvat_amt'] = '0.00';
            $insert['disc_amt'] = '0.000';
            $insert['round_off'] = '0.000';
            $insert['net_amt'] = '0.000';

        if($this->db->update('sales', $insert, $where)) {               
               $data['status'] = true;
               $data['sales_id'] = $params['sales_id'];

            if($data['status']){
                $this->db->where('sales_id',$params['sales_id']);
               $this->db->delete('sales_item');
               $data['msg']= 'Sales Entry canceled successfully.';
            }
            else {
                log_message('error', $this->db->_error_message());
            } 
        }            
        return $data; 
    }

    public function edit($sales_id)
    {
        $data = array();
         $sql = 'SELECT sales_id,
        sales_no, sales_date,sales.vechicle_code,mode_of_pay,form_type,
        sales.customer_code,sales.customer_id,cus.name,total_amt,total_qty,
        kvat_per,kvat_amt,sub_total,disc_per,disc_amt,round_off,net_amt,
        iscancel,reason FROM sales 
        inner join customer cus ON cus.customer_id=sales.customer_id WHERE sales_id='.$sales_id ;

        $data['sales'] = $this->db->query($sql)->row_array();

        $sql = 'SELECT si.item_id, si.sales_item_id,si.item_code,'.
        'si.qty,si.rate,si.batch_no,si.total,si.item_id,item.item_name'.
        ' FROM sales_item AS si '.
        ' JOIN item ON si.item_id=item.item_id '.
        ' WHERE si.sales_id='.$sales_id;

        $oResult = $this->db->query($sql);

        $data['sales_item'] = $oResult->result_array();

        return $data;
    }

    public function update($params)
    {
        $data = array();
        $data['status'] = false;
        $data['msg']= 'Failed to update the sales details.';
        $bStatus = $this->checkUniqueBillNo(
            $params['sales_no'],$params['sales_date'],$params['sales_id']
        );
        if($bStatus) {
            $where = array('sales_id'=>$params['sales_id']);
            $insert = array();
            $insert['sales_no'] = $params['sales_no'];
            $insert['sales_date'] = $params['sales_date'];
            $insert['customer_code'] = $params['customer_code'];
            $insert['outstanding_amt'] = $params['outstanding_amt'];
            $insert['financial_year'] = financial_year($params['sales_date']);
            $insert['user_id'] = $params['user_id'];
            $insert['mtime'] = $params['mtime'];
            $insert['customer_id'] = $this->get_customer_id($params['customer_code']);
            if($this->db->update('sales', $insert, $where)) {               
               $data['status'] = true;
               $data['sales_id'] = $params['sales_id'];
               $data['msg']= 'Sales details are updated successfully.';
            }
            else {
                log_message('error', $this->db->_error_message());
            }            
        }
        return $data;
    }

    public function update_sales_amounts($params)
    {
        $data = array();
        $update = array();
        $data['status'] = true;
        $data['msg'] = 'Sales entry updated successfully.';
        $where = array('sales_id'=>$params['sales_id']);
        $update['total_qty'] = $params['total_qty'];
        $update['total_amt'] = $params['total_amt'];
        $update['user_id'] = $this->session->userdata('user_id');
        $update['mtime'] = time();        
        if(!$this->db->update('sales', $update, $where)) {
            $data['status'] = false;
            $data['msg'] = 'Failed to update total amount details.';
        }
        return $data;
    }

    public function get_customers($params)
    {
        $data = array();
        $sql = 'SELECT customer_id, name, customer_code FROM customer';
        $sql .= ' WHERE customer_code LIKE "%'.$params['term'].'%" LIMIT 10';
        $oResult = $this->db->query($sql);

        if(is_object($oResult) && $oResult->num_rows() > 0) {
            foreach ($oResult->result_array() as $aRow) {
                $aRow['label'] = $aRow['customer_code'];
                $aRow['value'] = $aRow['customer_code'];
                $data[] = $aRow;
            }
        }

        return $data;
    }

    public function get_sales($sales_id)
    {
        $sql = 'SELECT sales_id,
        sales_no, sales_date,sales.vechicle_code,mode_of_pay,form_type,
        sales.customer_code,sales.customer_id,cus.name,total_amt,total_qty,
        kvat_per,kvat_amt,sub_total,disc_per,disc_amt,round_off,net_amt,
        iscancel,reason FROM sales 
        inner join customer cus ON cus.customer_id=sales.customer_id WHERE sales_id='.$sales_id ;

        return $this->db->query($sql)->row_array();

    }

     public function get_sales_items($sales_id)
     {

        $sql = 'SELECT si.item_id, si.sales_item_id,si.item_code,si.tax_per,'.
        'si.qty,si.rate,si.batch_no,si.total,si.item_id,item.item_name'.
        ' FROM sales_item AS si '.
        ' JOIN item ON si.item_id=item.item_id '.
        ' WHERE si.sales_id='.$sales_id;

        return $this->db->query($sql)->result_array();
    }

    public function get_customer_details($customer_id)
    {
        $sql = 'SELECT name,customer_code,tinno,mobile,phone,address1,'.
               'address2,city,pincode,vechicle_code,user_id FROM customer '.
               ' WHERE customer_id='.$customer_id ;

        return $this->db->query($sql)->row_array();
    }

}