<?php

class Dashboard_Model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function last_30days_sales()
    {
       $data = array();
       $chart_data = array();
       $end_date = date('Y-m-d');
       $end_date_obj = new DateTime($end_date);
       $start_date_obj = date_modify($end_date_obj, '-30 days');
       $start_date = date_format($start_date_obj,'Y-m-d');
       $sql = 'SELECT IFNULL(SUM(total_qty),0) AS sales_qty,'.
       'IFNULL(SUM(total_amt),0) AS sales_amt, sales_date'.
       ' FROM sales '.
       ' WHERE sales_date BETWEEN "'.$start_date.'" AND "'.$end_date.'"'.
       ' GROUP BY sales_date';
       $result = $this->db->query($sql);
       foreach ($result->result_array() as $row) {
         $data[$row['sales_date']] = $row;
       }
       $chart_data[] = array('Date','Sales Amt', 'Sales Qty');
       for($i=0; $i<30; $i++) {
         $date = new DateTime($start_date);
         $day = ($i>1)?'day':'days';
         $date_obj = date_modify($date,"+{$i} {$day}");
         $date_value = date_format($date_obj,'Y-m-d');
         if(!isset($data[$date_value])) {
           $chart_data[] = array(date_format($date_obj, 'd/m/Y'),0,0);
         }
         else {
           $chart_data[] = array(
             date_format($date_obj, 'd/m/Y'),
             floatval($data[$date_value]['sales_amt']),
             floatval($data[$date_value]['sales_qty'])
           );
         }
       }
       return $chart_data;
    }

    public function get_yesterday_sales()
    {
      $date = date('Y-m-d');
      $date_obj = new DateTime($date);
      $start_date_obj = date_modify($date_obj, '-1 day');
      $start_date = date_format($start_date_obj,'Y-m-d');
      $data = $this->get_data($start_date);
      return $data;
    }

    public function get_today_sales()
    {
      $date = date('Y-m-d');
      $data = $this->get_data($date);
      return $data;
    }

    private function get_data($date)
    {
      $data = array();
      $sql = 'SELECT itm.item_name, SUM(si.qty) AS sales_qty,
       SUM(si.total) AS sales_total FROM sales_item AS si
       JOIN sales AS sale ON sale.sales_id = si.sales_id
       JOIN item AS itm ON si.item_id=itm.item_id
       WHERE sale.sales_date BETWEEN "'.$date.'" AND "'.$date.'"
       GROUP BY itm.item_id';
       $result = $this->db->query($sql);
       foreach ($result->result() as $row) {
         $data[] = array(
           $row->item_name,
           $row->sales_qty,
           $row->sales_total
         );
       }
       return $data;
    }

    public function get_counts()
    {
      $data = array();
      $data['customers'] = $this->db->count_all('customer');
      $data['new_customers'] = $this->get_new_customers();
      $data['total_items'] = $this->db->count_all('item');
      $data['total_sales'] = $this->today_sales();
      return $data;
    }

    private function get_new_customers()
    {
        $start_date =strtotime(date('Y-m-d').'00:00:00');
        $end_date =strtotime(date('Y-m-d').'23:59:59');
        $sql = 'SELECT COUNT(*) AS cnt FROM customer
         WHERE mtime <= '.$end_date.' AND mtime >= '.$start_date;
        $result = $this->db->query($sql);
        if($result->num_rows() > 0) {
            $row = $result->row_array();
            return $row['cnt'];
        }
        return 0;
    }

    private function today_sales()
    {
      $date = date('Y-m-d');
      $sql = 'SELECT IFNULL(SUM(net_amt),0) AS total_amt FROM sales
      WHERE sales_date="'.$date.'"';
      $result = $this->db->query($sql)->row();
      return number_format($result->total_amt,2);
    }


}
