<?php

class Login_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }    
    
    public function authenticate($params)
    {
       $data = array();
       $data['status']=FALSE;
       $data['msg']="Invalid Email / Password";
       $sql='SELECT * FROM user_login WHERE email=? AND password=? AND user_role="Admin"';	    	    
       $result =$this->db->query($sql,array(
            $params['email'],$params['password']
       ));      

       if($result->num_rows()>0) {
          $row = $result->row_array(); 
    		  if($row['status']){
    		      $data['status'] = TRUE;
              $data['result']['user_id'] =$row['user_id'];
              $data['result']['email'] =$row['email'];
              $data['result']['user_role'] =$row['user_role'];
    		  }
    		  else {
    		      $data['status']=FALSE;
              $data['msg']="Accout is Blocked Contact Administrator";
    		  }          
       }      
       return $data;   
    }

    public function get_profile($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Invalid details.';
        $sql = 'SELECT user_id,user_name,config_key,mobile FROM user_login '.
        ' WHERE email=? AND password=?';

       $result =$this->db->query($sql,array(
            $params['email'],$params['password']
       ));

       if($result->num_rows()>0) {
          $data =  $result->row_array();
          $data['status'] = 1; 
          $data['msg'] = '';
          $this->register_user($params,$data);
       }

       return $data;
    }  

    private function register_user($params, $data)
    {
        $user = $this->db->get_where('user_vechicle_map',array(
            'user_id'=>$data['user_id'],
            'vechicle_code'=>$params['vechicle_code']
        ));
        $this->db->update('user_vechicle_map', array('status'=>0), 
              array('api_key'=>$data['config_key'])
        );
        if($user->num_rows()==0) {            
            $insert = array();
            $insert['user_id'] = $data['user_id'];
            $insert['vechicle_code'] = $params['vechicle_code'];
            $insert['mtime'] = time();
            $insert['api_key'] = $data['config_key'];
            $this->db->insert('user_vechicle_map', $insert);            
        }
        else if($user->num_rows()>0) {          
          $this->db->update(
                'user_vechicle_map', 
                array('status'=>1), 
                array(
                    'user_id'=>$data['user_id'],
                    'vechicle_code'=>$params['vechicle_code']
                )
          );
        }
    }

}

 