<?php

class Salesrep_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
   
       public function get_customer()
       {
       	$sql= "Select customer_id,name from customer";

       	return $this->db->query($sql)
    			->result_array();
       }

       public function get_item()
       {
    	$sql= "Select item_id,item_name from item";

       	return $this->db->query($sql)
    			->result_array();
       }

    	public function get_vechicle()
       {
    	$sql= "Select vechicle_id,vechicle_code from vechicle";

       	return $this->db->query($sql)
    			->result_array();
       }

      public function search($params)
      {
        $result = array();
        $where =" ";

      	$sql ="SELECT sales_id,
            sales_no,CONCAT(sales.vechicle_code,'/',sales_no) AS billno, sales_date,sales.vechicle_code,mode_of_pay,form_type,cus.name,total_amt,kvat_amt,disc_amt,round_off,net_amt,sales.mtime FROM sales 
            INNER JOIN customer cus ON cus.customer_id=sales.customer_id WHERE 1=1 ";
         
         if(!empty($params['from_date']) && !empty($params['to_date'])) {
    	 			$where .= ' AND sales_date BETWEEN "'.$params['from_date'].'" AND "'.$params['to_date'].'"';
    			}
         
         if(!empty($params['customer_id'])){
          $where .= ' AND sales.customer_id ="'.$params['customer_id'].'"';
         }

         if(!empty($params['vehicle'])){
          $where .= ' AND sales.vechicle_code ="'.$params['vehicle'].'"';
         }

         if(!empty($params['mode_of_pay'])){
          $where .= ' AND sales.mode_of_pay ="'.$params['mode_of_pay'].'"';
         }

        if(!empty($params['form_type'])){
          $where .= ' AND sales.form_type ="'.$params['form_type'].'"';
         }

          $sql .= $where ;
     			$sql .= ' ORDER BY sales.vechicle_code,sales_no,sales_date';

    	   $result['result'] = $this->db->query($sql)->result_array();

         $total_sql="SELECT SUM(total_amt) AS total_amt,SUM(kvat_amt) AS kvat_amt,SUM(disc_amt) AS disc_amt,SUM(round_off) AS round_off, SUM(CASE WHEN mode_of_pay='Cash' THEN net_amt ELSE 0 END) AS net_cash,SUM(CASE WHEN mode_of_pay='Credit' THEN net_amt ELSE 0 END) AS net_credit FROM sales WHERE 1=1 ";
         
         $total_sql .= $where ;

         $result['total'] = $this->db->query($total_sql)->row_array();

    		return $result;
      }

    public function itemwise($params)
    {
      $result = array();
      $where =" ";

      $sql ="SELECT s.sales_Date,s.vechicle_code,i.item_name,stk.opening_qty AS opening,stk.input_qty AS input,stk.opening_qty+stk.input_qty as loaded,SUM(sitem.qty) AS sales,SUM(sitem.total) AS total_amt,stk.opening_qty+stk.input_qty-SUM(sitem.qty) AS closing  FROM `sales_item` AS sitem 
        JOIN sales s on sitem.sales_id=s.Sales_id
        JOIN item i ON i.item_id=sitem.item_id
        JOIN vechicle_stock_input stk ON stk.vechicle_code=s.vechicle_code AND stk.input_date=s.sales_date AND stk.item_id=sitem.item_id WHERE 1=1 ";

       if(!empty($params['from_date']) && !empty($params['to_date'])) {
          $where .= ' AND s.sales_date BETWEEN "'.$params['from_date'].'" AND "'.$params['to_date'].'"';
        }
       
       if(!empty($params['customer_id'])){
        $where .= ' AND s.customer_id ="'.$params['customer_id'].'"';
       }

       if(!empty($params['vehicle'])){
        $where .= ' AND s.vechicle_code ="'.$params['vehicle'].'"';
       }

       if(!empty($params['mode_of_pay'])){
        $where .= ' AND s.mode_of_pay ="'.$params['mode_of_pay'].'"';
       }

      if(!empty($params['form_type'])){
        $where .= ' AND s.form_type ="'.$params['form_type'].'"';
       }

        $sql .= $where ;
        $sql .= ' GROUP BY s.sales_date,s.vechicle_code,i.item_name ';

      $cql ="SELECT s.sales_Date,s.vechicle_code,i.item_name,stk.opening_qty AS opening,stk.input_qty AS input,stk.opening_qty+stk.input_qty as loaded,SUM(sitem.qty) AS sales,SUM(sitem.total) AS total_amt,stk.opening_qty+stk.input_qty-SUM(sitem.qty) AS closing  FROM `sales_item` AS sitem 
        JOIN sales s on sitem.sales_id=s.Sales_id
        JOIN item i ON i.item_id=sitem.item_id
        JOIN archive_vechicle_stock_input_2017 stk ON stk.vechicle_code=s.vechicle_code AND stk.input_date=s.sales_date AND stk.item_id=sitem.item_id WHERE 1=1 ";

      $cql .= $where ;
      $cql .= ' GROUP BY s.sales_date,s.vechicle_code,i.item_name ';

      $bql = $sql.' UNION '.$cql;

      $result['result'] = $this->db->query($bql)->result_array();

       $total_sql="SELECT SUM(total_amt) AS total_amt,SUM(kvat_amt) AS kvat_amt,SUM(disc_amt)*-1 AS disc_amt,SUM(round_off) AS round_off, SUM(net_amt) AS net_amt FROM sales AS s WHERE 1=1 ";
       
       $total_sql .= $where ;

       $result['total'] = $this->db->query($total_sql)->row_array();

      return $result;
    }

     public function stockreport($params)
      {
        $result = array();
        $where =" ";

        $sql ="SELECT stk.input_date,i.item_name,SUM(stk.opening_qty) AS opening,SUM(stk.input_qty) AS input,SUM(stk.opening_qty+stk.input_qty) as loaded FROM `vechicle_stock_input` AS stk 
          JOIN item AS i ON i.item_id=stk.item_id WHERE 1=1 ";

         if(!empty($params['date'])) {
            $where .= ' AND input_date="'.$params['date'].'"';
          }

         if(!empty($params['vehicle'])){
          $where .= ' AND stk.vechicle_code ="'.$params['vehicle'].'"';
         }

          $sql .= $where ;
          $sql .= ' GROUP BY i.item_name,stk.input_date ';
          
         $cql ="SELECT stk.input_date,i.item_name,SUM(stk.opening_qty) AS opening,SUM(stk.input_qty) AS input,SUM(stk.opening_qty+stk.input_qty) as loaded FROM `archive_vechicle_stock_input_2017` AS stk 
          JOIN item AS i ON i.item_id=stk.item_id WHERE 1=1 ";

        $cql .= $where ;
        $cql .= ' GROUP BY i.item_name,stk.input_date ';

        $bql = $sql.' UNION '.$cql; 
        $result['result'] = $this->db->query($bql)->result_array();

        return $result;
      }

}
