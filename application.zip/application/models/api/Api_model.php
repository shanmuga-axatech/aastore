<?php

class Api_Model extends CI_Model
{
    private $sRawDumpTable;
    public function __construct()
    {
        parent::__construct();
        $this->sRawDumpTable = 'raw_dump_archive_'.date('Y');
    }

    public function getData()
    {
        $aData = $this->getPostData();
        if(!empty($aData) && ! $this->isValidRequest($aData)) {
            $aData = array();
        }
        if(empty($aData)) {
            $aData = array();
            $aData['status'] = false;
            $aData['msg'] = 'Invalid Request';
        }
        else {
             $aData['status'] = true;
        }
        return $aData;
    }

    private function getPostData()
    {
        $jsonData = $this->input->input_stream(null, true);
        $aData = json_decode($jsonData, true);
        $sMsg = json_last_error_msg();
        if(!$sMsg || $sMsg != 'No Error') {
            $aData = array();
            return $aData;
        }
        
        $this->saveRawDump($aData);

        return $aData;
    }

    private function isValidRequest()
    {
        return true;
    }

    private function saveRawDump($jsonData)
    {
        $this->checkCreateTable();
        $insert = array();
        $insert['user_id'] = $jsonData['user_id'];  
        $insert['api_key'] = $jsonData['api_key'];
        $insert['json_dump'] = serialize($jsonData);
        $insert['mtime'] = time();
        $this->db->insert($this->sRawDumpTable, $insert);
    }

    private function checkCreateTable()
    {
        if(!$this->db->table_exists($this->sRawDumpTable)) {
            $sql = "CREATE TABLE `{$this->sRawDumpTable}` (
            `archive_id` int unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` int NOT NULL,
            `api_key` char(16) NOT NULL,
            `json_dump` varchar(1000) NULL,
            `mtime` int NOT NULL
            ) ENGINE='ARCHIVE'";
            $this->db->query($sql);
        }
    }


}