<?php
class Tallyapi_model extends CI_Model
{
	const CODE_LENGTH = 10;
	const NAME_LENGTH = 40;
	const PLACE_LENGTH = 120;
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get_customer_details($aCustomerIds)
	{
		$data = array();
		
		if(!empty($aCustomerIds)) 
			$this->db->where_in('customer_id', array_unique($aCustomerIds));
		
		$result=$this->db->get('master_customer');
		
		if($result) {
			foreach ($result->result_array() as $aRow) {
				$data[$aRow['customer_id']] = $aRow;
			}
		} 		
		
		return $data;
	}
	
	public function get_customer($params)
	{

		$data = array();
		$sSql = '';		
		
		$sSql = "SELECT c.name,
					    c.tinno,
					    c.mobile,
					    c.address1,
					    c.address2,
					    c.pincode,
					    eso.vechicle_code
				 FROM sales AS eso
				 JOIN customer AS c
				 ON c.customer_id = eso.customer_id
				 WHERE 1=1 ";
		
		if(isset($params['start']) && !empty($params['start']) &&
				isset($params['end']) && !empty($params['end'])) {
			$sSql .= " AND eso.sales_date BETWEEN '{$params['start']}' AND '{$params['end']}'";
		}
		
		if(isset($params['financial_year'])) {
			$sSql .= ' AND eso.financial_year='.$this->db->escape($params['financial_year']);
		}
				
		$sSql .= ' GROUP BY c.name,c.tinno,c.mobile,c.address1,c.address2,
		           c.pincode,eso.vechicle_code ORDER BY c.name ASC';
				
		$result = $this->db->query($sSql);
		
		if($result) {
			$data = $result->result_array();
		}	

		return $data;	
	}

	public function customer_sdf_format($params)
	{
		$sn = 1;
		$mCode1='';
		$mCode2= '';
		$sData = '';
		
       $aCustomers=$this->get_customer($params);

		foreach ($aCustomers as $aRow) {
				
			$aRow['address1'] = $aRow['address1'];
			$aRow['address2'] = $aRow['address2'];
			$aRow['state']	  = 'Kerala'; //$aRow['district'];
				
			if($sn <= 9) {
				$mCode1 = "ULE00000{$sn}1";
				$mCode2 = "ULE00000{$sn}2";
			}
			else if($sn > 9 && $sn <= 99) {
				$mCode1 = "ULE0000{$sn}1";
				$mCode2 = "ULE0000{$sn}2";
			}
			else if($sn > 99 && $sn <=999) {
				$mCode1 = "ULE000{$sn}1";
				$mCode2 = "ULE000{$sn}2";
			}
			else if($sn > 999 && $sn <= 9999){
				$mCode1 = "ULE00{$sn}1";
				$mCode2 = "ULE00{$sn}2";
			}
				
			$sData .= $mCode1;
			$sData .= str_pad('', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['name'].PHP_EOL;
				
			$sData .= $mCode1;
			$sData .= str_pad('Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['address1'].PHP_EOL;
				
			$sData .= $mCode1;
			$sData .= str_pad('Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['address2'].PHP_EOL;
				
			$sData .= $mCode1;
			$sData .= str_pad('Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['mobile'].PHP_EOL;
				
			$sData .= $mCode1;
			$sData .= str_pad('MailingName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['name'].PHP_EOL;

			$sData .= $mCode1;
			$sData .= str_pad('CountryofResidence', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'India'.PHP_EOL;

			$sData .= $mCode1;
			$sData .= str_pad('LedStateName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['state'].PHP_EOL;						

			$sData .= $mCode1;
			$sData .= str_pad('PIN Code', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['pincode'].PHP_EOL;
				
			$sData .= $mCode1;
			$sData .= str_pad('IsBillWiseOn', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Yes'.PHP_EOL;
				
		/*	$sData .= $mCode1;
			$sData .= str_pad('InterState STNumber', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['cst_no'].PHP_EOL;*/
				
            if(STRLen($aRow['tinno'])>=10){
			  $sData .= $mCode1;
			  $sData .= str_pad('VATDealerType', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			  $sData .= 'Regular'.PHP_EOL;            

			  $sData .= $mCode1;
			  $sData .= str_pad('VAT TIN Number', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			  $sData .= $aRow['tinno'].PHP_EOL;
			}
				
			$sData .= $mCode1;
			$sData .= str_pad('Parent', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Sundry Debtors'.PHP_EOL;
				
			$sData .= $mCode1;
			$sData .= str_pad('Language Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= ''.PHP_EOL;
				
			$sData .= $mCode2;
			$sData .= str_pad('Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['name'].PHP_EOL;
				
			$sData .= $mCode2;
			$sData .= str_pad('Language Id', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '1033'.PHP_EOL;
		
			$sn++;
		}
		
		return $sData;
	}
	
	public function get_item_details($aItemIds)
	{
		$data = array();
		
		if(!empty($aItemIds))
			$this->db->where_in('item_id', array_unique($aItemIds));
		
		$result=$this->db->get('item');
		
		if($result) {
			foreach ($result->result_array() as $aRow) {
				$data[$aRow['item_id']] = $aRow;
			}
		}

		return $data;
	}

	public function get_item_group($params)
	{

		$data = array();
		$sSql = '';		
		
		$sSql = "SELECT c.category_name AS name
				 FROM category AS c";
				 				
		$result = $this->db->query($sSql);
		
		if($result) {
			$data = $result->result_array();
		}	

		return $data;	
	}

	public function get_items($params)
	{

		$data = array();
		$sSql = '';		
		
		$sSql = "SELECT i.item_name,
					    i.item_code,
					    i.mrp,
					    i.tax_per,
					    c.category_name,
					    c.category_id
				 FROM item AS i
				 JOIN category AS c
				 ON c.category_id = i.category_id ";
				 				
		$result = $this->db->query($sSql);
		
		if($result) {
			$data = $result->result_array();
		}	

		return $data;	
	}

	public function item_sdf_format($params)
	{
		$sn = 1;
		$mCode1='';
		$mCode2= '';
		$sData = '';
	
		$aItemGrp=$this->get_item_group($params);	

		foreach ($aItemGrp as $aRow) {
		
			if($sn <= 9) {
				$mCode1 = "USG00000{$sn}1";
				$mCode2 = "USG00000{$sn}2";
			}
			else if($sn > 9 && $sn <= 99) {
				$mCode1 = "USG0000{$sn}1";
				$mCode2 = "USG0000{$sn}2";
			}
			else if($sn > 99 && $sn <=999) {
				$mCode1 = "USG000{$sn}1";
				$mCode2 = "USG000{$sn}2";
			}
			else if($sn > 999 && $sn <= 9999){
				$mCode1 = "USG00{$sn}1";
				$mCode2 = "USG00{$sn}2";
			}

			$sData .= $mCode1;
			$sData .= str_pad('', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['name'].PHP_EOL;

			$sData .= $mCode1;
			$sData .= str_pad('Is Addable', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Yes'.PHP_EOL;

			$sData .= $mCode1;
			$sData .= str_pad('Language Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= ''.PHP_EOL;
		
			$sData .= $mCode2;
			$sData .= str_pad('Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['name'].PHP_EOL;
		
			$sData .= $mCode2;
			$sData .= str_pad('Language Id', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '1033'.PHP_EOL;		
			$sn++;
        }

		$sn = 1;
		$mCode1='';
		$mCode2= '';	

	    $aItems=$this->get_items($params);

		foreach ($aItems as $aRow) {
		
			if($sn <= 9) {
				$mCode1 = "USI00000{$sn}1";
				$mCode2 = "USI00000{$sn}2";
			}
			else if($sn > 9 && $sn <= 99) {
				$mCode1 = "USI0000{$sn}1";
				$mCode2 = "USI0000{$sn}2";
			}
			else if($sn > 99 && $sn <=999) {
				$mCode1 = "USI000{$sn}1";
				$mCode2 = "USI000{$sn}2";
			}
			else if($sn > 999 && $sn <= 9999){
				$mCode1 = "USI00{$sn}1";
				$mCode2 = "USI00{$sn}2";
			}
		
			$sData .= $mCode1;
			$sData .= str_pad('', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['item_name'].PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Parent', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['category_name'].PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Costing Method', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Avg. Cost'.PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Valuation Method', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Avg. Price'.PHP_EOL;

		    $uom = 'Kg';
		    if($aRow['category_id'] == '20')
		    {	    	
		     $uom = 'Pct';
		    }

			$sData .= $mCode1;
			$sData .= str_pad('Base Units', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $uom.PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Sort Position', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '0'.PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Denominator', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '1'.PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Rate of MRP', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['mrp'].PHP_EOL;
		
			$sData .= $mCode1;
			$sData .= str_pad('Rate of VAT', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['tax_per'].PHP_EOL;
			
			$sData .= $mCode1;
			$sData .= str_pad('Language Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= ''.PHP_EOL;
		
			$sData .= $mCode2;
			$sData .= str_pad('Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['item_name'].PHP_EOL;
		
			$sData .= $mCode2;
			$sData .= str_pad('Language Id', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '1033'.PHP_EOL;		
			$sn++;
		}
		
		return $sData;
	}
	
	public function get_sales_details($params)
	{
		$data = array();
		$sSql = '';		
		
		$sSql = "SELECT eso.sales_id,eso.sales_no,
					 eso.sales_date,
					 eso.financial_year,
					 eso.iscancel,
					 eso.vechicle_code AS vechicle,
					 eso.mtime,
                     eso.mode_of_pay,
                     eso.form_type,
					 eso.total_amt,
					 eso.net_amt AS net_amount,
					 eso.kvat_amt,
					 eso.disc_amt,
					 eso.round_off,
					 eso.net_amt - (eso.total_amt + eso.kvat_amt - eso.disc_amt) AS diff,
					 customer.*
				 FROM sales AS eso
				 JOIN customer AS customer 
				 ON customer.customer_id = eso.customer_id
				 WHERE 1=1 AND net_amt>=1 AND form_type='FORM-8' ";
			
		
		if(isset($params['start']) && !empty($params['start']) &&
				isset($params['end']) && !empty($params['end'])) {
			$sSql .= " AND eso.sales_date BETWEEN '{$params['start']}' AND '{$params['end']}'";
		}
		
		if(isset($params['customer_id'])) {
			$sSql .= ' AND customer.customer_id='.$this->db->escape($params['customer_id']);
		}
		
		if(isset($params['status'])) {
			$sSql .= ' AND eso.status='.$this->db->escape($params['status']);
		}
		
		if(isset($params['financial_year'])) {
			$sSql .= ' AND eso.financial_year='.$this->db->escape($params['financial_year']);
		}
				
		$sSql .= ' GROUP BY sales_id ORDER BY eso.vechicle_code,eso.sales_date,eso.sales_no ASC';
				
		$result = $this->db->query($sSql);
		
		if($result) {
			$data = $result->result_array();
		}
		
		return $data;		
	}	
	
	public function get_order_data($params)
	{
		$data = array();
		$result = $this->get_sales_details($params);		
		if(!empty($result)) {
			foreach ($result as $aRow) {				
				$data['aData'][$aRow['sales_id']] = $aRow; 
			}
		}		
		return $data;
	}
	
	public function get_item_ids($params)
	{		
		$data = array();
		$data['item'] = array();
		$data['aData'] = array();
		
		if(!empty($params))
			$this->db->where_in('sales_id', $params);
		
		$result=$this->db->get('sales_item');
		
		if($result) {			
			foreach ($result->result_array() as $aRow) {
				$data['item'][] = $aRow['item_id'];
				$data['aData'][$aRow['sales_id']][] = $aRow;
			}			
		}

		return $data;
	}
	
	public function sales_sdf_format($aData, $aOrderItemEntry)
	{
		$sn = 1;
		$mCode1='';
		$mCode2= '';
		$sData = '';

		foreach ($aData['aData'] as $iOrderId => $aRow) {
			
			$aProps = array();			
		
			if($sn <= 9) {
				$aProps['mCode1'] = "UVO00000{$sn}1";
				$aProps['mCode2'] = "UVO00000{$sn}2";
				$aProps['mCode3'] = "UVO00000{$sn}3";
			}
			else if($sn > 9 && $sn <= 99) {
				$aProps['mCode1'] = "UVO0000{$sn}1";
				$aProps['mCode2'] = "UVO0000{$sn}2";
				$aProps['mCode3'] = "UVO0000{$sn}3";
			}
			else if($sn > 99 && $sn <=999) {
				$aProps['mCode1'] = "UVO000{$sn}1";
				$aProps['mCode2'] = "UVO000{$sn}2";
				$aProps['mCode3'] = "UVO000{$sn}3";
			}
			else if($sn > 999 && $sn <= 9999){
				$aProps['mCode1'] = "UVO00{$sn}1";
				$aProps['mCode2'] = "UVO00{$sn}2";
				$aProps['mCode3'] = "UVO00{$sn}3";
			}
						
			$aProps['sn'] = $sn;
		
			$sData .= $this->_sales_basic_details($aProps, $aRow);			
			$sData .= $this->_sales_customer_details($aProps, $aRow);
			$sData .= $this->_sales_tax_details($aProps, $aRow);
			
			$aItemEntries = array();
			
			if(isset($aOrderItemEntry['aData'][$iOrderId])) {
				$aItemEntries = $aOrderItemEntry['aData'][$iOrderId];
			}

			foreach ($aItemEntries as $aItemSales) {
								
				$sData .= $this->_sales_item_details(
					$aProps, 
					$aItemSales, 
					$aData['aItemData'][$aItemSales['item_id']],
					$aRow	
				);
				
				$sData .= $this->_sales_item_tax_details($aProps, $aItemSales);
			}
		
			$sn++;
		}
		
		return $sData;
	}
	
	private function _sales_basic_details($aProps,$aRow)
	{
		$sData = '';
		
		$aRow['address1'] = $aRow['address1'];
		$aRow['address2'] = $aRow['address2'];
		$aRow['state']	  = 'Kerala'; //$aRow['district'];
		
		//address
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['address1'].PHP_EOL;
		
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['address2'].PHP_EOL;
		
		//basic buyer address
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Basic  Buyer Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['address1'].PHP_EOL;
		
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Basic  Buyer Address', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['address2'].PHP_EOL;
		
		//order date
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Date', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= date('Ymd', strtotime($aRow['sales_date'])).PHP_EOL;
		
		//state name
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('LedStateName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['state'].PHP_EOL;

		//PartyName
		$aRow['partyname']=($aRow['mode_of_pay'] == 'Cash' ? 'Cash' : $aRow['name']);

		$sData .= $aProps['mCode1'];
		$sData .= str_pad('PartyName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['partyname'].PHP_EOL;
		
		//Voucher Type Name
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Voucher Type Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);		
		$sData .= $aRow['vechicle'].PHP_EOL;

  		$vechicle= SUBSTR(TRIM($aRow['vechicle']),0,2);
  		$vechicle = strtoupper($vechicle);			
		//Reference
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Reference', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $vechicle.'/'.$aRow['sales_no'].PHP_EOL;
		

  		//Voucher Number
  		$sData .= $aProps['mCode1'];
  		$sData .= str_pad('Voucher Number', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
  		$sData .= $vechicle.'/'.$aRow['sales_no'].PHP_EOL;
		
		//Party Ledger Name
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Party Ledger Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['partyname'].PHP_EOL;
		
		//Basic Base Party Name
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Basic Base Party Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['partyname'].PHP_EOL;
		
		//Basic Buyer Name
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Basic Buyer NAme', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['name'].PHP_EOL;
		
		//Basic Buyers Sales tax No
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Basic Buyers Sales tax No', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['tinno'].PHP_EOL;
		
		//Effective Date
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Effective Date', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= date('Ymd', strtotime($aRow['sales_date'])).PHP_EOL;
		
		//Is Invoice
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Is Invoice', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Yes'.PHP_EOL;

		return $sData;
	}
	
	private function _sales_customer_details($aProps,$aRow)
	{
		$sData = '';
		
		$aRow['partyname']=($aRow['mode_of_pay'] == 'Cash' ? 'Cash' : $aRow['name']);

		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Ledger Entries', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= ''.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('LedgerName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['partyname'].PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Is Deemed Positive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Yes'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('IsPartyLedger', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Yes'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('IsLastDeemedPositive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Yes'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= '-'.$aRow['net_amount'].PHP_EOL;		
		
		return $sData;
	}
	
	private function _sales_tax_details($aProps,$aRow)
	{
		$sData = '';
		
		//Output Tax
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('Ledger Entries', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= ''.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Basic  Rate Of Invoice Tax', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= '5'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('LedgerName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Output Vat @ 5%'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Is Deemed Positive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('IsPartyLedger', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('IsLastDeemedPositive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['kvat_amt'].PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('VATExpAmount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['kvat_amt'].PHP_EOL;

      if($aRow['disc_amt']!=0)
       {
			//Discount
			$sData .= $aProps['mCode1'];
			$sData .= str_pad('Ledger Entries', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= ''.PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('LedgerName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Discount'.PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('Is Deemed Positive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'NO'.PHP_EOL;
				
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('IsLastDeemedPositive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'NO'.PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '-'.$aRow['disc_amt'].PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('VATExpAmount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= '-'.$aRow['disc_amt'].PHP_EOL;
        }

     if($aRow['diff']!=0)
       {
			//Round Off
			$sData .= $aProps['mCode1'];
			$sData .= str_pad('Ledger Entries', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= ''.PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('LedgerName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'Round Off'.PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('Is Deemed Positive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'No'.PHP_EOL;
				
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('IsLastDeemedPositive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= 'No'.PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['diff'].PHP_EOL;
			
			$sData .= $aProps['mCode2'];
			$sData .= str_pad('VATExpAmount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
			$sData .= $aRow['diff'].PHP_EOL;
        }

		return $sData;
	}
	
	//$aProps, $aItemSales, $aItemEntries[$aItemSales['item_id']]
	private function _sales_item_details($aProps, $aSales, $aItem, $aRow)
	{
		$sData = '';
		
		$sData .= $aProps['mCode1'];
		$sData .= str_pad('ALL Inventory Entries', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= ''.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Stock Item Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aItem['item_name'].PHP_EOL;

        $uom = 'Kg';

		 if($aItem['category_id'] == '20')
		{	    	
		     $uom = 'Pct';
		}
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Is Deemed Positive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('IsLastDeemedPositive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Rate', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['rate'].'/'.$uom.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['total'].PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Actual Qty', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['qty'].' '.$uom.PHP_EOL;
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Billed Qty', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['qty'].' '.$uom.PHP_EOL;
				
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Batch Allocations', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= ''.PHP_EOL;
		
  		$vechicle= SUBSTR(TRIM($aRow['vechicle']),0,2);
  		$vechicle = strtoupper($vechicle);	
  				
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Godown Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aRow['vechicle'].PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Batch Name', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Primary Batch'.PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('OrderNo', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $vechicle.'/'.$aRow['sales_no'].PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['total'].PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Actual Qty', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['qty'].' '.$uom.PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Billed Qty', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['qty'].' '.$uom.PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('OrderDueDate', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= date('d-M-Y', strtotime($aRow['sales_date'])).PHP_EOL;
		
		return $sData;
	}
	
	private function _sales_item_tax_details($aProps, $aSales)
	{
		$sData = '';
		
		$sData .= $aProps['mCode2'];
		$sData .= str_pad('Accounting Allocations', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= ''.PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('LedgerName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Sales Taxable 5%'.PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('StatNatureName', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'Sales Taxable'.PHP_EOL;
		               
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Is Deemed Positive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;
		
		$sData .= $aProps['mCode3'];
		$sData .= str_pad('IsLastDeemedPositive', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= 'No'.PHP_EOL;

		$sData .= $aProps['mCode3'];
		$sData .= str_pad('VATTaxRate', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= '5'.PHP_EOL;

		$sData .= $aProps['mCode3'];
		$sData .= str_pad('Amount', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['total'].PHP_EOL;	

		$sData .= $aProps['mCode3'];
		$sData .= str_pad('VAT Assessable Value', self::NAME_LENGTH,' ',STR_PAD_RIGHT);
		$sData .= $aSales['total'].PHP_EOL;	
		
		return $sData;
	}
}