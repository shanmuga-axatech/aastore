<?php

class V1_Model extends CI_Model
{
    private $api_details;
    private $sales_status = false;
    private $receipt_status = false;
    private $data = array();
    public function __construct()
    {
        parent::__construct();
        $this->data['sales']  =array();
        $this->data['sales_item'] = array();
    }

    public function archive($params)
    {
        $data = array();
        $data['status'] = 1;
        $data['msg'] = 'Archive created successfully.';
        $data['api_key'] = $this->get_api_key_code($params);
        return $data;
    }

    public function items($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Failed to pull the items.';
        $data['code'] = $this->get_api_key_code($params);
        $data['data'] = array();
        if($data['code']=='611116') {
            $mtime = empty($this->api->mtime)?time():$this->api->mtime;
            $input_date = date('Y-m-d', $mtime);
            $sql = 'SELECT item.item_code,
            item.item_name,
            item.category_id,
            item.mrp,
            item.retail_price,
            cate.hsncode,
            cate.igstper as tax_per,
            item.whole_sale_price,
            stock.opening_qty,
            stock.input_qty,
            stock.closing_qty AS qty,
            stock.input_date,
            stock.stock_input_id AS input_id,
            stock.mtime
            FROM vechicle_stock_input AS stock
            JOIN item ON item.item_id = stock.item_id
            JOIN category AS cate ON cate.category_id = item.category_id
            WHERE stock.closing_qty > 0 AND
            stock.vechicle_code=? AND stock.input_date = ?';
            $result = $this->db->query($sql, array(
                $this->api_details->vechicle_code,$input_date
            ));
            foreach($result->result_array() as $row) {
                $data['data'][] = $row;
            }
            $data['status'] = 1;
            $data['msg'] = '';
        }
        return $data;
    }

    public function customer($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Failed update the customer data.';
        $data['code'] = $this->get_api_key_code($params);
        $data['data'] = array();
        if($data['code']=='611116') {
            $aCustomer = json_decode($params['data'], true);
            foreach($aCustomer as $customer) {
                $item = array();
                $item['customer_id'] = $customer['customer_id'];
                $result = $this->db->get_where('customer', array(
                    'customer_code'=>$customer['customer_code']
                ));
                if($result->num_rows()==0) {
                    $item['remote_customer_id'] = $this->update_customer(
                        $customer,0
                    );
                }
                else{
                    $row = $result->row();
                    $item['remote_customer_id'] = $this->update_customer(
                        $customer,$row->customer_id
                    );
                }
                $data['status'] = 1;
                $data['msg'] = '';
                $data['data'][] = $item;
            }
        }
        return $data;
    }

    public function pull_customer($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Failed to pull the customer data.';
        $data['code'] = $this->get_api_key_code($params);
        $data['data'] = array();
        if($data['code']=='611116') {
            $result = $this->db->get_where('customer', array(
                'vechicle_code' => $params['vechicle_code'],
                'customer_id > ' => empty($params['customer_id'])?0:$params['customer_id']
            ));
            if($result->num_rows() > 0) {
                $data['data'] = $result->result_array();
            }
            $data['status'] = 1;
            $data['msg'] = '';
        }
        return $data;
    }

    private function update_customer($params, $customer_id)
    {
        $insert = array();
        $insert['name'] = $params['name'];
    		$insert['tinno'] = $params['tinno'];
    		$insert['customer_code'] = $params['customer_code'];
    		$insert['sales_type'] = $params['sales_type'];
    		$insert['mobile'] = $params['mobile'];
    		$insert['email'] = $params['email'];
    		$insert['address1'] = $params['address1'];
    		$insert['address2'] = $params['address2'];
    		$insert['pincode'] = $params['pincode'];
    		$insert['phone'] = $params['phone'];
    		$insert['city'] = $params['city'];
    		$insert['user_id'] = $params['user_id'];
        $insert['vechicle_code'] = $this->api_details->vechicle_code;
		    $insert['mtime'] = time();
        if($customer_id > 0) {
            $this->db->update('customer', $insert, array(
                'customer_id'=>$customer_id
            ));
        }
        else {
            $this->db->insert('customer',$insert);
            $customer_id = $this->db->insert_id();
        }
        return $customer_id;
    }

    public function sales($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Failed to update the sales.';
        $data['code'] = $this->get_api_key_code($params);
        $data['data'] = array();
        if($data['code']=='611116') {
            $this->db->trans_begin();
            $aParams = json_decode($params['data'], true);
            foreach($aParams['sales'] as $sales) {
                $this->insert_sales($sales, $params['vechicle_code']);
                if(!$this->sales_status) {
                    break;
                }
            }

            if($this->sales_status) {
                $this->delete_sales_items();
                foreach ($aParams['sales_item'] as $sales_item) {
                    if($this->sales_status) {
                       $sales_id = $this->data['sales'][$sales_item['sales_id']]['remote_sales_id'];
                       $this->insert_sales_items($sales_item,$sales_id);
                    }
                    else {
                         break;
                    }
                }
            }

            if(!$this->sales_status || $this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
            }
            else {
                $this->db->trans_commit();
                $data['status'] = 1;
                $data['msg'] = '';
                $data['data'] = $this->data;
            }


        }
        return $data;
    }

    private function insert_sales($params, $vechicle_code)
    {
        $sales_id = $this->get_sales_id(
            $params['sales_no'],$params['sales_date'],$params['form_type'],$vechicle_code
        );
        //format sales date
        $date = explode('/', $params['sales_date']);
        $params['sales_date'] = $date[2].'-'.$date[1].'-'.$date[0];
        $insert = array();
        $insert['sales_no'] = $params['sales_no'];
        $insert['sales_date'] = $params['sales_date'];
        $insert['form_type'] = $params['form_type'];
        $insert['mode_of_pay'] = $params['mode_of_pay'];
        $insert['customer_code'] = $params['customer_code'];
        $insert['outstanding_amt'] = $params['outstanding_amt'];
        $insert['financial_year'] = financial_year($params['sales_date']);
        $insert['user_id'] = $params['user_id'];
        $insert['mtime'] = $params['mtime'];
        $insert['total_qty'] = $params['total_qty'];
        $insert['total_amt'] = $params['total_amt'];
        $insert['kvat_per'] = $params['kvat_per'];
        $insert['kvat_amt'] = $params['kvat_amt'];
        $insert['sub_total'] = $params['sub_total'];
        $insert['disc_per'] = $params['disc_per'];
        $insert['disc_amt'] = $params['disc_amt'];
        $insert['round_off'] = $params['round_off'];
        $insert['net_amt'] = $params['net_amt'];
        $insert['vechicle_code'] = $vechicle_code;
        $insert['customer_id'] = $this->get_customer_id($params['customer_code']);
        if($sales_id > 0) {
            $this->sales_status = $this->db->update('sales',$insert,array(
                'sales_id'=>$sales_id
            ));
        }
        else {
            $this->sales_status = $this->db->insert('sales',$insert);
            $sales_id = $this->db->insert_id();
        }

        if($this->sales_status) {
            $this->data['sales'][$params['sales_id']] = array(
                'sales_id'=>$params['sales_id'],'remote_sales_id'=>$sales_id
            );
        }
        else {
            log_message('error', $this->db->last_query());
        }

    }

    public function get_customer_id($sCode)
    {
        $oCustomer = $this->db->get_where('customer', array(
            'customer_code' => $sCode
        ))->row();
        return $oCustomer->customer_id;
    }

    private function get_sales_id($sales_no,$sales_date,$form_type, $vechicle_code)
    {
        $where = array(
            'sales_no'=>$sales_no,'form_type'=>$form_type,
            'vechicle_code'=>$vechicle_code,
            'financial_year'=>financial_year_app($sales_date)
        );
        $chk = $this->db->get_where('sales', $where);
        if($chk && $chk->num_rows() > 0) {
            $row = $chk->row();
            return $row->sales_id;
        }
        return 0;
    }

    private function delete_sales_items()
    {
        $sales_id = array();
        foreach ($this->data['sales'] as $key => $sales) {
             $sales_id[] = $sales['remote_sales_id'];
        }
        if(!empty($sales_id)) {
            $sSalesId = implode(',', $sales_id);
            $sql = 'DELETE FROM sales_item WHERE sales_id IN('.$sSalesId.')';
            $this->sales_status = $this->db->query($sql);
        }
        else {
            $this->sales_status = false;
        }
    }

    private function insert_sales_items($params,$sales_id)
    {
        $insert = array();
        $item = $this->get_item($params['item_code']);
        $insert['sales_id'] = $sales_id;
        $insert['sales_no'] = $sales_id;
        $insert['item_id'] =  $item->item_id;
        $insert['tax_per'] =  $item->tax_per;
        $insert['item_code'] = $params['item_code'];
        $insert['qty'] = $params['qty'];
        $insert['rate'] = $params['rate'];
        $insert['total'] = $params['total'];
        $insert['user_id'] = $params['user_id'];
        $insert['mtime'] = time();
        $this->sales_status = $this->db->insert('sales_item', $insert);
        if($this->sales_status) {
            $this->data['sales_item'][$params['sales_item_id']] = array(
                'sales_item_id'=>$params['sales_item_id'],
                'remote_sales_item_id'=>$this->db->insert_id()
            );
        }
        else {
            log_message('error', $this->db->last_query());
        }
    }

    private function get_item($item_code)
    {
        $oResult = $this->db->get_where('item', array(
            'item_code'=>$item_code
        ))->row();
        return $oResult;
    }

    public function pull_sales($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Failed to update the sales.';
        $data['code'] = $this->get_api_key_code($params);
        $data['data'] = array();
        if($data['code']=='611116') {

            $sql = "SELECT sales_id AS remote_sales_id,
            form_type,
            sales_no,
            sales_date,
            mode_of_pay,
            customer_code,
            outstanding_amt,
            total_amt,
            total_qty,
            kvat_per,
            kvat_amt,
            sub_total,
            disc_per,
            disc_amt,
            round_off,
            net_amt,
            user_id,
            mtime FROM sales
            WHERE vechicle_code = ?
            AND financial_year = ?
            ORDER BY sales_no DESC LIMIT 1";
            $financial_year = financial_year(date('Y-m-d'));
            $oResult = $this->db->query($sql,array(
                $params['vechicle_code'],  $financial_year
            ));
            $data['status'] = 1;
            $data['msg'] = '';
            if($oResult->num_rows() > 0) {
                $data['data']['sales'] = $oResult->row_array();
                $data['data']['sales']['sales_date'] = date('d/m/Y',strtotime($data['data']['sales']['sales_date']));
                /*$data['data']['sales_item'] = $this->db->get_where('sales_item',array(
                    'sales_id'=>$data['data']['sales']['remote_sales_id']
                ))->result_array();*/
            }
        }
        return $data;
    }
    //-----------------------------------------------------
    public function receipts($params)
    {
        $data = array();
        $data['status'] = 0;
        $data['msg'] = 'Failed to update the receipts.';
        $data['code'] = $this->get_api_key_code($params);
        $data['data'] = array();
        if($data['code']=='611116') {
            $this->db->trans_begin();
            $aParams = json_decode($params['data'], true);
            foreach($aParams['receipts'] as $receipts) {
                $this->insert_receipts($receipts, $params['vechicle_code']);
                if(!$this->receipt_status) {
                    break;
                }
            }

            if(!$this->receipt_status || $this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
            }
            else {
                $this->db->trans_commit();
                $data['status'] = 1;
                $data['msg'] = '';
                $data['data'] = $this->data;
            }
        }
        return $data;
    }

    private function insert_receipts($params, $vechicle_code)
    {
        //format sales date
        $date = explode('/', $params['receipt_date']);
        $params['receipt_date'] = $date[2].'-'.$date[1].'-'.$date[0];

        $receipt_id = $this->get_receipts_id(
            $params['receipt_no'],$params['receipt_date'],$vechicle_code
        );

        $insert = array();
        $insert['receipt_no'] = $params['receipt_no'];
        $insert['receipt_date'] = $params['receipt_date'];
        $insert['mode_of_pay'] = $params['mode_of_pay'];
        $insert['customer_code'] = $params['customer_code'];
        $insert['customer_name'] = $params['customer_name'];
        $insert['financial_year'] = financial_year($params['receipt_date']);
        $insert['user_id'] = $params['user_id'];
        $insert['mtime'] = $params['mtime'];
        $insert['cheque_no'] = $params['cheque_no'];
        $insert['bank_name'] = $params['bank_name'];
        $insert['net_amt'] = $params['net_amt'];
        $insert['vechicle_code'] = $vechicle_code;
        $insert['customer_id'] = $this->get_customer_id($params['customer_code']);
        if($receipt_id > 0) {
            $this->receipt_status = $this->db->update('sales_receipt',$insert,array(
                'receipt_id'=>$receipt_id
            ));
        }
        else if($this->db->insert('sales_receipt',$insert)) {
            $this->receipt_status = true;
            $receipt_id = $this->db->insert_id();
        }
        if($this->receipt_status) {
            $this->data['receipts'][$params['receipt_id']] = array(
                'receipt_id'=>$params['receipt_id'],'remote_receipt_id'=>$receipt_id
            );
        }
        else {
            log_message('error', $this->db->last_query());
        }

    }

    private function get_receipts_id($receipt_no,$receipt_date,$vechicle_code)
    {
        $where = array(
            'receipt_no'=>$receipt_no,
            'vechicle_code'=>$vechicle_code,
            'financial_year'=>financial_year($receipt_date)
        );
        $chk = $this->db->get_where('sales_receipt', $where);
        if($chk && $chk->num_rows() > 0) {
            $row = $chk->row();
            return $row->receipt_id;
        }
        return 0;
    }

    public function pull_receipts($params)
    {
      $data = array();
      $data['status'] = 0;
      $data['msg'] = 'Failed to pull the receipts.';
      $data['code'] = $this->get_api_key_code($params);
      $data['data'] = array();
      if($data['code']=='611116') {
        $sql = 'SELECT receipt_id AS remote_receipt_id,
        receipt_no,
        receipt_date,
        financial_year,
        customer_id,
        customer_code,
        customer_name,
        mode_of_pay,
        cheque_no,
        bank_name,
        net_amt,
        vechicle_code,
        mtime,
        user_id
        FROM sales_receipt
        WHERE vechicle_code=? AND financial_year=?
        ORDER BY receipt_id DESC LIMIT 1';
        $financial_year = financial_year(date('Y-m-d'));
        $oResult = $this->db->query($sql,array(
            $params['vechicle_code'],  $financial_year
        ));
        $data['status'] = 1;
        $data['msg'] = '';
        if($oResult->num_rows() > 0) {
            $data['data']['receipts'] = $oResult->row_array();
            $date = date('d/m/Y',strtotime($data['data']['receipts']['receipt_date']));
            $data['data']['receipts']['receipt_date'] = $date;
        }
      }
      return $data;
    }

    //-----------------------------------------------------
    private function get_api_key_code($params)
    {
        $oResult = $this->db->get_where('user_vechicle_map', array(
            'api_key'=>$params['api_key'],
            'vechicle_code' => $params['vechicle_code'],
            'status' => 1
        ));
        if($oResult->num_rows() == 1) {
            $this->api_details = $oResult->row();
            return '611116';
        }
        return '69996';
    }
    //-----------------------------------------------------

    public function cron($params)
    {
        $startTime = time()-(8*60*60);
        $endTime = time()+(8*60*60);
        $startDate = date('Y-m-d', $startTime);
        //$startDate = '2017-01-20';
        $endDate = date('Y-m-d', $endTime);

        if($startDate==$endDate) {
            log_message('error', 'same day cron attempt');
            return true;
        }
 /*       $sql = 'SELECT stock.input_date,
        stock.item_id,
        stock.item_code,
        stock.batch_no,
        stock.vechicle_id,
        stock.vechicle_code,
        (stock.closing_qty-IFNULL(SUM(si.qty),0)) AS opening_qty,
        stock.user_id
        FROM vechicle_stock_input AS stock
        LEFT JOIN sales_item AS si ON si.item_code=stock.item_code
        LEFT JOIN sales ON sales.sales_date=stock.input_date
            AND sales.vechicle_code = stock.vechicle_code
        WHERE stock.input_date = ?
        GROUP BY stock.vechicle_code,stock.item_code HAVING opening_qty > 0';*/

        $sql ='Select stock.input_date,
        stock.item_id,
        stock.item_code,
        stock.batch_no,
        stock.vechicle_id,
        stock.vechicle_code,
        (stock.closing_qty-IFNULL(ds.salesqty,0)) AS opening_qty,
        stock.user_id
        FROM vechicle_stock_input AS stock
        LEFT JOIN (SELECT sales.sales_date,si.item_code,IFNULL(SUM(si.qty),0) AS salesqty,sales.vechicle_code
        FROM sales_item AS si
        LEFT JOIN sales ON sales.sales_id=si.sales_id
        WHERE sales.sales_date = ?
        GROUP BY sales.sales_date,si.item_code,sales.vechicle_code) AS ds ON
         stock.item_code=ds.item_code AND
         stock.input_date=ds.sales_date AND
         stock.vechicle_code=ds.vechicle_code
         WHERE stock.input_date= ?
         GROUP BY stock.item_code,stock.vechicle_id,stock.vechicle_code';

        $oResult = $this->db->query($sql, array($startDate,$startDate));

        if($oResult->num_rows() > 0) {
            $i=0;
            $aData = array();
            $bstatus = true;
            foreach ($oResult->result() as $row) {
               $aRow = array();
               $aRow['input_date'] = $endDate;
               $aRow['item_id'] = $row->item_id;
               $aRow['item_code'] = $row->item_code;
               $aRow['batch_no'] = $row->batch_no;
               $aRow['vechicle_id'] = $row->vechicle_id;
               $aRow['vechicle_code'] = $row->vechicle_code;
               $aRow['opening_qty'] = $row->opening_qty;
               $aRow['input_qty'] = 0;
               $aRow['closing_qty'] =$row->opening_qty;
               $aRow['entry_type'] = 'cron';
               $aRow['user_id'] = $row->user_id;
               $aRow['mtime'] = time();
               $aData[$i] = $aRow;
               $i++;

               if($i >= 25) {
                    if(!$this->db->insert_batch('vechicle_stock_input',$aData)) {
                        log_message('error', 'failed to execute the query');
                         $bstatus = false;
                        break;
                    }
                    else {
                        $i=0;
                        $aData = array();
                    }
               }
            }

            if(!empty($aData)) {
                if(!$this->db->insert_batch('vechicle_stock_input',$aData)) {
                    log_message('error', 'failed to execute the query');
                    $bstatus = false;
                }
                else {
                    $i=0;
                    $aData = array();
                }
            }

            if($bstatus)
                $this->cleanup();

        }

    }

    private function cleanup()
    {
        $time = time()-(20 * 86400);
        $backup_date = date('Y-m-d',$time);
        $table = $this->stock_archive_table();
        $sql = "INSERT INTO {$table} (`stock_input_id`, `input_date`, `item_id`, `item_code`, `batch_no`, `vechicle_id`, `vechicle_code`, `opening_qty`, `input_qty`, `closing_qty`, `user_id`,`is_completed`, `entry_type`, `mtime`) SELECT * FROM vechicle_stock_input WHERE input_date <= '{$backup_date}'";
        $result = $this->db->query($sql);
        if($result) {
            $sql = "DELETE FROM vechicle_stock_input WHERE input_date <= '{$backup_date}'";
            $this->db->query($sql);
        }
    }

    private function stock_archive_table()
    {
        $year = date('Y');
        $table = 'archive_vechicle_stock_input_'.$year;
        if(!$this->db->table_exists($table)) {
            $sql = "CREATE TABLE IF NOT EXISTS {$table} (
                  `archive_stock_input_id` int(11) NOT NULL AUTO_INCREMENT,
                  `stock_input_id` int(11) NOT NULL,
                  `input_date` date NOT NULL,
                  `item_id` int(11) NOT NULL,
                  `item_code` char(16) NOT NULL,
                  `batch_no` char(16) DEFAULT NULL,
                  `vechicle_id` int(11) NOT NULL,
                  `vechicle_code` char(12) NOT NULL,
                  `opening_qty` decimal(10,3) NOT NULL,
                  `input_qty` decimal(10,3) NOT NULL,
                  `closing_qty` decimal(10,3) NOT NULL,
                  `user_id` int(11) NOT NULL,
                  `is_completed` tinyint(1) DEFAULT 0,
                  `entry_type` enum('manual','cron') NOT NULL DEFAULT 'manual',
                  `mtime` int(11) NOT NULL,
                  PRIMARY KEY (`archive_stock_input_id`)
                ) ENGINE=ARCHIVE DEFAULT CHARSET=latin1";
            $this->db->query($sql);
        }
        return $table;
    }
}
