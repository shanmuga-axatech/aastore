<?php

class Vechicle extends CI_Controller
{
    private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id || $user_role != 'admin')
			redirect(site_url('/login'));
		
		$this->aHead['title'] = 'Vechicle Details';
		$this->aHead['sURLAdd'] = site_url('master/vechicle/add');
		$this->aHead['sURLView'] = site_url('master/vechicle/list-all');
		$this->load->model('master/vechicle_model','vechicle');	
	}

	public function index()
	{
		redirect(site_url('master/vechicle/add'));
	}

	public function add($data = array())
	{
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('vechicle/add', $data);
		$this->load->view('temp/footer');
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		$data = $this->vechicle->save($params);
		$this->add($data);
	}

	public function list_all()
	{
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('vechicle/list');
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$data = array();
		$params =$this->input->post(null, true);
		$data = $this->vechicle->get_records($params);
		echo json_encode($data);
	}

	public function edit($vechicle_id)
	{
		$this->aHead['sActive'] = 'add';
		$data = $this->vechicle->edit($vechicle_id);		
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('vechicle/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['vechicle_id']) && 
			!empty($params['vechicle_id'])) {
			$data = $this->vechicle->update($params);
			$this->add($data);
		}
		else {
			redirect(site_url('master/vechicle/add'));
		}
	}
}