<?php

class Customer extends CI_Controller
{
	private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id || $user_role != 'admin')
			redirect(site_url('/login'));
		
		$this->aHead['title'] = 'Customer';
		$this->aHead['sURLAdd'] = site_url('master/customer/add');
		$this->aHead['sURLView'] = site_url('master/customer/list-all');
		$this->load->model('master/customer_model','customer');	
	}

	public function index()
	{
		redirect(site_url('master/customer/add'));
	}

	public function add($data = array())
	{
		$this->aHead['sActive'] = 'add';
		$data['_SALES_TYPES'] = array(
			'Retail' => 'Retail Sale',
			'Catering'  => 'Catering Sale'
		);
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('customer/add', $data);
		$this->load->view('temp/footer');
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		$params['user_id'] = $this->session->userdata('user_id');
		$data = $this->customer->save($params);
		$this->add($data);
	}

	public function list_all()
	{
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('customer/list');
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$data = array();
		$params =$this->input->post(null, true);
		$data = $this->customer->get_records($params);
		echo json_encode($data);
	}

	public function edit($iCustomerId)
	{
		$this->aHead['sActive'] = 'add';
		$data = $this->customer->edit($iCustomerId);
		$data['_SALES_TYPES'] = array(
			'Retail' => 'Retail Sale',
			'Catering'  => 'Catering Sale'
		);
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('customer/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['customer_id']) && 
			!empty($params['customer_id'])) {
			$data = $this->customer->update($params);
			$this->add($data);
		}
		else {
			redirect(site_url('master/customer/add'));
		}
	}

	public function view($iCustomerId)
	{
		$aSalesType = array(
			'Retail' => 'Retail Sale',
			'Catering'  => 'Catering Sale'
		);
		$data = $this->customer->edit($iCustomerId);
		$data['sales_type'] = $aSalesType[$data['sales_type']];
		$this->load->view('customer/view', $data);
	}
}