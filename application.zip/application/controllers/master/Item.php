<?php

class Item extends CI_Controller
{
    private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id || $user_role != 'admin')
			redirect(site_url('/login'));
		
		$this->aHead['title'] = 'Item Details';
		$this->aHead['sURLAdd'] = site_url('master/item/add');
		$this->aHead['sURLView'] = site_url('master/item/list-all');
		$this->load->model('master/item_model','item');	
	}

	public function index()
	{
		redirect(site_url('master/item/add'));
	}

	public function add($data = array())
	{
		$this->aHead['sActive'] = 'add';	
        $data['category'] = $this->item->get_category();	
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('item/add', $data);
		$this->load->view('temp/footer');
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		$data = $this->item->save($params);
		$this->add($data);
	}

	public function list_all()
	{
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('item/list');
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$data = array();
		$params =$this->input->post(null, true);
		$data = $this->item->get_records($params);
		echo json_encode($data);
	}

	public function edit($itemid)
	{
		$this->aHead['sActive'] = 'add';
		$data = $this->item->edit($itemid);
		$data['category'] = $this->item->get_category();	
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('item/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['item_id']) && 
			!empty($params['item_id'])) {
			$data = $this->item->update($params);
			$this->add($data);
		}
		else {
			redirect(site_url('master/item/add'));
		}
	}

	public function view($itemid)
	{
		$data = $this->item->edit($itemid);
        $data['category'] = $this->item->get_category();	
		$this->load->view('item/view', $data);
	}


}