<?php

class Category extends CI_Controller
{
	private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id || $user_role != 'admin')
			redirect(site_url('/login'));
		
		$this->aHead['title'] = 'Request Category';
		$this->aHead['hideAddNew'] = true;
		$this->aHead['sURLAdd'] = site_url('master/category/add');
		$this->aHead['sURLView'] = site_url('master/category/list-all');
		$this->load->model('master/category_model','category');	
	}

	public function index()
	{
		redirect(site_url('master/category/add'));
	}

	public function add($data = array())
	{
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('category/add', $data);
		$this->load->view('temp/footer');
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['category_id']) && 
			!empty($params['category_id'])) {
			$this->update();
		}
		else {
			$data = $this->category->save($params);
			$this->add($data);
		}
	}
	
	public function get_records()
	{
		$data = array();
		$params =$this->input->post(null, true);
		$data = $this->category->get_records($params);
		echo json_encode($data);
	}

	public function edit($iCustomerId)
	{
		$this->aHead['sActive'] = 'add';
		$data = $this->category->edit($iCustomerId);
		$this->add($data);
	}

	public function update()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['category_id']) && 
			!empty($params['category_id'])) {
			$data = $this->category->update($params);
			$this->add($data);
		}
		else {
			redirect(site_url('master/category/add'));
		}
	}
	
}