<?php

class Dashboard extends CI_Controller
{
	private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id || $user_role != 'admin')
			redirect(site_url('/login'));
								
		$this->aHead['title'] = 'Dashboard';
		$this->aHead['hideAddNew'] = true;		
		$this->load->model('admin/Dashboard_model','dashboard');
	}

	public function index()
	{

	//	redirect(site_url('master/customer'));
	//	exit(0);
		$data = array();
       // $data = $this->dashboard->counts();
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('dashboard/chart',$data);
		$this->load->view('temp/footer');
	}

}