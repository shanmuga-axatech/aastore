<?php

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $user_id=$this->session->userdata('user_id');
    		$user_role = $this->session->userdata('user_role');
    		if(!$user_id)
    			redirect(site_url('/login'));
        $this->load->model('Dashboard_model', 'dashboard');
    }

    public function index()
    {
      $this->load->view('temp/head');
      $data = $this->dashboard->get_counts();
      $this->load->view('dashboard/dashboard', $data);
      $this->load->view('temp/footer');
    }

    public function last_30days_sales()
    {
       $data = $this->dashboard->last_30days_sales();
       echo json_encode($data);
    }

    public function get_yesterday_sales()
    {
      $data = $this->dashboard->get_yesterday_sales();
      echo json_encode($data);
    }

    public function get_today_sales()
    {
      $data = $this->dashboard->get_today_sales();
      echo json_encode($data);
    }
}
