<?php

class Itemwise_report extends CI_Controller
{
    private $aHead = array();
	private $user_id;
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id)
			redirect(site_url('/login'));
		
		$this->user_id = $user_id;
		$this->aHead['hideAddNew'] = true;		
		$this->aHead['title'] = 'Itemwise Daily Sales Report';
		$this->aHead['sURLAdd'] = site_url('report/itemwise_report');
		$this->aHead['sURLView'] = site_url('report/itemwise_report');
		$this->load->model('report/salesrep_model','report');	
	}

		public function index()
	{
		$this->load->view('temp/header', $this->aHead);

		$data = array();
		$data['customer'] = $this->report->get_customer();
		$data['item'] = $this->report->get_item();
		$data['vehicle'] = $this->report->get_vechicle();

		$this->load->view('report/item_report', $data);
		$this->load->view('temp/footer');

	}

   public function item_sales_report()
   {

     $params = $this->input->post(null, true);
     $data=array();
     $data['result']= $this->report->itemwise($params); 
     $data['title'] = 'Itemwise Daily Sales Report';
     $data['from_date'] = $params['from_date'];
     $data['to_date'] = $params['to_date'];
     $data['vehicle'] = $params['vehicle'];
     $this->load->view('report/item_report_print', $data);
 }

 }	