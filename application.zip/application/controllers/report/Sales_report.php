<?php

class Sales_report extends CI_Controller
{
    private $aHead = array();
	private $user_id;
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id)
			redirect(site_url('/login'));
		
		$this->user_id = $user_id;
		$this->aHead['hideAddNew'] = true;		
		$this->aHead['title'] = 'Daily Sales Report';
		$this->aHead['sURLAdd'] = site_url('report/sales_report');
		$this->aHead['sURLView'] = site_url('report/sales_report');
		$this->load->model('report/salesrep_model','report');	
	}

		public function index()
	{
		$this->load->view('temp/header', $this->aHead);

		$data = array();
		$data['customer'] = $this->report->get_customer();
		$data['item'] = $this->report->get_item();
		$data['vehicle'] = $this->report->get_vechicle();

		$this->load->view('report/sales_report', $data);
		$this->load->view('temp/footer');

	}

   public function daily_sales_report()
   {

     $params = $this->input->post(null, true);
     $data=array();
     $data['result']= $this->report->search($params); 
     $data['title'] = 'Daily Sales Report';
     $data['from_date'] = $params['from_date'];
     $data['to_date'] = $params['to_date'];
     $data['vehicle'] = $params['vehicle'];
     $data['customer_id'] = $params['customer_id'];
     $this->load->view('report/sales_report_print', $data);
 }

	public function search()
	{
		$data = array();
		$params = $this->input->post(null, true);
		$data = $this->rep->search($params);		
		echo json_encode($data);
	}
 }	