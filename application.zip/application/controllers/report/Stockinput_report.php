<?php

class Stockinput_report extends CI_Controller
{
    private $aHead = array();
	private $user_id;
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id)
			redirect(site_url('/login'));
		
		$this->user_id = $user_id;
		$this->aHead['hideAddNew'] = true;		
		$this->aHead['title'] = 'Stock Inward Report';
		$this->aHead['sURLAdd'] = site_url('report/itemwise_report');
		$this->aHead['sURLView'] = site_url('report/itemwise_report');
		$this->load->model('report/salesrep_model','report');	
	}

		public function index()
	{
		$this->load->view('temp/header', $this->aHead);

		$data = array();
		$data['customer'] = $this->report->get_customer();
		$data['item'] = $this->report->get_item();
		$data['vehicle'] = $this->report->get_vechicle();

		$this->load->view('report/stockinput_report', $data);
		$this->load->view('temp/footer');

	}

   public function stock_report()
   {

     $params = $this->input->post(null, true);
     $data=array();
     $data['result']= $this->report->stockreport($params); 
     $data['title'] = 'Stock Inward Report';
     $data['date'] = $params['date'];
     $data['vehicle'] = $params['vehicle'];
     $data['item_id'] = $params['item_id'];
     $this->load->view('report/stockinput_report_print', $data);
   }

 }	