<?php

class User extends CI_Controller
{
	private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id || $user_role != 'admin')
			redirect(site_url('/login'));
		
		$this->aHead['title'] = 'User Management';
		$this->aHead['sURLAdd'] = site_url('admin/user/add');
		$this->aHead['sURLView'] = site_url('admin/user/list-all');
		$this->load->model('admin/user_model','user');	
	}

	public function index()
	{
		redirect(site_url('admin/user/add'));
	}

	public function add($data = array())
	{
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('user/add', $data);
		$this->load->view('temp/footer');
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		$data = $this->user->save($params);
		$this->add($data);
	}

	public function list_all()
	{
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('user/list');
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$data = array();
		$params =$this->input->post(null, true);
		$data = $this->user->get_records($params);
		echo json_encode($data);
	}

	public function edit($iId)
	{
		$this->aHead['sActive'] = 'add';
		$data = $this->user->edit($iId);
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('user/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['user_id']) && 
			!empty($params['user_id'])) {
			$data = $this->user->update($params);
			$this->add($data);
		}
		else {
			redirect(site_url('master/material/add'));
		}
	}

	public function update_status($user_id, $status)
	{
		$data = array();
		$data = $this->user->update_status($user_id, $status);
		$this->add($data);
	}

	public function view($iCustomerId)
	{
		$data = $this->user->edit($iCustomerId);
		$this->load->view('material/view', $data);
	}
}