<?php

class Sales extends CI_Controller
{
    private $aHead = array();
	private $user_id;
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id)
			redirect(site_url('/login'));
		
		$this->user_id = $user_id;
		$this->aHead['title'] = 'Sales Entry';
		//$this->aHead['sURLAdd'] = site_url('entry/sales/add');
		$this->aHead['sURLAdd'] = site_url('entry/sales/list-all');
		$this->aHead['sURLView'] = site_url('entry/sales/list-all');
		$this->load->model('entry/sales_model','sales');	
	}

    public function index() 
    {		
        redirect(site_url('entry/sales/list-all/'));
    }

    public function add($data=array())
    {
        $this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('sales/add', $data);
		$this->load->view('temp/footer');
    }

	public function create()
	{
		$uniqueId = mt_rand(1000, 10000000); 
		$params = $this->input->post(null, true);
		if($this->sales->saveTemp($params, $uniqueId, 'sales')) {
			redirect(site_url('entry/sales/item/'.$uniqueId));
			exit(0);
		}
		$data = array();
		$data['status'] = false;
		$data['msg'] = 'Failed to save the record';
		$this->add($data);		
	}

	public function item($uniqueId)
	{
		$data['uniqueId'] = $uniqueId;
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('sales/item', $data);
		$this->load->view('temp/footer');
	}

	public function add_entry()
	{
		$data = array(
			'status'=>false,
			'msg' => 'Failed to add the entry.'
		);
		$params = $this->input->post(null, true);
		if(!empty($params['item_id']) && empty($params['sales_id']) &&
			$this->sales->saveTemp($params, $params['unique_id'], 'sales_item')) {
			$data = array(
				'status'=>true,
				'msg' => 'Entry updated successfully.'	
			);
		}
		else if(isset($params['sales_id']) && !empty($params['sales_id'])) {
			$aSales = $this->sales->edit($params['sales_id']);
			$params['user_id'] = $this->session->userdata('user_id');
        	$params['mtime'] = time();
			if($this->sales->insert_sales_item(
				$params,$params['sales_id'],$aSales['sales']['sales_no']
			)) {
				$data = array(
					'status'=>true,
					'msg' => 'Entry updated successfully.'	
				);
			}
		}

		echo json_encode($data);
	}

	public function get_items_list()
	{
		$data = array();
		$params = $this->input->post(null, true);
		$data = $this->sales->get_items_list($params);
		echo json_encode($data);
	}

	public function delete_temp_record($temp_id) 
	{
		$data = array(
			'status' => false,
			'msg' => 'Failed to remove the record.'
		);

		if($this->sales->delete_temp_record($temp_id)) {
			$data = array(
				'status' => true,
				'msg' => 'Record removed successfully.'
			);
		}
		echo json_encode($data);
	}

	public function delete_item_record($sales_item_id)
	{
		$data = array(
			'status' => false,
			'msg' => 'Failed to remove the record.'
		);

		if($this->sales->delete_item_record($sales_item_id)) {
			$data = array(
				'status' => true,
				'msg' => 'Record removed successfully.'
			);
		}
		echo json_encode($data);
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(null, true);
		$data = $this->sales->save($params);
		echo json_encode($data);
	}

	public function list_all()
	{
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('sales/list');
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$params = $this->input->post(null, true);
		$data = $this->sales->get_records($params);
		echo json_encode($data);
	}

	public function view($sales_id)
	{
		$data = array();
		$data = $this->sales->edit($sales_id);
		$this->load->view('sales/view', $data);
	}

	public function billcancel($sales_id)
	{
		$data = array();
		$data = $this->sales->cancel_get($sales_id);
		$this->load->view('sales/cancel', $data);
	}

	public function cancel_entry()
	{
		$params = $this->input->post(null, true);
		$data=$this->sales->cancel_entry($params);
        echo json_encode($data);
		//redirect(site_url('entry/sales/list_all'));
	}

	public function edit($sales_id)
	{
		$data = array();
		$data = $this->sales->edit($sales_id);
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('sales/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$params = $this->input->post(null, true);

		if(empty($params['sales_id'])) {
			redirect(site_url('/entry/sales'));
			return true;
		}
		$params['user_id'] = $this->session->userdata('user_id');
        $params['mtime'] = time();
        
		$data = $this->sales->update($params);

		if($data['status']) {
			redirect(site_url('entry/sales/update-item/'.$params['sales_id']));
			return true;
		}

		$this->add($data);
	}

	public function update_item($sales_id)
	{
		$data['uniqueId'] = $sales_id;
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('sales/item_edit', $data);
		$this->load->view('temp/footer');
	}

	public function cancel($unique_id)
	{
		$this->sales->remove_temp_entries($unique_id);
		redirect(site_url('entry/sales/add'));
	}

	public function get_customers()
	{
		$params = $this->input->post(null, true);
		$data = $this->sales->get_customers($params);
		echo json_encode($data);
	}

	public function get_print()
	{
		$data  = array();
		$iSalesId = $this->uri->segment(4);
		$iSalesNo = $this->uri->segment(5);
		if(!empty($iSalesNo) && !empty($iSalesId)){			
			$data['sales'] = $this->sales->get_sales($iSalesId);

			if(!empty($data['sales'])) {
				$data['items'] = $this->sales->get_sales_items($iSalesId);	
				$data['customer'] = $this->sales->get_customer_details($data['sales']['customer_id']);							
				$this->load->library('invprint');
				$this->invprint->get_pdf($data);
			}
			else {
				redirect(site_url('sales'));
			}			
		}
	}


}