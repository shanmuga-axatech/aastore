<?php

class Stock extends CI_Controller
{
    private $aHead = array();
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id)
			redirect(site_url('/login'));
		
		$this->aHead['title'] = 'Stock Management';
		$this->aHead['sURLAdd'] = site_url('entry/stock/add');
		$this->aHead['sURLView'] = site_url('entry/stock/list-all');
		$this->load->model('entry/stock_model','stock');	
	}

    public function index() 
    {
        redirect(site_url('entry/stock/list-all'));
    }

    public function add($data=array())
    {
        $this->aHead['sActive'] = 'add';
		$data['vehicle'] = $this->stock->get_vechicle();
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('stock/add', $data);
		$this->load->view('temp/footer');
    }

	public function save()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		$params['user_id'] = $this->session->userdata('user_id');
		$data = $this->stock->save($params);
		$this->add($data);
	}

	public function list_all()
	{
		$data = array();
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$data['vechicle'] = $this->stock->get_vechicle();
		$data['items'] = $this->stock->get_item_list();
		$this->load->view('stock/list', $data);
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$data = array();
		$params =$this->input->post(null, true);
		$data = $this->stock->get_records($params);
		echo json_encode($data);
	}

	public function edit($stock_id)
	{
		$this->aHead['sActive'] = 'add';
		$data = $this->stock->edit($stock_id);	
        $data['vehicle'] = $this->stock->get_vechicle();		
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('stock/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$data = array();
		$params = $this->input->post(NULL, TRUE);
		if(isset($params['stock_input_id']) && 
			!empty($params['stock_input_id'])) {
			$params['user_id'] = $this->session->userdata('user_id');
			$data = $this->stock->update($params);
			//$this->add($data);
			$this->list_all();
		}
		else {
			redirect(site_url('entry/stock/add'));
		}
	}

	public function get_items()
	{
		$params = $this->input->post();
		$data = $this->stock->get_items($params);
		echo json_encode($data);
	}

	public function vechicle_details()
	{
		$params = $this->input->post();
		$data = $this->stock->vechicle_details($params);
		echo json_encode($data);
	}

	public function verify_unique()
	{
		$params = $this->input->post();
		$data = $this->stock->verify_unique($params);
		echo json_encode($data);
	}

}