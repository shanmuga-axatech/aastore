<?php

class Receipt extends CI_Controller
{
    private $aHead = array();
	private $user_id;
	public function __construct()
	{
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		$user_role = $this->session->userdata('user_role');
		if(!$user_id)
			redirect(site_url('/login'));
		
		$this->user_id = $user_id;
		$this->aHead['title'] = 'Receipt Entry';
		$this->aHead['sURLAdd'] = site_url('entry/receipt/add');
		$this->aHead['sURLView'] = site_url('entry/receipt/list-all');
		$this->load->model('entry/receipt_model','receipt');	
	}

    public function index() 
    {		
        redirect(site_url('entry/receipt/add/'));
    }

    public function add($data=array())
    {
        $this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('receipt/add', $data);
		$this->load->view('temp/footer');
    }

	public function create()
	{
		$uniqueId = mt_rand(1000, 10000000); 
		$params = $this->input->post(null, true);
		if($this->receipt->saveTemp($params, $uniqueId, 'receipt')) {
			redirect(site_url('entry/receipt/item/'.$uniqueId));
			exit(0);
		}
		$data = array();
		$data['status'] = false;
		$data['msg'] = 'Failed to save the record';
		$this->add($data);		
	}

	public function item($uniqueId)
	{
		$data = array();
		$data['sales'] = $this->receipt->get_outstanding_amount_details($uniqueId);
		if(!empty($data['sales'])) {
			$data['uniqueId'] = $uniqueId;
			$this->aHead['sActive'] = 'add';
			$this->load->view('temp/header', $this->aHead);
			$this->load->view('receipt/item', $data);
			$this->load->view('temp/footer');
		}
		else {
			$data['status'] = false;
			$data['msg'] = 'Outstanding Amt is not available to credit';
			$this->add($data);
		}
	}

	public function add_entry()
	{
		$data = array(
			'status'=>false,
			'msg' => 'Failed to add the entry.'
		);
		$params = $this->input->post(null, true);
		if(!empty($params['sales_id']) && empty($params['receipt_id']) &&
			$this->receipt->saveTemp($params, $params['unique_id'], 'receipt_item')) {
			$data = array(
				'status'=>true,
				'msg' => 'Entry created successfully.'	
			);
		}
		else if(isset($params['receipt_id']) && !empty($params['receipt_id'])) {
			$aSales = $this->receipt->edit($params['receipt_id']);
			$params['user_id'] = $this->session->userdata('user_id');
        	$params['mtime'] = time();
			if($this->receipt->insert_receipt_item($params,$params['receipt_id'])) {
				$data = array(
					'status'=>true,
					'msg' => 'Entry updated successfully.'	
				);
			}
		}

		echo json_encode($data);
	}

	public function get_items_list()
	{
		$data = array();
		$params = $this->input->post(null, true);
		$data = $this->receipt->get_items_list($params);
		echo json_encode($data);
	}

	public function delete_temp_record($temp_id) 
	{
		$data = array(
			'status' => false,
			'msg' => 'Failed to remove the record.'
		);

		if($this->receipt->delete_temp_record($temp_id)) {
			$data = array(
				'status' => true,
				'msg' => 'Record removed successfully.'
			);
		}
		echo json_encode($data);
	}

	public function delete_item_record($receipt_item_id)
	{
		$data = array(
			'status' => false,
			'msg' => 'Failed to remove the record.'
		);

		if($this->receipt->delete_item_record($receipt_item_id)) {
			$data = array(
				'status' => true,
				'msg' => 'Record removed successfully.'
			);
		}
		echo json_encode($data);
	}

	public function save()
	{
		$data = array();
		$params = $this->input->post(null, true);
		$data = $this->receipt->save($params);
		echo json_encode($data);
	}

	public function list_all()
	{
		$this->aHead['sActive'] = 'list';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('receipt/list');
		$this->load->view('temp/footer');
	}

	public function get_records()
	{
		$params = $this->input->post(null, true);
		$data = $this->receipt->get_records($params);
		echo json_encode($data);
	}

	public function view($receipt_id)
	{
		$data = array();
		$data = $this->receipt->edit($receipt_id);
		$this->load->view('receipt/view', $data);
	}

	public function edit($receipt_id)
	{
		$data = array();
		$data = $this->receipt->edit($receipt_id);
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('receipt/edit', $data);
		$this->load->view('temp/footer');
	}

	public function update()
	{
		$params = $this->input->post(null, true);

		if(empty($params['receipt_id'])) {
			redirect(site_url('/entry/receipt'));
			return true;
		}
		$params['user_id'] = $this->session->userdata('user_id');
        $params['mtime'] = time();
        
		$data = $this->receipt->update($params);

		if($data['status']) {
			$sUrl = site_url('entry/receipt/update-item/'.$params['receipt_id'].'/'.$params['customer_code']);
			redirect($sUrl);
			return true;
		}

		$this->add($data);
	}

	public function update_item($receipt_id, $customer_code)
	{
		$data = array();
		$data['sales'] = $this->receipt->get_outstanding_details($customer_code);
		$data['uniqueId'] = $receipt_id;
		$this->aHead['sActive'] = 'add';
		$this->load->view('temp/header', $this->aHead);
		$this->load->view('receipt/item_edit', $data);
		$this->load->view('temp/footer');
	}

	public function cancel($unique_id)
	{
		$this->sales->remove_temp_entries($unique_id);
		redirect(site_url('entry/receipt/add'));
	}

}