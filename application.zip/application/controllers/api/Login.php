<?php

class Login extends CI_Controller
{
	private $handshake_token;

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model', 'login');
		$this->load->library('api');
	}

	public function get_profile()
	{
		$params = $this->api->request('login');
		$data = $this->login->get_profile($params);
		$this->api->response($data);
	}
}
