<?php

class Android extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('api');
        $this->load->model('api/V1_model', 'v1');
    }

    public function archive()
    {
        $params = $this->api->request('archive');
        $data = $this->v1->archive();
        $this->api->response($data);
    }

    public function customer()
    {
       $params = $this->api->request('customer');      
       $data = $this->v1->customer($params);
       $this->api->response($data);    
    }

    public function pull_customer()
    {
       $params = $this->api->request('customer');      
       $data = $this->v1->pull_customer($params);
       $this->api->response($data);    
    }

    public function items()
    {  
       $json_string = $this->input->raw_input_stream;
       $params = json_decode($json_string);  	
       $request = $this->api->android_request('get-items',$params);
       $data = $this->v1->items($request);
       $this->api->response($data);
    }

    public function sales()
    {
       $params = $this->api->request('sales');
       $data = $this->v1->sales($params);
       $this->api->response($data);
    }

    public function pull_sales()
    {
       $params = $this->api->request('get-sale');
       $data = $this->v1->pull_sales($params);
       $this->api->response($data);
    }
}