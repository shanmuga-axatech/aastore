<?php

class V1 extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('api');
        $this->load->model('api/V1_model', 'v1');
    }

    public function archive()
    {
        $params = $this->api->request('archive');
        $data = $this->v1->archive();
        $this->api->response($data);
    }

    public function customer()
    {
       $params = $this->api->request('customer');
       $data = $this->v1->customer($params);
       $this->api->response($data);
    }

    public function pull_customer()
    {
       $params = $this->api->request('customer');
       $data = $this->v1->pull_customer($params);
       $this->api->response($data);
    }

    public function items()
    {
       $params = $this->api->request('get-items');
       $data = $this->v1->items($params);
       $this->api->response($data);
    }

    public function sales()
    {
       $params = $this->api->request('sales');
       $data = $this->v1->sales($params);
       $this->api->response($data);
    }

    public function pull_sales()
    {
       $params = $this->api->request('get-sale');
       $data = $this->v1->pull_sales($params);
       $this->api->response($data);
    }

    public function receipts()
    {
       $params = $this->api->request('receipts');
       $data = $this->v1->receipts($params);
       $this->api->response($data);
    }

    public function pull_receipts()
    {
       $params = $this->api->request('get-receipt');
       $data = $this->v1->pull_receipts($params);
       $this->api->response($data);
    }

    public function cron()
    {
       log_message('error', 'CRON server Time '.date('Y-m-d H:i:s'));
        $params = $this->input->post(null, true);
        $this->v1->cron($params);
    }
}
