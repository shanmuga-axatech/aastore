<?php
class Tallyapi extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('api/tallyapi_model', 'export');
	}
	
	public function index()
	{
		redirect(site_url());
		//$this->get_sales_details();
	}
	
	public function get_master_details()
	{	
		$sData = '';
			
		$params = $this->input->get();
				
		//get customer ids
		$aData = $this->export->get_order_data($params);

		if(!empty($aData)) {
		
          $sData .= $this->export->customer_sdf_format($params);		          	      	     
		  $sData .= $this->export->item_sdf_format($params);
		
		//	$sData .= $this->export->customer_sdf_format($aData['aData']);				
			//get item ids
		//	$aItemData = $this->export->get_item_ids(array_keys($aData['aData']));
		//	$sData .= $this->get_item_details($aItemData['item']);
		}
						
		echo $sData;		
	}
	
	public function get_sales_details()
	{
		$sData = '';
		$params = $this->input->get();
				
		//get customer ids
		$aData = $this->export->get_order_data($params);
		
		if(!empty($aData)) {
			//get item ids
			$aOrderData = $this->export->get_item_ids(array_keys($aData['aData']));		
			$aData['aItemData'] = $this->export->get_item_details($aOrderData['item']);		
			
			$sData = $this->export->sales_sdf_format($aData, $aOrderData);
		}
		
		echo $sData;
	}
	
	private function get_item_details($aItemIds = array())
	{
		$data = $this->export->get_item_details($aItemIds);
		return $this->export->item_sdf_format($data);
	}
	
	private function get_customer_details($aCustomerIds = array())
	{
		$data = $this->export->get_customer_details($aCustomerIds);		
		return $this->export->customer_sdf_format($data);		
	}
	
}