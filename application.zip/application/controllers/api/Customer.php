<?php

class Customer extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('api_model', 'api');
        $this->load->model('master/customer_model', 'customer');
    }

    public function store()
    {
        $data = array();
        $params = $this->api->getData();
        if($params['status']) {
            if(!empty($params['customer_id'])) {
                $data = $this->customer->update($params);
            }
            else {
                $data = $this->customer->save($params);
            }
        }
        $data = $this->response($data, $params);
        echo json_encode($data);
    }

    private function response($data, $params)
    {
        $aData = array();        
        if(isset($data['status'])) {
            $aData['status'] = $data['status'];
            $aData['msg'] = $data['msg'];
        }
        else if(isset($params['status'])) {
            $aData['status'] = $params['status'];
            $aData['msg'] = $params['msg'];
        }

        $aData['app_customer_id'] = $params['app_customer_id'];
        $aData['handshake'] = $params['handshake'];
        $aData['api_key'] = $params['api_key'];
        $aData['customer_id'] = isset($data['customer_id'])?$data['customer_id']:'';
        
        return $aData;
    }
}

/**
JSON Structures-------------

//customer create and update
{
    "api_key":"api_key",
    "handshake":"handshake",
    "app_customer_id":"app_customer_id",
    "customer_id":"customer_id",
    "name":"customer_name",
    "customer_code":"customer_code",
    "tinno":"tinno",
    "sales_type":"sales_type",
    "mobile":"mobile",
    "phone":"phone",
    "email":"email",
    "address1":"address1",
    "address2":"address2",
    "city":"city",
    "pincode":"pincode",
    "app_time":"app_time",
    "user_id":"user_id"
}

Response
{
    "app_customer_id":"app_customer_id",
    "api_key":"api_key",
    "handshake":"handshake",
    "customer_id":"customer_id",
    "status":"status",
    "msg":"msg",
}
**/