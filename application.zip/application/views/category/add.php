
<div class="col-md-8">

<?php 

$sCateName = isset($category_name)?$category_name:'';
$sHsnCode = isset($hsncode)?$hsncode:'';
$sIgstPer = isset($igstper)?$igstper:'';
$iCateId = isset($category_id)?$category_id:'';

if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>
<form method="post" action="<?php echo site_url('master/category/save'); ?>" name="categoryForm" id="categoryForm">
<table class="table table-striped" width="100%">
	<tr>
		<th width="15%">Category</th>
		<td width="15%">			
			<input type="text" value="<?php echo $sCateName; ?>" name="category_name" id="category_name" class="form-control input-sm" />	
			<input type="hidden" value="<?php echo $iCateId; ?>" name="category_id" id="category_id"  />		
		</td>	
		<th width="15%"></th>
	</tr>
	<tr>
		<th>HSN Code</th>
		<td>			
			<input type="text" value="<?php echo $sHsnCode; ?>" name="hsncode" id="hsncode" class="form-control input-sm" />		
		</td>	
        <th></th>
	</tr>	
	<tr>
		<th>IGST %</th>
		<td>			
			<input type="text" value="<?php echo $sIgstPer; ?>" name="igstper" id="igstper" class="form-control input-sm" />		
		</td>	
        <th></th>
	</tr>		
	<tr>	
	    <th></th>
		<td>
			<button type="submit" class="btn btn-primary btn-sm" name="saveCategory" id="saveCategory"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Save</strong></button>
			&nbsp;<a href="<?php echo site_url('master/category/add'); ?>" class="btn btn-sm btn-default"><i class="glyphicon glyphicon-remove-circle"></i> Cancel</a>
		</td>
		<th></th>		
	</tr>
</table>
</form>
<table class="table datatable table-striped" id="category">
	<thead>
		<tr>
			<th>CategoryId</th>
			<th>CategoryName</th>
			<th>HSN Code</th>
			<th>IGST %</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody></tbody>
</table>
</div>