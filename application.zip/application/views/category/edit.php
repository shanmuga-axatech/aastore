<div class="col-md-8">

<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>

<form method="post" action="<?php echo site_url('master/customer/update'); ?>" name="customer-form" id="customer-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>Name</th>
		<td><input type="text" name="name" value="<?php echo $name; ?>" id="name" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>
	<tr>		
		<th></th>
		<th>Mobile No</th>
		<td><input type="text" name="mobile" id="mobile" value="<?php echo $mobile; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Phone No</th>
		<td><input type="text" name="phone" id="phone" value="<?php echo $phone; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Email</th>
		<td><input type="text" name="email" id="email" value="<?php echo $email; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Address 1</th>
		<td><input type="text" name="address1" id="address1" value="<?php echo $address1; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Address 2</th>
		<td><input type="text" name="address2" id="address2" value="<?php echo $address2; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>
		<th></th>
		<th>City</th>
		<td><input type="text" name="city" id="city" value="<?php echo $city; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>
		<th></th>
		<th>Pincode</th>
		<td><input type="text" name="pincode" id="pincode" value="<?php echo $pincode; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>
		<th></th>
		<td><input type="hidden" name="customer_id" value="<?php echo $customer_id; ?>"></td>		
		<td align="center">
			<button type="button" class="btn btn-primary btn-sm" name="saveCustomer" id="saveCustomer"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Save</strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
