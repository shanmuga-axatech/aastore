<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table id="customer" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Name</th>
	      <th>Mobile</th>      	      
	      <th>City</th> 
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>

</div>