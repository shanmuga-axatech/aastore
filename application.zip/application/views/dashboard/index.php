
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
                <div class="inner">
                     <table width="100%">
                    <tbody><tr>      
                        <td> <h3>
                            <?php echo sprintf('%0.2f',$sales['total_amt']); ?>                              
                        </h3></td>
                    </tr>
                    <tr>
                        <td> <h4>Total Sales</h4></td>
                    </tr>
                     </tbody></table>
                </div>
                <div class="icon">
                    <i class="glyphicon glyphicon-leaf"></i>
                </div>
                <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                   <table width="100%">
                    <tbody><tr> 
                        <td><h3>10</h3></td>
                    </tr>
                    <tr>
                        <td><h4>Employees</h4></td>
                    </tr>
                   </tbody></table>
                </div>
                <div class="icon">
                    <i class="glyphicon glyphicon-leaf"></i>
                </div>
                <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <table width="100%">
                    <tbody><tr>
                        <td> <h3>15</h3></td>
                    </tr>
                    <tr>
                        <td> <h4>Customers</h4></td>
                    </tr>
                    </tbody></table>
                </div>
                <div class="icon">
                    <i class="ion ion-person-add"></i>
                </div>
                <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <table width="100%">
                    <tbody><tr>
                        <td> <h3>4</h3></td>
                    </tr>
                    <tr>
                    <td><h4>Services</h4></td>
                    </tr>
                    </tbody></table>
                </div>
                <div class="icon">
                    <i class="fa fa-fw fa-phone"></i>
                </div>
                <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-purple">
                <div class="inner">
                    <table width="100%">
                    <tbody><tr>
                        <td><h3>9</h3></td>
                    </tr>
                    <tr>
                        <td><h4>Service Ticketing</h4></td>
                    </tr>
                    </tbody></table>
                </div>
                <div class="icon">
                    <i class="fa fa-fw fa-phone"></i>
                </div>
                <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-lg-4 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-maroon">
                <div class="inner">
                    <table width="100%">
                    <tbody>
                    <tr>
                     
                     <?php
                      foreach($vansales as $row){
                        ?>                    
                        <td><h4>
                            <?php echo sprintf('%0.2f',$row['total_amt']); ?>
                        </h4></td>
                      <?php } ?>

                    </tr>                     
                    <tr>
                     
                     <?php
                      foreach($vansales as $row){
                        ?>                    
                        <td><h3>
                            <?php echo $row['van']; ?>
                        </h3></td>
                      <?php } ?>

                    </tr>                    
                    </tbody></table>
                </div>
                <div class="icon">
                    <i class="glyphicon glyphicon-leaf"></i>
                </div>
                <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
   <!-- </div>
     <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Assigned Tasks</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
    <div class="box-body">
        <div class="table-responsive">
       
            <table class="table no-margin">
                <thead>
                    <tr>
                        <th>Service Ticket Id</th>
                        <th>Service Ticket Raised Date</th>
                        <th>Location</th>
                        <th>Task Assigned Date</th>
                      
                        <th>Employee Details</th>
                          <th>Service Name</th>

                    </tr>
                </thead>
                <tbody>
                                    </tbody>
            </table>
        </div>
    </div>
     </div> -->
     </div>
    


