<div class="col-md-3">
  <div class="panel panel-info">
  <div class="panel-heading text-center">Total Customers</div>
  <div class="panel-body text-center" style="padding:0px;">
    <h3><strong><?php echo $customers; ?></strong></h3>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="panel panel-success text-center">
  <div class="panel-heading text-center">New Cutomers</div>
  <div class="panel-body text-center" style="padding:0px;">
    <h3><strong><?php echo $new_customers; ?></strong></h3>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="panel panel-info">
  <div class="panel-heading text-center">Total Items</div>
  <div class="panel-body text-center" style="padding:0px;">
    <h3><strong><?php echo $total_items; ?></strong></h3>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="panel panel-success">
  <div class="panel-heading text-center">Today Sales Amt</div>
  <div class="panel-body text-center" style="padding:0px;">
    <h3><strong><?php echo $total_sales; ?></strong></h3>
  </div>
</div>
</div>
<div id="last_30days_sales" class="col-md-12" style="width:100%;height:300px;">
</div>
<div class="clear">&nbsp;</div>
<!--<div class="col-md-6">
    <h3>Yesterday Sales Details</h3>
    <table class="table" id="total_sales_yesterday">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Qty</th>
                <th>Amt</th>
            </tr>
        </thead>
    </table>
</div>
<div class="col-md-6">
    <h3>Today Sales Details</h3>
    <table class="table" id="total_sales_today">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Qty</th>
                <th>Amt</th>
            </tr>
        </thead>
    </table>
</div>-->



<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
