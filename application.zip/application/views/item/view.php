<div class="col-md-8 bg-dialog-500">


<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>Name</th>
		<td><?php echo $item_name; ?></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>Item Code</th>
		<td>
			<?php echo $item_code; ?>
		</td>
		<th></th>
	</tr>
	<tr>	
		<th width="15%"></th>	
		<th>Category</th>
		<td>
			<?php foreach($category as $oRow): ?>
				<?php $bSelected = $oRow->category_id==$category_id?$oRow->category_name:''; ?>
				<?php echo $bSelected; ?>
			<?php endforeach; ?>
		</td>		
		<th width="15%"></th>
	</tr>
	<tr>	
		<th width="12%"></th>	
		<th>IGST %</th>	
		<td>
			<?php foreach($category as $oRow): ?>
				<?php $bSelected = $oRow->category_id==$category_id?$oRow->igstper:''; ?>
				<?php echo $bSelected; ?>
			<?php endforeach; ?>
		</td>		
		<th width="12%"></th>
	</tr>
	<tr>	
		<th width="12%"></th>	
		<th>MRP</th>	
		<td><?php echo $mrp; ?></td>		
		<th width="12%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>Retail Price</th>
		<td><?php echo $retail_price; ?></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Catering Price</th>
		<td><?php echo $whole_sale_price; ?></td>
		<th></th>
	</tr>	
</table>
</div>
