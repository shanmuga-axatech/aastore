<div class="col-md-8">

<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>

<form method="post" action="<?php echo site_url('master/item/save'); ?>" name="item-form" id="item-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>Name</th>
		<td><input type="text" name="item_name" id="item_name" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>Item Code</th>
		<td>
			<input type="text" name="item_code" id="item_code" class="form-control input-sm" />
		</td>
		<th></th>
	</tr>
	<tr>	
		<th width="15%"></th>	
		<th>Category</th>
		<td>
		<select name="category_id" id="category_id" class="form-control input-sm">
			<?php foreach($category as $oRow): ?>
				<option value="<?php echo $oRow->category_id; ?>"><?php echo $oRow->category_name; ?> </option>
			<?php endforeach; ?>
		</select>
		</td>		
		<th width="15%"></th>
	</tr>
<!--	<tr>	
		<th width="12%"></th>	
		<th>Tax %</th>	
		<td><input type="text" name="tax_per" id="tax_per" class="form-control input-sm" /></td>		
		<th width="12%"></th>
	</tr>-->
	<tr>	
		<th width="12%"></th>	
		<th>MRP</th>	
		<td><input type="text" name="mrp" id="mrp" class="form-control input-sm" /></td>		
		<th width="12%"></th>	
	</tr>

	<tr>		
		<th></th>
		<th>Retail Price</th>
		<td><input type="text" name="retail_price" id="retail_price" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Catering Price</th>
		<td><input type="text" name="whole_sale_price" id="whole_sale_price" class="form-control input-sm"/></td>
		<th></th>
	</tr>	
	<tr>
		<th></th>
		<td></td>		
		<td align="center">
			<button type="button" class="btn btn-primary btn-sm" name="saveItem" id="saveItem"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Save</strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
