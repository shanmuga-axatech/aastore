<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table id="item" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Code</th>
	      <th>Name</th>      	      
	      <th>Category</th> 
	      <th>Retail</th> 
	      <th>Catering</th> 
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>

</div>