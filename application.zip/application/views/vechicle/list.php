<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table id="vechicle" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Code</th>
	      <th>Model</th>      	      
	      <th>Reg No</th> 
				<th>Insurance No</th> 
				<th>Expiry Date</th> 	
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>
</div>