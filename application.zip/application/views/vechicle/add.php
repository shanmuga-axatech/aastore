<div class="col-md-8">

<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>

<form method="post" action="<?php echo site_url('master/vechicle/save'); ?>" name="vechicle-form" id="vechicle-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>Code</th>
		<td><input type="text" name="vechicle_code" id="vechicle_code" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>Model</th>
		<td>
			<input type="text" name="model" id="model" class="form-control input-sm" />
		</td>
		<th></th>
	</tr>
	
	<tr>	
		<th width="15%"></th>	
		<th>Reg No</th>	
		<td><input type="text" name="reg_no" id="reg_no" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>
	
	<tr>		
		<th></th>
		<th>Insurance No</th>
		<td><input type="text" name="insurance_no" id="insurance_no" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Expiry Date</th>
		<td><input type="text" name="expiry_date" id="expiry_date" class="form-control input-sm datepicker" /></td>
		<th></th>
	</tr>	
	<tr>
		<th></th>
		<td></td>		
		<td align="center">
			<button type="button" class="btn btn-primary btn-sm" name="saveVechicle" id="saveVechicle"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Save</strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
