 </div>
<div class="clear">&nbsp;</div>
<div class="col-md-12"><?php view_js(); ?></div>
</body>
</html>