<div class="col-md-8">

<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>

<form method="post" action="<?php echo site_url('entry/stock/save'); ?>" name="stock-form" id="stock-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>InputDate</th>
		<td><input type="text" name="input_date" id="input_date" value="<?php echo date('Y-m-d'); ?>" class="form-control input-sm datepicker" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>	
		<th width="15%"></th>	
		<th>Vehicle Code</th>
		<td>
		<select name="vechicle_code" id="vechicle_code" class="selectpicker form-control input-sm"  data-live-search="true">
        <option value="">- Select Vehicle-</option>
        <?php foreach ($vehicle as $vehicle): ?>
        <option value="<?php echo $vehicle->vechicle_code; ?>"><?php echo $vehicle->vechicle_code;?></option>
        <?php endforeach; ?>
        </select></td>		
		<th width="15%"></th>
	</tr>
	<tr>		
		<th></th>
		<th>Item Code/Name</th>
		<td>
			<input type="text" name="item_code" id="item_code" class="form-control input-sm" />
		</td>
		<th></th>
	</tr>	
	<tr>		
		<th></th>
		<th>BatchNo</th>
		<td>
			<input type="text" name="batch_no" id="batch_no" class="form-control input-sm" />
		</td>
		<th></th>
	</tr>
	
	<tr>		
		<th></th>
		<th>Opening Qty</th>
		<td><input type="text" name="opening_qty" id="opening_qty" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Input Qty</th>
		<td><input type="text" name="input_qty" id="input_qty" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Closing Qty</th>
		<td><input type="text" name="closing_qty" id="closing_qty" class="form-control input-sm" /></td>
		<th></th>
	</tr>	
	<tr>
		<th></th>
		<td></td>		
		<td align="center">
			<button type="button" disabled="disabled" class="btn btn-primary btn-sm" name="saveStock" id="saveStock"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Save</strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
