<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table class="table table-bordered">
		<tr>
			<th>Vechicle Code</th>
			<td>
				<select name="vechicle_code" id="vechicle_code_list" class="selectpicker form-control input-sm"  data-live-search="true">
		        <option value="">- Select Vehicle-</option>
		        <?php foreach ($vechicle as $vehicle): ?>
		        <option value="<?php echo $vehicle->vechicle_code; ?>"><?php echo $vehicle->vechicle_code;?></option>
		        <?php endforeach; ?>
		        </select>
			</td>
			<th>Item Code</th>
			<td>
				
				<select name="item_code" id="item_code_list" class="selectpicker form-control input-sm"  data-live-search="true">
		        <option value="">- Select Items-</option>
		        <?php foreach ($items as $item): ?>
		        <option value="<?php echo $item->item_code; ?>"><?php echo $item->item_code.' - '.$item->item_name;?></option>
		        <?php endforeach; ?>
		        </select>
			</td>
		</tr>
	</table>
	<table id="stock" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Date</th>
	      <th>Item Code</th>
	      <th>Item</th>      	            	      
	      <th class="status">Veh.Code</th> 
		  <th>Op Qty</th> 
		  <th>In Qty</th> 
		  <th>Cl Qty</th> 
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>

</div>