<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table id="user" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Route/User</th>
	      <th>Email</th>      	      
	      <th>Password</th> 
	      <th>Mobile</th> 
	      <th>UserRole</th> 
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>

</div>