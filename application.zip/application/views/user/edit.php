<div class="col-md-8">
<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>

<form method="post" action="<?php echo site_url('admin/user/update'); ?>" name="user-form" id="user-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>Route/User Name</th>
		<td><input type="text" name="user_name" id="user_name" value="<?php echo $user_name; ?>" class="form-control input-sm" /></td>	
		<th width="15%"></th>
	</tr>
	<tr>	
		<th></th>	
		<th>Email</th>
		<td><input type="text" name="email" id="email" value="<?php echo $email; ?>" class="form-control input-sm" /></td>	
		<th></th>
	</tr>
	<tr>	
		<th></th>	
		<th>Password</th>
		<td><input type="text" name="password" id="password" value="<?php echo $password; ?>" class="form-control input-sm" /></td>		
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>User Role</th>
		<td>
			<select name="user_role" id="user_role"  class="form-control input-sm">
				<option value="user">User</option>
				<option value="admin">Admin</option>
			</select>
		</td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Mobile</th>
		<td><input type="text" name="mobile" id="mobile" value="<?php echo $mobile; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>		
	<tr>
		<th></th>
		<td></td>		
		<td align="center">
			<input type="hidden" name="user_id" value="<?php echo $user_id; ?>" /> 
			<button type="button" class="btn btn-primary btn-sm" name="saveUser" id="saveUser"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Update</strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
