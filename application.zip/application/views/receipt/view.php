<div class="col-md-8 bg-dialog-750">
	<table class="table table-striped " width="100%">
		<tr>
			<th>ReceiptNo</th>
			<td><?php echo $receipt['receipt_no']; ?></td>		
			<th>ReceiptDate</th>
			<td><?php echo date('d-m-Y', strtotime($receipt['receipt_date'])); ?></td>
			
		</tr>
		<tr>
			<th>CustomerCode</th>
			<td><?php echo $receipt['customer_code']; ?></td>		
			<th>ReceivedAmt</th>
			<td><?php echo $receipt['net_amt']; ?></td>
			
		</tr>
		<tr class="danger">
			<th>BillNo</th>
			<th>BillDate</th>
			<th>OutstandingAmt</th>
			<th>ReceivedAmt</th>		
		</tr>
		<?php foreach($receipt_item as $item): ?>
			<tr>
				<td><?php echo $item['sales_no']; ?></td>
				<td><?php echo date('d-m-Y', strtotime($item['sales_date'])); ?></td>			
				<td  class="text-right"><?php echo $item['outstanding_amt']; ?></td>
				<td  class="text-right"><?php echo $item['received_amt']; ?></td>			
			</tr>
		<?php endforeach; ?>
	</table>
</div>
