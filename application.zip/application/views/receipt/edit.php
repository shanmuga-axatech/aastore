<div class="col-md-8">
<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>
<form method="post" action="<?php echo site_url('entry/receipt/update'); ?>" name="receipt-form" id="receipt-form">

<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>ReceiptNo</th>
		<td><input type="text" name="receipt_no" id="receipt_no" value="<?php echo $receipt['receipt_no']; ?>" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>ReceiptDate</th>
		<td><input type="text" name="receipt_date" id="receipt_date" value="<?php echo $receipt['receipt_date']; ?>" class="form-control input-sm datepicker" /></td>
		<th></th>
	</tr>	
	<tr>	
		<th width="15%"></th>	
		<th>CustomerCode</th>	
		<td><input type="text" name="customer_code" id="customer_code" value="<?php echo $receipt['customer_code']; ?>" class="form-control input-sm" /></td>
		<th width="15%"></th>
	</tr>	
	<tr>
		<th></th>
		<td>&nbsp;</td>		
		<td>
			<input type="hidden" name="receipt_id" id="receipt_id" value="<?php echo $receipt['receipt_id']; ?>">
			<button type="button" class="btn btn-block btn-primary btn-sm" name="saveReceipt" id="saveReceipt"><strong>Next >></strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
