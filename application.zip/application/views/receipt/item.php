<div class="col-md-12">
<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>
<form method="post" action="<?php echo site_url('entry/receipt/save'); ?>" name="entry-form" id="entry-form">
<table class="table table-striped" width="100%">
	<tr>
		<th>Bill No</th>
		<th>Outstanding</th>
		<th>Recv Amt</th>		
		<th>Action</th>
	</tr>
	<tr>
		<td>
			<select name="sales_id" id="sales_id" class="form-control input-sm">
				<option value="">--Select--</option>
				<?php foreach ($sales as $aRow) { ?>
					<option value="<?php echo $aRow['sales_id']; ?>"><?php echo $aRow['display']; ?></option>
				<?php } ?>
			</select>			
		</td>
		<td><input type="text" name="outstanding_amt" id="outstanding_amt" class="form-control input-sm" /></td>
		<td><input type="text" name="received_amt" id="received_amt" class="form-control input-sm" /></td>	
		<td>
			<input type="hidden" id="unique_id" value='<?php echo $uniqueId; ?>' />
			<input type="hidden" id="container" value='<?php echo json_encode($sales); ?>' />
			<button type="button" class="btn btn-primary btn-sm" name="addReceipt" id="addReceipt"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Add</strong></button>
		</td>		
	</tr>
</table>
<table class="table table-striped" id="item-table" width="100%">
	<thead>
	<tr class="active">
		<th width="30%">Bill No</th>
		<th width="30%">Outstanding</th>
		<th width="30%">Recv Amt</th>		
		<th width="10%">Action</th>
	</tr>	
	</thead>
	<tbody></tbody>
</table>

<table class="table table-striped" width="100%">	
	<tr>		
		<th width="30%">&nbsp;</th>
		<th width="30%" class="text-right">Net Amt</th>
		<th width="30%" class="text-right">
			<input type="text" name="net_amt" id="net_amt" class="form-control text-right input-sm">
		</th>
		<th width="10%">&nbsp;</th>
	</tr>

	<tr>
		<th width="30%">&nbsp;</th>		
		<th width="25%"><button type="button" class="btn btn-block btn-warning btn-sm">Cancel</button></th>
		<th width="25%"><button type="button" id="save" class="btn btn-block btn-success btn-sm">Save</button></th>
		<th width="20%">&nbsp;</th>
	</tr>	
</table>


</form>
</div>
