<div class="container">
    <form method="post" action="<?php echo site_url(); ?>report/itemwise_report/item_sales_report" id="sale_report" name="sale_report" target=_blank>
    <table class="table">
      <tr>
        <td>
          <table width="80%">
            <tr>
             <td colspan="1" width="8%"><font size="+1">Customer</font></td>             
             <td colspan="1" width="20%">
                  <select class="selectpicker form-control input-sm" data-live-search="true" name="customer_id" id="customer_id">
                    <option value="">- Select Party Name -</option>
                    <?php foreach ($customer as $party) { ?>
                    <option value="<?php echo $party['customer_id']; ?>"><?php echo $party['name'];?></option>
                   <?php } ?>              
                  </select>
              </td>
              <th  class="text-right" align="right" width="10%">Vehicle&nbsp;</th>
              <td colspan="1" width="20%">
                  <select name="vehicle" id="vehicle" class="selectpicker form-control input-sm" data-live-search="true">
                  <option value="">- Select Vehicle-</option>
                  <?php foreach ($vehicle as $vehicle) { ?>
                    <option value="<?php echo $vehicle['vechicle_code']; ?>"><?php echo $vehicle['vechicle_code'];?></option>
                  <?php } ?>
                  </select>
              </td>  
            </tr>
        </table>
        </td>
      </tr>            
       <tr>
         <td>
          <table width="80%">
            <tr>
              <td width="14%"><font size="+1">Bill Type</font></td>
              <td>
                 <select name="mode_of_pay" id="mode_of_pay" class="form-control input-sm">
                    <option value="">- Select Bill Type -</option>
                    <option value="cash">Cash</option>
                    <option value="credit">Credit</option>
                 </select>
             </td>
              <th class="text-right" align="right">Form Type&nbsp;</th>
              <td>
                 <select name="form_type" id="form_type" class="form-control input-sm">
                    <option value="">- Select Bill Type -</option>
                    <option value="FORM-8">Form 8</option>
                    <option value="FORM-8B">Form 8B</option>
                 </select>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td>
          <table width="80%">
              <tr>
                <th width="15%"><strong>From Date</strong></th>
                <td width="20%">
                  <input type="text" value="<?php echo date('Y-m-d'); ?>" name="from_date" id="from_date" class="form-control datepicker input-sm" />
                </td>
                <td  width="5%">&nbsp;</td>
                <th width="15%" ><strong>To Date</strong></th>
                <td width="20%" >
                  <input type="text" value="<?php echo date('Y-m-d'); ?>" name="to_date" id="to_date" class="form-control datepicker input-sm"/>
                </td>              
                <td  width="5%">&nbsp;</td>    
                 <td width="20%">
                  <button type="submit" class="btn btn-primary btn-sm btn-block" name="search" id="search">
                    <i class="glyphicon glyphicon-search"> </i>
                    Search
                  </button>
                </td>        
              </tr>
          </table>
        </td>
      </tr>
      </table>
    </form>
</div>

<!--<table id="sales_report" class="display table" width="80%" cellspacing="0">
  <thead>
      <tr>
          <th>S.No</th>
          <th>Bill.No</th>
          <th>Date</th>
          <th>Customer</th>           
          <th>Type</th>
          <th>Form</th>
          <th>Total Qty</th>                
          <th>Total Amount</th>
      </tr>
  </thead>  
  <tbody>  </tbody>
</table>-->
             
