<div class="container">
    <form method="post" action="<?php echo site_url(); ?>report/stockinput_report/stock_report" id="stock_report" name="stock_report" target=_blank>
    <table class="table">
      <tr>
        <td>
          <table width="80%">
            <tr>
             <td colspan="1" width="8%"><font size="+1">Item </font></td>             
             <td colspan="1" width="20%">
                  <select class="selectpicker form-control input-sm" data-live-search="true" name="item_id" id="item_id">
                    <option value="">- Select Item-</option>
                  <?php foreach ($item as $item) { ?>
                    <option value="<?php echo $item['item_id']; ?>"><?php echo $item['item_name'];?></option>
                  <?php } ?>             
                  </select>
              </td>
              <th  class="text-right" align="right" width="10%">Vehicle&nbsp;</th>
              <td colspan="1" width="20%">
                  <select name="vehicle" id="vehicle" class="selectpicker form-control input-sm" data-live-search="true">
                  <option value="">- Select Vehicle-</option>
                  <?php foreach ($vehicle as $vehicle) { ?>
                    <option value="<?php echo $vehicle['vechicle_code']; ?>"><?php echo $vehicle['vechicle_code'];?></option>
                  <?php } ?>
                  </select>
              </td>  
            </tr>
        </table>
        </td>
      </tr>            
      <tr>
        <td>
          <table width="50%">
              <tr>
                <th width="10%" ><strong>Date</strong></th>
                <td width="16%" >
                  <input type="text" value="<?php echo date('Y-m-d'); ?>" name="date" id="date" class="form-control datepicker input-sm"/>
                </td>              
                <td  width="5%">&nbsp;</td>    
                 <td width="15%">
                  <button type="submit" class="btn btn-primary btn-sm btn-block" name="search" id="search">
                    <i class="glyphicon glyphicon-search"> </i>
                    Search
                  </button>
                </td>        
              </tr>
          </table>
        </td>
      </tr>
      </table>
    </form>
</div>
             
