<?php
	echo "<script type='text/javascript'>alert('Use browser print option to take printout');</script>";
?>

<table border="2" cellpadding="2" cellspacing="0" bordercolor="#FFF">
<tr>
	<td colspan="10" align="center">
    <strong><?php echo $title; ?>  <br />
     For</strong> : <?php echo $date; ?>
    <?php if(!empty($vehicle)){ ?>
    <strong> &nbsp;&nbsp; Vehicle Code :-</strong><?php echo $vehicle; ?>
    <?php } ?>
    </td>

</tr>
   <tr bgcolor="#FFF" style="color:#222;">
    <th scope="col">S.No</th>
    <th scope="col">Date</th>
    <th scope="col">Item Name</th>
    <th scope="col">Opening</th>
    <th scope="col">Input</th>
    <th scope="col">Loading(O+I)</th>
  </tr>
  <?php 
    
  if(count($result['result'])>0)
  {
    $i = 1;
    foreach($result['result'] as $row):
  ?>
  <tr>
    <td><?php echo $i++; ?></td>
    <td><?php echo $row['input_date']; ?></td>   
    <td><?php echo $row['item_name']; ?></td>
    <td align="right"><?php echo $row['opening']; ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['input']); ?></td>
    <td align="right"><?php echo $row['loaded']; ?></td>
  </tr>

  <?php 
   endforeach; ?>

  <?php   
    } ?>

</table>