<?php
	echo "<script type='text/javascript'>alert('Use browser print option to take printout');</script>";
?>

<table border="2" cellpadding="2" cellspacing="0" bordercolor="#FFF">
<tr>
	<td colspan="10" align="center">
    <strong><?php echo $title; ?>  <br />
     From</strong> : <?php echo $from_date; ?> <strong>To</strong> : <?php echo $to_date; ?>
    <?php if(!empty($vehicle)){ ?>
    <br />
    <strong>Vehicle Code :-</strong><?php echo $vehicle; ?>
    <?php } ?>
    </td>

</tr>
   <tr bgcolor="#FFF" style="color:#222;">
    <th scope="col">S.No</th>
  <?php if(empty($vehicle)){ ?>
    <th scope="col">Vehicle Code</th>
  <?php } ?>  
    <th scope="col">Item Name</th>
    <th scope="col">Opening</th>
    <th scope="col">Input</th>
    <th scope="col">Loading(O+I)</th>
    <th scope="col">Sales</th>
    <th scope="col">Sales Amount</th>
    <th scope="col">Closing</th>
  </tr>

  <?php 
  	
	if(count($result['result'])>0)
	{
		$i = 1;
    $tot_amount = 0;
		foreach($result['result'] as $row):
  ?>
  <tr>
    <td><?php echo $i++; ?></td>
  <?php if(empty($vehicle)){ ?> 
    <td><?php echo $row['vechicle_code']; ?></td>
  <?php } ?>  
    <td><?php echo $row['item_name']; ?></td> 
    <td align="right" style="font-style: italic;"><?php echo sprintf('%0.2f',$row['opening']); ?></td> 
    <td align="right" style="font-style: italic;"><?php echo sprintf('%0.2f',$row['input']); ?></td>   
    <td align="right" style="font-style: italic;"><?php echo sprintf('%0.2f',$row['loaded']); ?></td> 
    <td align="right"><?php echo sprintf('%0.2f',$row['sales']); ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['total_amt']); ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['closing']); ?></td> 
  </tr>

  <?php 
    $tot_amount +=$row['total_amt'];
    endforeach; ?>
 
   <tr>
      <td colspan=<?php echo !empty($vehicle) ? "6" : "7" ?>  align="right"><strong>TOTAL</strong></td>
      <td align="right"><?php echo sprintf('%0.2f',$tot_amount); ?></td>
      <td>&nbsp</td>
    </tr>

   <tr>
      <td colspan=<?php echo !empty($vehicle) ? "6" : "7" ?>  align="right"><strong>K.VAT</strong></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['kvat_amt']); ?></td>
      <td>&nbsp</td>
    </tr>

   <tr>
      <td colspan=<?php echo !empty($vehicle) ? "6" : "7" ?>  align="right"><strong>Discount</strong></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['disc_amt']); ?></td>
      <td>&nbsp</td>
    </tr>        
    
    <tr>
      <td colspan=<?php echo !empty($vehicle) ? "6" : "7" ?>  align="right"><strong>Roundoff</strong></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['round_off']); ?></td>
      <td>&nbsp</td>
    </tr>

    <tr>
      <td colspan=<?php echo !empty($vehicle) ? "6" : "7" ?>  align="right"><strong>Net Amount</strong></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['net_amt']); ?></td>
      <td>&nbsp</td>
    </tr>

  <?php 	
    } ?>

</table>