<?php
	echo "<script type='text/javascript'>alert('Use browser print option to take printout');</script>";
?>

<table border="2" cellpadding="2" cellspacing="0" bordercolor="#3399FF">
<tr>
	<td colspan="10" align="center">
    <br />
    <strong><?php echo $title; ?> From</strong> : <?php echo $from_date; ?> <strong>To</strong> : <?php echo $to_date; ?>
    <?php if(!empty($vehicle)){ ?>
    <br />
    <strong>Vehicle Code :-</strong><?php echo $vehicle; ?>
    <?php } ?>
    </td>

</tr>
   <tr bgcolor="#000033" style="color:#CCCCCC;">
    <th scope="col">S.No</th>
    <th scope="col">Bill No</th>
    <th scope="col">Date</th>
    <th scope="col">Form</th>
    <th scope="col">Party </th>
    <th scope="col">Amount</th>
    <th scope="col">Vat</th>
    <th scope="col">Discount</th>
    <th scope="col">Round.Off</th>
    <th scope="col">Cash</th>
    <th scope="col">Credit</th>
  </tr>

  <?php 
  	
	if(count($result['result'])>0)
	{
		$i = 1;
		foreach($result['result'] as $row):
  ?>
  <tr>
    <td><?php echo $i++; ?></td>
    <td><?php echo $row['billno']; ?></td>   
    <td><?php echo $row['sales_date']; ?></td>
    <td><?php echo $row['form_type']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['total_amt']); ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['kvat_amt']); ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['disc_amt']); ?></td>
    <td align="right"><?php echo sprintf('%0.2f',$row['round_off']); ?></td>
    <td align="right"><?php echo $row['mode_of_pay'] == 'Cash' ?  sprintf('%0.2f',$row['net_amt']) : '' ; ?></td>
    <td align="right"><?php echo $row['mode_of_pay'] == 'Cash' ?  '' : sprintf('%0.2f',$row['net_amt']) ; ?></td>
  </tr>

  <?php 
   endforeach; ?>

    <tr>
      <td colspan="5" align="right"><strong>TOTAL</strong></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['total_amt']); ?></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['kvat_amt']); ?></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['disc_amt']); ?></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['round_off']); ?></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['net_cash']); ?></td>
      <td align="right"><?php echo sprintf('%0.2f',$result['total']['net_credit']); ?></td>      
    </tr>

  <?php 	
    } ?>

</table>