<h2 class="sub-header">Dashboard</h2>
<p> All details are based on selected financial year</p>
<!--<div class="row">
	<div class="col-md-12">
    	<h3>Total Available Details</h3>
        <div id="treemap" style="width: 900px; height: 400px;"></div>    	
    </div>
</div>
<hr/>-->
<div class="row">
	<div class="col-md-12">
    	<h3> Last 7 Days Purchase, InStock & Sales Active Details</h3>
    	<div id='dashboard'></div>
    </div>
</div>
<hr/>
<div class="row">
	<div class="col-md-12">
    	<h3>Monthly Avg Purchase, InStock, DC & Sales Details</h3>
    	<div id="chart_div"  style="width: 900px;height:300px;"></div>
    </div>
</div>

