<div class="col-md-8">
<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>
<form method="post" action="<?php echo site_url('entry/sales/create'); ?>" name="sales-form" id="sales-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>BillNo</th>
		<td><input type="text" name="sales_no" id="sales_no" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>BillDate</th>
		<td><input type="text" name="sales_date" id="sales_date" value="<?php echo date('Y-m-d'); ?>" class="form-control input-sm datepicker" /></td>
		<th></th>
	</tr>	
	<tr>	
		<th width="15%"></th>	
		<th>CustomerCode</th>	
		<td><input type="text" name="customer_code" id="customer_code" class="form-control input-sm" /></td>	
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>OutstandingAmt</th>
		<td><input type="text" name="outstanding_amt" id="outstanding_amt" class="form-control input-sm" /></td>
		<th></th>
	</tr>	
	<tr>
		<th></th>
		<td></td>		
		<td>
			<button type="button" class="btn btn-block btn-primary btn-sm" name="createSales" id="createSales"><strong>Next >></strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
