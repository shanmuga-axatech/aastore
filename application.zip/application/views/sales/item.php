<div class="col-md-12">
<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>
<form method="post" action="<?php echo site_url('entry/sales/'); ?>" name="entry-form" id="entry-form">
	<table class="table table-striped" width="100%">
		<tr>		
			<th width="39%">ItemName/Code</th>
			<th width="15%">BatchNo</th>
			<th width="12%">Qty</th>
			<th width="12%">Rate</th>
			<th width="12%">Total</th>
			<th width="10%">Action</th>
		</tr>
		<tr>
			<td>
				<input type="text" name="item_code" id="item_code" class="form-control input-sm" />
				<input type="hidden" name="item_id" id="item_id" />
			</td>
			<td><input type="text" name="batch_no" id="batch_no" class="form-control input-sm" /></td>
			<td><input type="text" name="qty" id="qty" class="form-control input-sm" /></td>
			<td><input type="text" name="rate" id="rate" class="form-control input-sm" /></td>
			<td><input type="text" name="total" id="total" class="form-control input-sm" /></td>
			<td>
				<input type="hidden" name="unique_id" id="unique_id" value="<?php echo $uniqueId; ?>" />
				<button type="submit" class="btn btn-primary btn-sm" name="addStock" id="addStock"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Add</strong></button>
			</td>		
		</tr>
	</table>
</form>
<table class="table table-striped" id="item-table" width="100%">
	<thead>
	<tr class="active">		
		<th width="39%">ItemName/Code</th>
		<th width="15%">BatchNo</th>
		<th width="12%">Qty</th>
		<th width="12%">Rate</th>
		<th width="12%">Total</th>
		<th width="10%">Action</th>
	</tr>	
	</thead>
	<tbody></tbody>
</table>

<table class="table table-striped" width="100%">
	<tr>
		<th width="39%">&nbsp;</th>		
		<th width="12%">TotalQty</th>
		<th width="12%"><input type="text" id="total_qty" class="form-control input-sm text-right" /></th>
		<th width="12%">TotalAmt</th>
		<th width="12%"><input type="text" id="total_amt" class="form-control input-sm text-right" /></th>
		<th width="10%">&nbsp;</th>
	</tr>	
	<tr>
		<th width="39%">&nbsp;</th>
		<th width="15%">&nbsp;</th>
		<th colspan="2">
			<a href="<?php echo site_url('entry/sales/cancel/'.$uniqueId); ?>" class="btn btn-sm btn-block btn-warning">Cancel</button>
		</th>
		<th colspan="2"><button type="button" id="save" class="btn btn-block btn-success btn-sm">Save</button></th>
	</tr>	
</table>
</div>
