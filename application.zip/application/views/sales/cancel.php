<div class="col-md-8 bg-dialog-750">
<table class="table table-striped " width="100%">
	<tr>
		<th></th>
		<th>Reason</th>
		<td><input type="text" name="reason" id="reason" placeholder="Enter Reason" class="form-control input-sm" value="<?php echo $cancel_reason['reason']; ?>"/></td>
		<th></th>		
	</tr>
	<tr>
		<th></th>
		<td><input type="hidden" name="sales_id" id="sales_id" value="<?php echo $cancel_reason['sales_id']; ?>"/></td>
		<td align="center">
			<button type="button" class="btn btn-danger btn-me" name="salecancel" id="salecancel"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Confirm</strong></button>
		</td>		
		<th></th>

	</tr>		
</table>
</div>
