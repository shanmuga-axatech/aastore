<div class="col-md-8">
<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>
<form method="post" action="<?php echo site_url('entry/sales/update'); ?>" name="sales-form" id="sales-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>BillNo</th>
		<td><input type="text" name="sales_no" id="sales_no" value="<?php echo $sales['sales_no']; ?>" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>BillDate</th>
		<td><input type="text" name="sales_date" id="sales_date" value="<?php echo $sales['sales_date']; ?>" class="form-control input-sm datepicker" /></td>
		<th></th>
	</tr>	
	<tr>	
		<th width="15%"></th>	
		<th>CustomerCode</th>	
		<td><input type="text" name="customer_code" id="customer_code"  value="<?php echo $sales['customer_code']; ?>" class="form-control input-sm" /></td>	
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>OutstandingAmt</th>
		<td><input type="text" name="outstanding_amt" id="outstanding_amt" value="<?php echo $sales['outstanding_amt']; ?>" class="form-control input-sm" /></td>
		<th></th>
	</tr>	
	<tr>
		<th></th>
		<td></td>		
		<td>
			<input type="hidden" name="sales_id" id="sales_id" value="<?php echo $sales['sales_id']; ?>" />
			<button type="button" class="btn btn-block btn-primary btn-sm" name="createSales" id="createSales"><strong>Update &amp; Next >></strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
