<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table id="sales-table" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Vehicle Code</th> 	    
	      <th>Bill No</th>
	      <th>Bill Date</th>      	      
	      <th>Customer</th>   
	      <th>Form</th>  
	      <th>Pay Type</th> 
	      <th>Amount</th>  
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>
</div>