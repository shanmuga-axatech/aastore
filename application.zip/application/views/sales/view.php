<div class="col-md-8 bg-dialog-750">
<table class="table table-striped " width="100%">
	<tr>
		<th>Bill No</th>
		<td><?php echo strtoupper($sales['vechicle_code']).'/'.$sales['sales_no']; ?></td>
		<td>&nbsp;</td>
		<th>Bill Date</th>
		<td><?php echo date('d-m-Y', strtotime($sales['sales_date'])); ?></td>
		
	</tr>
	<tr>
		<th>Customer</th>
		<td colspan="4"><?php echo $sales['name']; ?></td>
	</tr>	
	<tr>
		<th >Form</th>
		<td><?php echo $sales['form_type']; ?></td>	
		<td>&nbsp;</td>
		<th>Pay Type</th>
		<td><?php echo $sales['mode_of_pay']; ?></td>
	</tr>

	<tr class="danger">
		<th>ItemName/Code</th>
		<th>BatchNo</th>
		<th class="text-right">Qty</th>
		<th class="text-right">Rate</th>
		<th class="text-right">Total</th>
		
	</tr>
	<?php foreach($sales_item as $item): ?>
		<tr>
			<td><h5><?php echo $item['item_name']; ?><small><?php echo strtoupper($item['item_code']); ?></small></h5></td>
			<td><?php echo $item['batch_no']; ?></td>
			<td class="text-right"><?php echo $item['qty']; ?></td>
			<td  class="text-right"><?php echo $item['rate']; ?></td>
			<td  class="text-right"><?php echo $item['total']; ?></td>			
		</tr>
	<?php endforeach; ?>

	<tr class="danger">
		<td>&nbsp;</td>
		<th class="text-right">TotalQty&nbsp;</th>
		<th class="text-right"><?php echo $sales['total_qty']; ?></th>
		<th class="text-right">TotalAmt&nbsp;</th>
		<th class="text-right"><?php echo $sales['total_amt']; ?></th>
	</tr>
	<tr>
		<th>&nbsp;</th>
		<td>&nbsp;</td>	
		<td>&nbsp;</td>
		<th>KVAT <?php echo $sales['kvat_per'].'%'; ?></th>
		<td class="text-right"><?php echo sprintf('%00.2f',$sales['kvat_amt']); ?></td>
	</tr>

	<?php if($sales['disc_amt']!='0') { ?>
	<tr>
		<th>&nbsp;</th>
		<td>&nbsp;</td>	
		<td>&nbsp;</td>
		<th>Discount <?php echo $sales['disc_per']=0 ? '' : $sales['disc_per']; ?></th>
		<td class="text-right"><?php echo sprintf('%01.2f',$sales['disc_amt']); ?></td>
	</tr>
	<?php } ?>
	<tr>
		<th>&nbsp;</th>
		<td>&nbsp;</td>	
		<td>&nbsp;</td>
		<th>Net Amount</th>
		<td class="text-right"><?php echo sprintf('%01.2f',$sales['net_amt']); ?></td>
	</tr>	
</table>
</div>
