<div class="clear">&nbsp;</div>
<div class="col-md-12">
	<table id="customer" class="table table-striped">
	  <thead>
	    <tr>
	      <th>Code</th>
	      <th>Van</th>
	      <th>Name</th>
	      <th>Mobile</th>      	      
	      <th>Address</th> 
	      <th>Action</th>
	    </tr>
	  </thead>
	  <tbody></tbody>
	</table>

</div>