<div class="col-md-8 bg-dialog-500">
<table class="table table-striped " width="100%">
	<tr>
		<th>Name</th>
		<td><?php echo $name; ?></td>
	</tr>
	<tr>
		<th>Code</th>
		<td><?php echo $customer_code; ?></td>
	</tr>
	<tr>
		<th>TinNo</th>
		<td><?php echo $tinno; ?></td>
	</tr>
	<tr>
		<th>SalesType</th>
		<td><?php echo $sales_type; ?></td>
	</tr>
	<tr>
		<th>Mobile&nbsp;No</th>
		<td><?php echo $mobile; ?></td>
	</tr>
	<tr>
		<th>Phone&nbsp;No</th>
		<td><?php echo $phone; ?></td>
	</tr>
	<tr>
		<th>Email</th>
		<td><?php echo $email; ?></td>		
	</tr>
	<tr>
		<th>Address&nbsp;1</th>
		<td><?php echo $address1; ?></td>
	</tr>
	<tr>		
		<th>Address&nbsp;2</th>
		<td><?php echo $address2; ?></td>
	</tr>
	<tr>
		<th>City</th>
		<td><?php echo $city; ?></td>
	</tr>
	<tr>
		<th>Pincode</th>
		<td><?php echo $pincode; ?></td>
	</tr>
</table>
</div>
