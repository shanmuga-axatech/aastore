<div class="col-md-8">

<?php 
if(isset($msg)):
	$sClass  = $status?'alert-success':'alert-danger';
	$sAction = $status?'Success':'Error';
?>
<div class="alert <?php echo $sClass; ?> alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="glyphicon glyphicon-remove-circle"></i></button>
  <strong><?php echo $sAction; ?>!</strong> <?php echo $msg; ?>
</div>
<?php endif; ?>

<form method="post" action="<?php echo site_url('master/customer/save'); ?>" name="customer-form" id="customer-form">
<table class="table table-striped" width="100%">
	<tr>	
		<th width="15%"></th>	
		<th>Name</th>
		<td><input type="text" name="name" id="name" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>
	<tr>	
		<th width="15%"></th>	
		<th>Code</th>
		<td><input type="text" name="customer_code" id="customer_code" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>	
	<tr>		
		<th></th>
		<th>Mobile No</th>
		<td>
			<div class="input-group input-group-sm">
  			<span class="input-group-addon">0 - </span>
			<input type="text" name="mobile" id="mobile" class="form-control input-sm" />
			</div>
		</td>
		<th></th>
	</tr>
	<tr>	
		<th width="15%"></th>	
		<th>TinNo</th>
		<td><input type="text" name="tinno" id="tinno" class="form-control input-sm" /></td>		
		<th width="15%"></th>
	</tr>
	<tr>	
		<th width="15%"></th>	
		<th>SalesType</th>
		<td>
		<select name="sales_type" id="sales_type" class="form-control input-sm">
			<?php foreach($_SALES_TYPES as $sKey=>$sVal): ?>
				<option value="<?php echo $sKey; ?>"><?php echo $sVal; ?> </option>
			<?php endforeach; ?>
		</select>
		</td>		
		<th width="15%"></th>
	</tr>
	<tr>		
		<th></th>
		<th>Phone No</th>
		<td><input type="text" name="phone" id="phone" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Email</th>
		<td><input type="text" name="email" id="email" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Address 1</th>
		<td><input type="text" name="address1" id="address1" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>		
		<th></th>
		<th>Address 2</th>
		<td><input type="text" name="address2" id="address2" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>
		<th></th>
		<th>City</th>
		<td><input type="text" name="city" id="city" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>
		<th></th>
		<th>Pincode</th>
		<td><input type="text" name="pincode" id="pincode" class="form-control input-sm" /></td>
		<th></th>
	</tr>
	<tr>
		<th></th>
		<td></td>		
		<td align="center">
			<button type="button" class="btn btn-primary btn-sm" name="saveCustomer" id="saveCustomer"><i class="glyphicon glyphicon-ok-circle"></i> <strong>Save</strong></button>
		</td>		
		<th></th>
	</tr>
</table>
</form>
</div>
